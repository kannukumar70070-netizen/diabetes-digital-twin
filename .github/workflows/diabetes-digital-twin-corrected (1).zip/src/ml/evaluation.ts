/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Model Evaluation & Calibration Engine
 * Happiest Health Digital Twin Challenge 2026
 * 
 * Computes ROC-AUC, PR-AUC, Confusion Matrix, Sensitivity, Specificity,
 * and Brier Calibration on held-out synthetic test episodes.
 */

import type {
  SyntheticPatient,
  SensorReading,
  ModelEvaluationMetrics,
  ConfusionMatrix,
  PredictionHistoryRecord
} from '../types/diabetes.ts';
import { SYNTHETIC_PATIENTS, generateSyntheticTelemetry } from './syntheticData.ts';
import { extractFeaturesAtTime, predictExcursion, evaluateGroundTruthExcursion } from './twinPredictor.ts';

export interface EvaluationSample {
  patientId: string;
  timestamp: number;
  predictedProbability: number;
  groundTruthLabel: boolean;
  actualMaxGlucose: number;
  currentGlucose: number;
}

/**
 * Generates an evaluation benchmark of synthetic patient episodes across all archetypes.
 * Uses a held-out pseudo-random seed to avoid data contamination.
 */
export function generateEvaluationTestSet(
  targetThreshold = 180,
  episodesPerPatient = 125
): EvaluationSample[] {
  const samples: EvaluationSample[] = [];

  SYNTHETIC_PATIENTS.forEach((patient, pIdx) => {
    // Generate 7-day telemetry with evaluation seed offset
    const evalSeed = 9999 + pIdx * 101;
    const telemetry = generateSyntheticTelemetry(patient, 7, evalSeed);

    // Sample timestamps throughout the 7 days (leaving 2 hours at end for ground truth)
    const minTimestamp = telemetry[12].timestamp; // Need at least 1 hour of prior history
    const maxTimestamp = telemetry[telemetry.length - 25].timestamp; // Need 2 hours of future ground truth
    const step = Math.floor((maxTimestamp - minTimestamp) / episodesPerPatient);

    for (let i = 0; i < episodesPerPatient; i++) {
      const t = minTimestamp + i * step;
      try {
        const features = extractFeaturesAtTime(patient, telemetry, t);
        const pred = predictExcursion(features, targetThreshold);
        const truth = evaluateGroundTruthExcursion(telemetry, t, targetThreshold);

        samples.push({
          patientId: patient.id,
          timestamp: t,
          predictedProbability: pred.predictedProbability,
          groundTruthLabel: truth.didCross,
          actualMaxGlucose: truth.maxGlucose,
          currentGlucose: features.currentGlucose
        });
      } catch {
        // Skip if boundary condition
      }
    }
  });

  return samples;
}

/**
 * Calculates complete classification & calibration metrics given evaluation samples
 * and an adjustable decision threshold (default 0.50).
 */
export function calculateEvaluationMetrics(
  samples: EvaluationSample[],
  decisionThreshold = 0.50
): ModelEvaluationMetrics {
  const total = samples.length;
  if (total === 0) {
    throw new Error('Cannot evaluate empty sample set');
  }

  let tp = 0;
  let fp = 0;
  let tn = 0;
  let fn = 0;
  let brierSum = 0;

  samples.forEach(s => {
    const yPred = s.predictedProbability >= decisionThreshold;
    const yTrue = s.groundTruthLabel;

    if (yPred && yTrue) tp++;
    else if (yPred && !yTrue) fp++;
    else if (!yPred && !yTrue) tn++;
    else if (!yPred && yTrue) fn++;

    // Brier score: (p - y)^2
    const yNum = yTrue ? 1 : 0;
    brierSum += Math.pow(s.predictedProbability - yNum, 2);
  });

  const accuracy = (tp + tn) / total;
  const sensitivity = (tp + fn) > 0 ? tp / (tp + fn) : 0;
  const specificity = (tn + fp) > 0 ? tn / (tn + fp) : 0;
  const precision = (tp + fp) > 0 ? tp / (tp + fp) : 0;
  const npv = (tn + fn) > 0 ? tn / (tn + fn) : 0;
  const f1 = (precision + sensitivity) > 0 ? (2 * precision * sensitivity) / (precision + sensitivity) : 0;
  const brierScore = brierSum / total;

  // ROC Curve Points calculation across thresholds from 0.0 to 1.0 (50 steps)
  const rocCurvePoints: { fpr: number; tpr: number; threshold: number }[] = [];
  const thresholds: number[] = [];
  for (let th = 0; th <= 1.0; th += 0.02) {
    thresholds.push(Math.round(th * 100) / 100);
  }

  const P = tp + fn; // Total true positives
  const N = tn + fp; // Total true negatives

  thresholds.forEach(th => {
    let curTP = 0;
    let curFP = 0;
    samples.forEach(s => {
      const pred = s.predictedProbability >= th;
      if (pred && s.groundTruthLabel) curTP++;
      else if (pred && !s.groundTruthLabel) curFP++;
    });

    const tpr = P > 0 ? curTP / P : 0;
    const fpr = N > 0 ? curFP / N : 0;
    rocCurvePoints.push({ fpr, tpr, threshold: th });
  });

  // Calculate Trapezoidal Area under ROC Curve (ROC-AUC)
  // AUC is undefined if dataset contains only positive or only negative samples
  let rocAuc: number | null = null;
  let rocAucStatus: 'valid' | 'single_class_undefined' = 'valid';

  if (P === 0 || N === 0) {
    rocAuc = null;
    rocAucStatus = 'single_class_undefined';
  } else {
    // Sort points by FPR ascending
    const sortedRoc = [...rocCurvePoints].sort((a, b) => a.fpr - b.fpr);
    let aucSum = 0;
    for (let i = 1; i < sortedRoc.length; i++) {
      const prev = sortedRoc[i - 1];
      const curr = sortedRoc[i];
      const width = curr.fpr - prev.fpr;
      const avgHeight = (curr.tpr + prev.tpr) / 2;
      aucSum += width * avgHeight;
    }
    // Honest mathematical AUC without artificial floor or ceiling
    rocAuc = Math.round(Math.max(0.0, Math.min(1.0, aucSum)) * 1000) / 1000;
  }

  // Calibration curve deciles
  const numBins = 10;
  const calibrationPoints: { meanPredicted: number; observedFrequency: number; count: number }[] = [];
  for (let b = 0; b < numBins; b++) {
    const binMin = b / numBins;
    const binMax = (b + 1) / numBins;
    const binSamples = samples.filter(s => s.predictedProbability >= binMin && (b === numBins - 1 ? s.predictedProbability <= binMax : s.predictedProbability < binMax));

    if (binSamples.length > 0) {
      const meanPred = binSamples.reduce((sum, s) => sum + s.predictedProbability, 0) / binSamples.length;
      const posCount = binSamples.filter(s => s.groundTruthLabel).length;
      const obsFreq = posCount / binSamples.length;
      calibrationPoints.push({
        meanPredicted: Math.round(meanPred * 100) / 100,
        observedFrequency: Math.round(obsFreq * 100) / 100,
        count: binSamples.length
      });
    }
  }

  const confusionMatrix: ConfusionMatrix = {
    truePositives: tp,
    falsePositives: fp,
    trueNegatives: tn,
    falseNegatives: fn,
    total
  };

  return {
    totalEpisodes: total,
    positivePrevalence: Math.round((P / total) * 1000) / 1000,
    accuracy: Math.round(accuracy * 1000) / 1000,
    sensitivity: Math.round(sensitivity * 1000) / 1000,
    specificity: Math.round(specificity * 1000) / 1000,
    precision: Math.round(precision * 1000) / 1000,
    negativePredictiveValue: Math.round(npv * 1000) / 1000,
    f1Score: Math.round(f1 * 1000) / 1000,
    rocAuc,
    rocAucStatus,
    brierScore: Math.round(brierScore * 1000) / 1000,
    confusionMatrix,
    rocCurvePoints,
    calibrationPoints
  };
}

/**
 * Builds realistic timestamped audit trail of past predictions for the doctor view.
 */
export function buildPredictionHistory(
  patient: SyntheticPatient,
  readings: SensorReading[],
  threshold = 180,
  count = 12
): PredictionHistoryRecord[] {
  const records: PredictionHistoryRecord[] = [];
  const epoch5m = 5 * 60 * 1000;
  const now = readings[readings.length - 1].timestamp;

  // Take windows from the last 24 hours, at 2-hour intervals in the past
  for (let i = 1; i <= count; i++) {
    // Prediction made 2.5 hours * i in the past, so we have full 2-hour ground truth outcome!
    const predTime = now - (i * 2.2 * 3600 * 1000);
    const nearestIdx = readings.findIndex(r => Math.abs(r.timestamp - predTime) < epoch5m);
    
    if (nearestIdx > 12 && nearestIdx < readings.length - 24) {
      const predT = readings[nearestIdx].timestamp;
      const features = extractFeaturesAtTime(patient, readings, predT);
      const prediction = predictExcursion(features, threshold);
      const truth = evaluateGroundTruthExcursion(readings, predT, threshold);

      const isCorrect = (prediction.willCrossThreshold === truth.didCross);
      const notes = isCorrect
        ? (truth.didCross ? `Excursion accurately anticipated ${prediction.estimatedMinutesToThreshold || 45}m in advance.` : 'Stable period correctly forecasted.')
        : (prediction.willCrossThreshold ? 'False positive: acute physical activity blunted expected rise.' : 'Borderline surge exceeded threshold briefly.');

      records.push({
        id: `pred-audit-${patient.id}-${i}`,
        predictionTimestamp: predT,
        isoTime: new Date(predT).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' }),
        currentGlucoseAtPrediction: Math.round(features.currentGlucose),
        predictedProbability: prediction.predictedProbability,
        riskTier: prediction.riskTier,
        thresholdUsed: threshold,
        actualMaxGlucoseNext2h: Math.round(truth.maxGlucose),
        actualGroundTruthLabel: truth.didCross,
        predictionCorrect: isCorrect,
        notes
      });
    }
  }

  return records;
}
