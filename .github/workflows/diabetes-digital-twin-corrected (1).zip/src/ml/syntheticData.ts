/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Reproducible Synthetic Data Engine
 * Happiest Health Digital Twin Challenge 2026
 * 
 * Physiological Minimal Model-inspired synthetic data generator.
 * Strictly enforces zero data leakage.
 */

import type { SyntheticPatient, SensorReading } from '../types/diabetes.ts';

// Seeded pseudo-random number generator (Mulberry32) for 100% reproducible data
export function createRng(seed: number) {
  let s = Math.floor(seed);
  return function() {
    s |= 0;
    s = s + 0x6D2B79F5 | 0;
    let t = Math.imul(s ^ s >>> 15, 1 | s);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// Box-Muller transform for reproducible Gaussian distributed noise
export function gaussianRandom(rng: () => number, mean = 0, stdev = 1): number {
  const u1 = Math.max(1e-7, rng());
  const u2 = rng();
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return z0 * stdev + mean;
}

export const SYNTHETIC_PATIENTS: SyntheticPatient[] = [
  {
    id: 'pt-001-vance',
    name: 'Eleanor Vance',
    age: 58,
    gender: 'Female',
    diagnosis: 'Type 2 Diabetes',
    diagnosisYears: 6,
    bmi: 29.4,
    baselineHbA1c: 7.8,
    targetGlucoseRange: [70, 180],
    hyperglycemiaThreshold: 180,
    hypoglycemiaThreshold: 70,
    medications: [
      { name: 'Metformin XR', dosage: '1000 mg', frequency: 'Twice daily', complianceRate: 0.94, class: 'Biguanide' },
      { name: 'Empagliflozin', dosage: '10 mg', frequency: 'Once daily (AM)', complianceRate: 0.90, class: 'SGLT2-i' }
    ],
    clinicalNotes: 'Demonstrates notable postprandial excursions, especially after carbohydrate-dense evening meals. Delayed gastric emptying and moderate hepatic insulin resistance.',
    avatarSeed: 'eleanor'
  },
  {
    id: 'pt-002-chen',
    name: 'Marcus Chen',
    age: 46,
    gender: 'Male',
    diagnosis: 'Prediabetes',
    diagnosisYears: 2,
    bmi: 27.8,
    baselineHbA1c: 6.2,
    targetGlucoseRange: [70, 160],
    hyperglycemiaThreshold: 160,
    hypoglycemiaThreshold: 70,
    medications: [
      { name: 'Lifestyle Intervention', dosage: 'Mediterranean diet + 150 min/wk', frequency: 'Daily', complianceRate: 0.78, class: 'Lifestyle Only' }
    ],
    clinicalNotes: 'Software architect with sedentary desk hours and high work-related cortisol spikes. Fasting glucose borderline 108 mg/dL with prolonged recovery after stress meetings.',
    avatarSeed: 'marcus'
  },
  {
    id: 'pt-003-patel',
    name: 'Aisha Patel',
    age: 34,
    gender: 'Female',
    diagnosis: 'LADA',
    diagnosisYears: 3,
    bmi: 23.1,
    baselineHbA1c: 8.4,
    targetGlucoseRange: [70, 180],
    hyperglycemiaThreshold: 180,
    hypoglycemiaThreshold: 70,
    medications: [
      { name: 'Insulin Glargine', dosage: '14 units', frequency: 'Bedtime', complianceRate: 0.98, class: 'Basal Insulin' },
      { name: 'Insulin Aspart', dosage: '1 unit / 12g carb', frequency: 'Prandial bolus', complianceRate: 0.88, class: 'Basal Insulin' }
    ],
    clinicalNotes: 'Latent Autoimmune Diabetes in Adults. Significant beta-cell decline, high glycemic variability, high sensitivity to rapid carbs and rapid glucose rate of rise.',
    avatarSeed: 'aisha'
  },
  {
    id: 'pt-004-miller',
    name: 'David Miller',
    age: 64,
    gender: 'Male',
    diagnosis: 'Type 2 Diabetes',
    diagnosisYears: 12,
    bmi: 26.2,
    baselineHbA1c: 6.7,
    targetGlucoseRange: [70, 180],
    hyperglycemiaThreshold: 180,
    hypoglycemiaThreshold: 70,
    medications: [
      { name: 'Metformin', dosage: '500 mg', frequency: 'Twice daily', complianceRate: 0.98, class: 'Biguanide' },
      { name: 'Semaglutide', dosage: '0.5 mg', frequency: 'Weekly', complianceRate: 0.96, class: 'GLP-1 RA' }
    ],
    clinicalNotes: 'Well-managed patient with high daily step counts (retiree gardener). Consistent glycemic stability, excellent time-in-range (>82%), low rate of excursions.',
    avatarSeed: 'david'
  }
];

export interface MealEvent {
  day: number;
  minuteOfDay: number;
  carbsGrams: number;
  giFactor: number; // Glycemic Index (0.5 = low GI, 1.2 = high GI)
  description: string;
}

export interface ExerciseEvent {
  day: number;
  minuteOfDay: number;
  durationMinutes: number;
  intensity: 'light' | 'moderate' | 'vigorous';
  description: string;
}

/**
 * Generates continuous multi-sensor telemetry for a synthetic patient over `numDays` (default 7 days).
 * 5-minute epochs (288 readings per day).
 */
export function generateSyntheticTelemetry(
  patient: SyntheticPatient,
  numDays = 7,
  seed = 42
): SensorReading[] {
  const rng = createRng(seed + patient.age * 13 + patient.bmi * 7);
  const readings: SensorReading[] = [];
  const epochMinutes = 5;
  const totalEpochs = (numDays * 24 * 60) / epochMinutes;

  // Base physiological parameters derived from patient profile
  const basalGlucose = 85 + (patient.baselineHbA1c - 5.4) * 22; // mg/dL
  const restingHeartRate = 62 + (patient.bmi > 28 ? 8 : 2) + (patient.age > 50 ? 4 : 0);
  const insulinSensitivity = 1.0 / (1.0 + (patient.bmi - 22) * 0.05 + (patient.diagnosisYears * 0.04));

  // Anchor time: starting 7 days ago, aligned to midnight
  const now = Date.now();
  const startTime = now - numDays * 24 * 3600 * 1000;

  // State variables for continuous physiological simulation
  let currentG = basalGlucose;
  let activeMealEffect = 0; // Current rate of glucose flux from digestive absorption
  let activeExerciseEffect = 0; // Exercise-induced GLUT4 uptake sink
  let cumulativeStepsToday = 0;
  let lastDayRecorded = -1;

  for (let i = 0; i < totalEpochs; i++) {
    const timestamp = startTime + i * epochMinutes * 60 * 1000;
    const epochMinuteOfDay = (i * epochMinutes) % (24 * 60);
    const dayIndex = Math.floor((i * epochMinutes) / (24 * 60));
    const hourOfDay = epochMinuteOfDay / 60;

    // Reset daily steps at midnight
    if (dayIndex !== lastDayRecorded) {
      cumulativeStepsToday = 0;
      lastDayRecorded = dayIndex;
    }

    let eventMarker: SensorReading['eventMarker'] = undefined;
    let eventDescription: string | undefined = undefined;

    // Daily sleep duration for previous night (7.2h +/- 1h)
    const sleepMinutes = Math.round(420 + gaussianRandom(rng, 0, 35));
    const sleepQuality = Math.min(98, Math.max(50, Math.round(82 - (patient.bmi > 28 ? 10 : 0) + gaussianRandom(rng, 0, 6))));

    // Circadian Dawn Phenomenon (cortisol surge ~04:30 - 08:00 AM)
    let dawnSurge = 0;
    if (hourOfDay >= 4.5 && hourOfDay <= 8.5) {
      dawnSurge = Math.sin(((hourOfDay - 4.5) / 4.0) * Math.PI) * (patient.baselineHbA1c > 7.0 ? 18 : 8);
    }

    // Schedule Meals
    // Breakfast: 07:45 - 08:30
    if (epochMinuteOfDay === 8 * 60) {
      const carbs = 40 + gaussianRandom(rng, 0, 8);
      activeMealEffect += (carbs * 1.6) / insulinSensitivity;
      eventMarker = 'meal';
      eventDescription = 'Breakfast (oatmeal & berries, ~42g carbs)';
    }
    // Lunch: 12:45 - 13:15
    else if (epochMinuteOfDay === 13 * 60) {
      const carbs = 60 + gaussianRandom(rng, 0, 12);
      activeMealEffect += (carbs * 1.8) / insulinSensitivity;
      eventMarker = 'meal';
      eventDescription = 'Lunch (grain bowl & chicken, ~65g carbs)';
    }
    // Dinner: 19:15 - 20:00
    else if (epochMinuteOfDay === 19.5 * 60) {
      const carbs = 70 + (patient.id.includes('vance') ? 25 : 0) + gaussianRandom(rng, 0, 15);
      activeMealEffect += (carbs * 2.1) / insulinSensitivity;
      eventMarker = 'meal';
      eventDescription = 'Dinner (pasta & salad, ~85g carbs)';
    }
    // Occasional afternoon snack
    else if (epochMinuteOfDay === 16 * 60 && rng() > 0.4) {
      activeMealEffect += (25 * 1.4) / insulinSensitivity;
      eventMarker = 'meal';
      eventDescription = 'Afternoon Snack (apple & nuts, ~22g carbs)';
    }

    // Schedule Exercise / Physical Activity
    let epochSteps = 0;
    let heartRate = restingHeartRate + gaussianRandom(rng, 0, 2.5);

    // Sleep hours (23:00 to 07:00)
    const isSleeping = hourOfDay < 7.0 || hourOfDay >= 23.0;
    if (isSleeping) {
      epochSteps = rng() > 0.9 ? Math.floor(rng() * 12) : 0;
      heartRate = restingHeartRate - 8 + gaussianRandom(rng, 0, 2);
    } else {
      // Daytime baseline movement
      epochSteps = Math.floor(rng() * 60 + 20);

      // Evening or morning walk event
      if (epochMinuteOfDay === 17.5 * 60) {
        epochSteps = 1200 + Math.floor(rng() * 400); // 20 min brisk walk
        heartRate = restingHeartRate + 38 + gaussianRandom(rng, 0, 4);
        activeExerciseEffect += 35 * (patient.medications.some(m => m.class === 'SGLT2-i') ? 1.2 : 1.0);
        eventMarker = 'exercise';
        eventDescription = 'Brisk Evening Walk (20 min)';
      } else if (epochMinuteOfDay === 10.5 * 60 && patient.id.includes('miller')) {
        epochSteps = 900 + Math.floor(rng() * 300);
        heartRate = restingHeartRate + 25 + gaussianRandom(rng, 0, 3);
        activeExerciseEffect += 22;
        eventMarker = 'exercise';
        eventDescription = 'Gardening / Active chore (30 min)';
      }
    }

    cumulativeStepsToday += epochSteps;

    // Physiological ODE approximation:
    // dG/dt = Basal_return + (Meal_absorption) - (Exercise_uptake) - Insulin_clearance + Noise
    const mealFlux = activeMealEffect * 0.12; // exponential absorption decay
    activeMealEffect *= 0.88; // decay remaining meal in gut

    const exerciseSink = activeExerciseEffect * 0.15;
    activeExerciseEffect *= 0.85;

    const clearanceRate = 0.05 * insulinSensitivity;
    const basalDeviation = currentG - (basalGlucose + dawnSurge);

    const deltaG = (mealFlux - exerciseSink - basalDeviation * clearanceRate) * (epochMinutes / 5) + gaussianRandom(rng, 0, 1.2);
    
    // Previous glucose for velocity calculation
    const prevG = currentG;
    currentG = Math.max(55, Math.min(360, currentG + deltaG));
    const instantaneousVelocity = (currentG - prevG) / epochMinutes; // mg/dL per min

    readings.push({
      timestamp,
      isoTime: new Date(timestamp).toISOString(),
      glucose: Math.round(currentG * 10) / 10,
      glucoseVelocity: Math.round(instantaneousVelocity * 100) / 100,
      heartRate: Math.round(heartRate),
      steps: epochSteps,
      cumulativeStepsToday,
      sleepMinutesPriorNight: sleepMinutes,
      sleepQualityScore: sleepQuality,
      eventMarker,
      eventDescription
    });
  }

  return readings;
}
