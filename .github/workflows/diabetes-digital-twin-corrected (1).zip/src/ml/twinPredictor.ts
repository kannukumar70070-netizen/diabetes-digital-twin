/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Rule-Based Physiological Logistic Scoring Model
 * Happiest Health Digital Twin Challenge 2026
 * 
 * Rigorous Zero-Leakage Feature Extraction & Physiological Risk Scoring Model
 */

import type {
  SyntheticPatient,
  SensorReading,
  FeatureVector,
  FeatureAttribution,
  ForecastPoint,
  PredictionResult,
} from '../types/diabetes.ts';

/**
 * Standardize features and calculate logistic model log-odds.
 * Model formulation:
 * - Architecture: Expert-parameterized rule-based multivariable logistic scoring model
 *   (parameterized from Bergman Minimal Model kinetics and multi-sensor glycemic dynamics,
 *   evaluated on held-out synthetic patient telemetry).
 * - Target Y(t): Binary indicator of whether glucose exceeds the threshold within the next 2 hours:
 *     Y(t) = 1 if max{G(t + dt) : 0 < dt <= 120m} >= G_threshold else 0
 * - Prediction Horizon: Fixed 2-hour forward window.
 * - Input Features X(t): Derived strictly from retrospective readings (t_reading <= t).
 * - Limitations: Evaluated on synthetic patient cohorts; not trained on human clinical trial data.
 */
interface ModelWeights {
  intercept: number;
  currentGlucose: number;
  glucoseDelta15: number;
  glucoseDelta30: number;
  glucoseVelocity: number;
  glucoseAcceleration: number;
  glucoseMean60m: number;
  glucoseStd60m: number;
  recentSteps60m: number;
  heartRateElevation: number;
  sleepDeficitHours: number;
  timeOfDayCircadian: number;
  baselineHbA1c: number;
  age: number;
  bmi: number;
  medicationPotency: number;
}

const BASE_WEIGHTS: ModelWeights = {
  intercept: -3.85,
  currentGlucose: 0.048, // Higher current glucose strongly increases odds
  glucoseDelta15: 0.082, // Rapid rise in last 15 min
  glucoseDelta30: 0.045, // Sustained 30 min climb
  glucoseVelocity: 0.95, // Direct velocity vector
  glucoseAcceleration: 0.42, // Upward acceleration
  glucoseMean60m: 0.015,
  glucoseStd60m: 0.038, // Glycemic variability risk
  recentSteps60m: -0.00075, // Physical activity is protective (GLUT4 sink)
  heartRateElevation: 0.018, // Acute sympathetic stress / adrenaline elevation
  sleepDeficitHours: 0.22, // Sleep deprivation worsens morning insulin resistance
  timeOfDayCircadian: 0.35, // Postprandial evening or dawn cortisol window
  baselineHbA1c: 0.45, // High baseline prior = higher persistent peak
  age: 0.012,
  bmi: 0.032,
  medicationPotency: -0.55 // High medication compliance & potency lowers excursion odds
};

/**
 * Strictly extracts feature vector using ONLY data at or before target timestamp `t`.
 * ZERO DATA LEAKAGE GUARANTEE: Filter strictly checks r.timestamp <= t.
 */
export function extractFeaturesAtTime(
  patient: SyntheticPatient,
  readings: SensorReading[],
  t: number
): FeatureVector {
  // 1. Strictly filter history up to t
  const history = readings.filter(r => r.timestamp <= t);
  if (history.length === 0) {
    throw new Error('Cannot extract features: no historical sensor readings before target time.');
  }

  const current = history[history.length - 1];
  const currentG = current.glucose;

  // 2. Look back 15 minutes (3 epochs) and 30 minutes (6 epochs)
  const epoch5m = 5 * 60 * 1000;
  const tMinus15 = t - 15 * 60 * 1000;
  const tMinus30 = t - 30 * 60 * 1000;
  const tMinus60 = t - 60 * 60 * 1000;

  // Find nearest readings at or before t-15 and t-30
  const reading15 = [...history].reverse().find(r => r.timestamp <= tMinus15);
  const reading30 = [...history].reverse().find(r => r.timestamp <= tMinus30);
  const readingsPast60m = history.filter(r => r.timestamp >= tMinus60 && r.timestamp <= t);

  const glucoseDelta15 = reading15 ? (currentG - reading15.glucose) : (current.glucoseVelocity * 15);
  const glucoseDelta30 = reading30 ? (currentG - reading30.glucose) : (current.glucoseVelocity * 30);

  // Mean & Std of glucose in past 60 min
  const glucoseVals60m = readingsPast60m.map(r => r.glucose);
  const mean60m = glucoseVals60m.length > 0
    ? glucoseVals60m.reduce((a, b) => a + b, 0) / glucoseVals60m.length
    : currentG;

  const variance60m = glucoseVals60m.length > 1
    ? glucoseVals60m.reduce((acc, val) => acc + Math.pow(val - mean60m, 2), 0) / (glucoseVals60m.length - 1)
    : 4.0;
  const std60m = Math.sqrt(variance60m);

  // Acceleration (change in velocity over last 15 min)
  const prevVelocity = reading15 ? reading15.glucoseVelocity : current.glucoseVelocity;
  const glucoseAcceleration = (current.glucoseVelocity - prevVelocity) / 15.0;

  // Steps in last 60 minutes
  const recentSteps60m = readingsPast60m.reduce((sum, r) => sum + r.steps, 0);

  // Heart rate elevation (relative to patient resting baseline)
  const restingHR = 65 + (patient.bmi > 28 ? 6 : 0);
  const heartRateElevation = Math.max(-10, current.heartRate - restingHR);

  // Sleep deficit
  const sleepHours = current.sleepMinutesPriorNight / 60.0;
  const sleepDeficitHours = Math.max(0, 8.0 - sleepHours);

  // Circadian hour
  const date = new Date(t);
  const hourOfDay = date.getHours() + date.getMinutes() / 60;

  // Medication potency score
  let medScore = 0;
  patient.medications.forEach(m => {
    let weight = 0.5;
    if (m.class === 'Basal Insulin') weight = 1.0;
    else if (m.class === 'GLP-1 RA') weight = 0.9;
    else if (m.class === 'SGLT2-i') weight = 0.7;
    else if (m.class === 'Biguanide') weight = 0.6;
    medScore += weight * m.complianceRate;
  });

  // Check if patient currently takes GLP-1 RA therapy
  const hasGlp1Rx = patient.medications.some(m => m.class === 'GLP-1 RA');

  return {
    age: patient.age,
    baselineHbA1c: patient.baselineHbA1c,
    bmi: patient.bmi,
    diagnosisYears: patient.diagnosisYears,
    medicationPotencyScore: medScore,
    currentGlucose: currentG,
    glucoseDelta15,
    glucoseDelta30,
    glucoseVelocity: current.glucoseVelocity,
    glucoseAcceleration,
    glucoseMean60m: Math.round(mean60m * 10) / 10,
    glucoseStd60m: Math.round(std60m * 10) / 10,
    recentSteps60m,
    heartRateElevation,
    sleepDeficitHours,
    timeOfDayHour: hourOfDay,
    glp1TherapyActive: hasGlp1Rx,
    absorptionDelayFactor: hasGlp1Rx ? 0.65 : 1.0
  };
}

/**
 * Predicts probability of crossing `threshold` (default 180 mg/dL) within next 2 hours (120 minutes)
 * and generates explainable SHAP-like factor attributions and forward trajectory.
 */
export function predictExcursion(
  features: FeatureVector,
  threshold = 180,
  decisionThreshold = 0.50
): PredictionResult {
  // Baseline threshold adjustment: If user sets threshold lower (e.g. 150), probability scales up
  const thresholdDelta = (180 - threshold) * 0.035;

  // Circadian alignment factor (higher evening after dinner or dawn)
  const circadianWeight = (features.timeOfDayHour >= 19 && features.timeOfDayHour <= 22)
    ? 1.0
    : (features.timeOfDayHour >= 5 && features.timeOfDayHour <= 8 ? 0.7 : 0.2);

  // GLP-1 Receptor Agonist Modulation:
  // Delayed gastric emptying attenuates acute glucose appearance velocity (absorptionDelayFactor default 0.65 = 35% slower carb appearance)
  const isGlp1 = Boolean(features.glp1TherapyActive);
  const absorptionFactor = isGlp1 ? (features.absorptionDelayFactor ?? 0.65) : 1.0;
  const effectiveVelocity = features.glucoseVelocity * absorptionFactor;
  const effectiveDelta15 = features.glucoseDelta15 * absorptionFactor;
  const effectiveDelta30 = features.glucoseDelta30 * absorptionFactor;
  const glp1ProtectiveBonus = isGlp1 ? -0.75 : 0.0;

  // Compute logit linear sum
  let logit = BASE_WEIGHTS.intercept + thresholdDelta;

  const currentGContribution = (features.currentGlucose - 130) * BASE_WEIGHTS.currentGlucose;
  const delta15Contribution = effectiveDelta15 * BASE_WEIGHTS.glucoseDelta15;
  const delta30Contribution = effectiveDelta30 * BASE_WEIGHTS.glucoseDelta30;
  const velocityContribution = effectiveVelocity * BASE_WEIGHTS.glucoseVelocity;
  const accelContribution = features.glucoseAcceleration * 10 * BASE_WEIGHTS.glucoseAcceleration;
  const stdContribution = (features.glucoseStd60m - 12) * BASE_WEIGHTS.glucoseStd60m;
  const stepsContribution = (features.recentSteps60m - 800) * BASE_WEIGHTS.recentSteps60m;
  const hrContribution = features.heartRateElevation * BASE_WEIGHTS.heartRateElevation;
  const sleepContribution = features.sleepDeficitHours * BASE_WEIGHTS.sleepDeficitHours;
  const circadianContribution = circadianWeight * BASE_WEIGHTS.timeOfDayCircadian;
  const hba1cContribution = (features.baselineHbA1c - 6.5) * BASE_WEIGHTS.baselineHbA1c;
  const bmiContribution = (features.bmi - 25) * BASE_WEIGHTS.bmi;
  const medContribution = ((features.medicationPotencyScore - 1.0) * BASE_WEIGHTS.medicationPotency) + glp1ProtectiveBonus;

  logit += (
    currentGContribution +
    delta15Contribution +
    delta30Contribution +
    velocityContribution +
    accelContribution +
    stdContribution +
    stepsContribution +
    hrContribution +
    sleepContribution +
    circadianContribution +
    hba1cContribution +
    bmiContribution +
    medContribution
  );

  // Logistic sigmoid
  const rawProb = 1.0 / (1.0 + Math.exp(-logit));
  const probability = Math.max(0.01, Math.min(0.99, Math.round(rawProb * 1000) / 1000));

  // Determine Risk Tier
  let riskTier: PredictionResult['riskTier'] = 'Low';
  if (probability >= 0.75) riskTier = 'Critical';
  else if (probability >= 0.50) riskTier = 'Elevated';
  else if (probability >= 0.25) riskTier = 'Moderate';

  // Estimate expected peak glucose in next 2 hours
  // Physiological projection based on velocity decay
  const projectedRise = Math.max(
    0,
    (effectiveVelocity * 50) + (effectiveDelta15 * 0.8) + (features.glucoseStd60m * 0.6) - (features.recentSteps60m * 0.005) - (isGlp1 ? 22 : 0)
  );
  const expectedPeak = Math.round(features.currentGlucose + projectedRise);

  // Estimate minutes to threshold crossing if trending upward towards it
  let minutesToCrossing: number | null = null;
  if (features.currentGlucose >= threshold) {
    minutesToCrossing = 0; // Already crossed
  } else if (effectiveVelocity > 0.3) {
    const minNeeded = Math.round((threshold - features.currentGlucose) / effectiveVelocity);
    if (minNeeded <= 120) {
      minutesToCrossing = Math.max(5, minNeeded);
    }
  }

  // Generate Feature Attributions (Local Explainability)
  const rawAttributions: { name: string; label: string; raw: string; val: number; interp: string }[] = [
    {
      name: 'currentGlucose',
      label: 'Current CGM Glucose',
      raw: `${Math.round(features.currentGlucose)} mg/dL`,
      val: currentGContribution,
      interp: features.currentGlucose > 150 ? 'Baseline elevated towards threshold' : 'Glucose well within target range'
    },
    {
      name: 'glucoseVelocity',
      label: 'Rate of Change (dG/dt)',
      raw: `${features.glucoseVelocity > 0 ? '+' : ''}${features.glucoseVelocity.toFixed(2)} mg/dL/min`,
      val: velocityContribution + delta15Contribution,
      interp: isGlp1
        ? `Attenuated by GLP-1 RA (~${Math.round((1 - absorptionFactor) * 100)}% slower absorption flux)`
        : (features.glucoseVelocity > 0.8 ? 'Rapid upward glycemic velocity' : (features.glucoseVelocity < -0.5 ? 'Downward velocity clearing glucose' : 'Stable slope'))
    },
    {
      name: 'baselineHbA1c',
      label: 'Clinical HbA1c Prior',
      raw: `${features.baselineHbA1c.toFixed(1)}%`,
      val: hba1cContribution,
      interp: features.baselineHbA1c > 7.0 ? 'High historical glycemic burden' : 'Well-controlled baseline metabolism'
    },
    {
      name: 'recentSteps60m',
      label: 'Activity (Steps last 60m)',
      raw: `${features.recentSteps60m} steps`,
      val: stepsContribution,
      interp: features.recentSteps60m > 1200 ? 'Active movement promotes non-insulin GLUT4 clearance' : 'Sedentary status blunts glucose uptake'
    },
    {
      name: 'heartRateElevation',
      label: 'Heart Rate Elevation',
      raw: `${features.heartRateElevation >= 0 ? '+' : ''}${Math.round(features.heartRateElevation)} bpm`,
      val: hrContribution,
      interp: features.heartRateElevation > 15 ? 'Sympathetic stress or exertion elevated' : 'Normal resting cardiovascular state'
    },
    {
      name: 'sleepDeficitHours',
      label: 'Sleep Debt',
      raw: `${features.sleepDeficitHours.toFixed(1)} hrs deficit`,
      val: sleepContribution,
      interp: features.sleepDeficitHours > 1.5 ? 'Sleep deprivation reduces peripheral insulin sensitivity' : 'Restorative sleep prior night'
    },
    {
      name: 'medicationPotency',
      label: 'Medication Regimen & Adherence',
      raw: `${Math.round(features.medicationPotencyScore * 100)}% coverage`,
      val: medContribution,
      interp: isGlp1
        ? 'GLP-1 RA active: Delayed gastric emptying & enhanced glucose-dependent insulin secretion'
        : (features.medicationPotencyScore > 0.8 ? 'Active pharmacotherapy dampens postprandial peak' : 'Suboptimal medication barrier')
    }
  ];

  if (isGlp1) {
    rawAttributions.push({
      name: 'glp1TherapyActive',
      label: 'GLP-1 RA Therapy',
      raw: 'Active (Semaglutide / Tirzepatide)',
      val: glp1ProtectiveBonus,
      interp: 'Delays gastric emptying & suppresses inappropriate glucagon secretion'
    });
  }

  // Calculate percentage shares of total magnitude
  const totalMagnitude = rawAttributions.reduce((sum, a) => sum + Math.abs(a.val), 0) || 1;
  const attributions: FeatureAttribution[] = rawAttributions
    .map(a => {
      const pct = Math.round((a.val / totalMagnitude) * 100);
      return {
        featureName: a.name,
        label: a.label,
        rawValue: a.raw,
        contributionPercent: pct,
        impact: (pct > 2 ? 'risk_increasing' : (pct < -2 ? 'protective' : 'neutral')) as FeatureAttribution['impact'],
        clinicalInterpretation: a.interp
      };
    })
    .sort((a, b) => Math.abs(b.contributionPercent) - Math.abs(a.contributionPercent));

  // Forward 2-Hour Trajectory Projection
  // Step intervals: 0, 15, 30, 45, 60, 75, 90, 105, 120 minutes
  const trajectory: ForecastPoint[] = [];
  const intervals = [0, 15, 30, 45, 60, 75, 90, 105, 120];

  // Dynamics simulation parameters
  let gProj = features.currentGlucose;
  let vel = effectiveVelocity;
  let gWalk = features.currentGlucose;
  let velWalk = effectiveVelocity;
  let gGlp1 = features.currentGlucose;
  const glp1Factor = features.absorptionDelayFactor ?? 0.65;
  let velGlp1 = features.glucoseVelocity * glp1Factor; // GLP-1 counterfactual absorption curve
  let gUnmed = features.currentGlucose;
  let velUnmed = features.glucoseVelocity; // Unattenuated raw velocity curve

  intervals.forEach(dt => {
    if (dt === 0) {
      trajectory.push({
        timeOffsetMinutes: 0,
        projectedGlucose: Math.round(gProj),
        lowerConfidence95: Math.round(gProj),
        upperConfidence95: Math.round(gProj),
        counterfactualWalkGlucose: Math.round(gProj),
        counterfactualRestGlucose: Math.round(gProj),
        counterfactualGlp1Glucose: Math.round(gProj),
        counterfactualUnmedicatedGlucose: Math.round(gProj)
      });
      return;
    }

    // Baseline projection: velocity decays naturally back toward basal equilibrium
    const stepDeltaMin = 15;
    gProj += vel * stepDeltaMin * 0.85;
    vel *= 0.72; // velocity decays as meal absorption peaks and clearances kick in

    // Heuristic dispersion band widens with time: +/- (4 + dt * 0.32 + std * 0.4) mg/dL
    // Note: This is an empirical dispersion heuristic, not a statistically validated parametric 95% CI.
    const spread = 4 + dt * 0.32 + (features.glucoseStd60m * 0.4);

    // Counterfactual: 15-min brisk walk immediately taken
    // Increases muscle glucose clearance by extra 1.2 mg/dL per min
    const walkSink = dt <= 45 ? 1.4 : 0.6;
    gWalk += (velWalk - walkSink) * stepDeltaMin * 0.8;
    velWalk *= 0.65;

    // Counterfactual GLP-1 trajectory: smooth delayed rise and lower peak
    const glp1Clearance = dt <= 60 ? 0.4 : 0.8;
    gGlp1 += (velGlp1 - glp1Clearance) * stepDeltaMin * 0.78;
    velGlp1 *= 0.62;

    // Counterfactual Unmedicated trajectory (if on GLP-1, what it would be without):
    gUnmed += velUnmed * stepDeltaMin * 0.85;
    velUnmed *= 0.72;

    trajectory.push({
      timeOffsetMinutes: dt,
      projectedGlucose: Math.round(Math.max(50, gProj)),
      lowerConfidence95: Math.round(Math.max(45, gProj - spread)),
      upperConfidence95: Math.round(gProj + spread),
      counterfactualWalkGlucose: Math.round(Math.max(50, gWalk)),
      counterfactualRestGlucose: Math.round(gProj + (dt * 0.15)), // resting accumulates slight extra elevation
      counterfactualGlp1Glucose: Math.round(Math.max(50, gGlp1)),
      counterfactualUnmedicatedGlucose: Math.round(Math.max(50, gUnmed))
    });
  });

  return {
    timestamp: Date.now(),
    predictedProbability: probability,
    decisionThreshold,
    willCrossThreshold: probability >= decisionThreshold,
    riskTier,
    expectedPeakGlucose2h: expectedPeak,
    estimatedMinutesToThreshold: minutesToCrossing,
    attributions,
    trajectory
  };
}

/**
 * Evaluates whether ground truth excursion actually occurred in historical data
 * from target time `t` to `t + 120min`.
 */
export function evaluateGroundTruthExcursion(
  readings: SensorReading[],
  t: number,
  threshold = 180
): { didCross: boolean; maxGlucose: number } {
  const windowEnd = t + 120 * 60 * 1000;
  // Strictly in the future window (t < timestamp <= t + 120min)
  const futureReadings = readings.filter(r => r.timestamp > t && r.timestamp <= windowEnd);
  
  if (futureReadings.length === 0) {
    return { didCross: false, maxGlucose: 0 };
  }

  const maxG = Math.max(...futureReadings.map(r => r.glucose));
  return {
    didCross: maxG >= threshold,
    maxGlucose: maxG
  };
}
