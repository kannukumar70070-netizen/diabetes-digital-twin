/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Unit tests for Diabetes Digital Twin ML & Feature Extraction
 * Node:test native runner
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { SYNTHETIC_PATIENTS, generateSyntheticTelemetry, createRng } from './syntheticData.ts';
import { extractFeaturesAtTime, predictExcursion, evaluateGroundTruthExcursion } from './twinPredictor.ts';
import { calculateEvaluationMetrics, type EvaluationSample } from './evaluation.ts';

test('createRng produces deterministic sequences for identical seeds', () => {
  const rng1 = createRng(12345);
  const rng2 = createRng(12345);
  for (let i = 0; i < 10; i++) {
    assert.equal(rng1(), rng2());
  }
});

test('generateSyntheticTelemetry produces continuous 5-minute data without NaNs', () => {
  const patient = SYNTHETIC_PATIENTS[0];
  const telemetry = generateSyntheticTelemetry(patient, 2, 42); // 2 days
  assert.equal(telemetry.length, (2 * 24 * 60) / 5);

  telemetry.forEach((r, idx) => {
    assert.ok(!isNaN(r.glucose), `Glucose is NaN at index ${idx}`);
    assert.ok(r.glucose >= 40 && r.glucose <= 450, `Glucose out of biological bounds: ${r.glucose}`);
    assert.ok(r.heartRate >= 45 && r.heartRate <= 200, `Heart rate out of biological bounds: ${r.heartRate}`);
    assert.ok(r.steps >= 0, 'Steps must be non-negative');
  });
});

test('extractFeaturesAtTime enforces STRICT zero data leakage', () => {
  const patient = SYNTHETIC_PATIENTS[0];
  const telemetry = generateSyntheticTelemetry(patient, 3, 42);

  // Pick a target index halfway through the series
  const targetIdx = 144; // 12 hours in
  const targetTime = telemetry[targetIdx].timestamp;

  const features = extractFeaturesAtTime(patient, telemetry, targetTime);

  // 1. Current glucose must match the reading at targetTime exactly
  assert.equal(features.currentGlucose, telemetry[targetIdx].glucose);

  // 2. Modify future values in telemetry and verify features DO NOT CHANGE
  const clonedTelemetry = JSON.parse(JSON.stringify(telemetry));
  for (let i = targetIdx + 1; i < clonedTelemetry.length; i++) {
    clonedTelemetry[i].glucose = 999;
    clonedTelemetry[i].steps = 99999;
    clonedTelemetry[i].heartRate = 300;
  }

  const featuresWithCorruptedFuture = extractFeaturesAtTime(patient, clonedTelemetry, targetTime);
  assert.deepEqual(features, featuresWithCorruptedFuture, 'Zero-leakage violated: feature changed when future data changed!');
});

test('predictExcursion returns calibrated probability within [0, 1] and valid trajectory', () => {
  const patient = SYNTHETIC_PATIENTS[0];
  const telemetry = generateSyntheticTelemetry(patient, 2, 42);
  const targetTime = telemetry[50].timestamp;
  const features = extractFeaturesAtTime(patient, telemetry, targetTime);

  const pred = predictExcursion(features, 180);
  assert.ok(pred.predictedProbability >= 0 && pred.predictedProbability <= 1, 'Probability must be in [0, 1]');
  assert.ok(['Low', 'Moderate', 'Elevated', 'Critical'].includes(pred.riskTier));
  assert.equal(pred.trajectory.length, 9, 'Trajectory must have 9 forecast steps (0 to 120 mins)');
  assert.ok(pred.attributions.length >= 5, 'Must provide feature attributions');

  // Verify counterfactual walk glucose is lower than baseline trajectory
  const lastPoint = pred.trajectory[pred.trajectory.length - 1];
  assert.ok(
    lastPoint.counterfactualWalkGlucose! <= lastPoint.projectedGlucose,
    'Physical walk counterfactual should decrease or maintain projected glucose'
  );
});

test('High glucose and rapid positive velocity yield high probability of excursion', () => {
  const highRiskFeatures = {
    age: 58,
    baselineHbA1c: 8.5,
    bmi: 31,
    diagnosisYears: 8,
    medicationPotencyScore: 0.5,
    currentGlucose: 175,
    glucoseDelta15: 18,
    glucoseDelta30: 32,
    glucoseVelocity: 2.1,
    glucoseAcceleration: 0.05,
    glucoseMean60m: 160,
    glucoseStd60m: 24,
    recentSteps60m: 100,
    heartRateElevation: 15,
    sleepDeficitHours: 2.5,
    timeOfDayHour: 20.0
  };

  const pred = predictExcursion(highRiskFeatures, 180);
  assert.ok(pred.predictedProbability > 0.70, `Expected high probability, got ${pred.predictedProbability}`);
  assert.ok(['Elevated', 'Critical'].includes(pred.riskTier));
  assert.equal(pred.willCrossThreshold, true);
});

test('Low glucose and negative velocity yield low probability of excursion', () => {
  const lowRiskFeatures = {
    age: 46,
    baselineHbA1c: 5.8,
    bmi: 24,
    diagnosisYears: 1,
    medicationPotencyScore: 1.0,
    currentGlucose: 105,
    glucoseDelta15: -8,
    glucoseDelta30: -15,
    glucoseVelocity: -0.8,
    glucoseAcceleration: -0.02,
    glucoseMean60m: 112,
    glucoseStd60m: 6,
    recentSteps60m: 3500,
    heartRateElevation: 0,
    sleepDeficitHours: 0,
    timeOfDayHour: 10.0
  };

  const pred = predictExcursion(lowRiskFeatures, 180);
  assert.ok(pred.predictedProbability < 0.20, `Expected low probability, got ${pred.predictedProbability}`);
  assert.equal(pred.riskTier, 'Low');
  assert.equal(pred.willCrossThreshold, false);
});

test('calculateEvaluationMetrics accurately calculates confusion matrix and metrics', () => {
  const mockSamples: EvaluationSample[] = [
    { patientId: 'p1', timestamp: 1, predictedProbability: 0.8, groundTruthLabel: true, actualMaxGlucose: 195, currentGlucose: 160 },
    { patientId: 'p1', timestamp: 2, predictedProbability: 0.7, groundTruthLabel: true, actualMaxGlucose: 188, currentGlucose: 150 },
    { patientId: 'p1', timestamp: 3, predictedProbability: 0.6, groundTruthLabel: false, actualMaxGlucose: 165, currentGlucose: 140 }, // FP
    { patientId: 'p1', timestamp: 4, predictedProbability: 0.2, groundTruthLabel: false, actualMaxGlucose: 130, currentGlucose: 110 },
    { patientId: 'p1', timestamp: 5, predictedProbability: 0.1, groundTruthLabel: false, actualMaxGlucose: 120, currentGlucose: 105 },
    { patientId: 'p1', timestamp: 6, predictedProbability: 0.3, groundTruthLabel: true, actualMaxGlucose: 182, currentGlucose: 135 }, // FN (th=0.5)
  ];

  const metrics = calculateEvaluationMetrics(mockSamples, 0.50);
  assert.equal(metrics.confusionMatrix.truePositives, 2);
  assert.equal(metrics.confusionMatrix.falsePositives, 1);
  assert.equal(metrics.confusionMatrix.trueNegatives, 2);
  assert.equal(metrics.confusionMatrix.falseNegatives, 1);
  assert.equal(metrics.totalEpisodes, 6);
  assert.equal(metrics.accuracy, 0.667);
  assert.ok(metrics.rocAuc !== null && metrics.rocAuc >= 0.0 && metrics.rocAuc <= 1.0);
  assert.equal(metrics.rocAucStatus, 'valid');

  // Edge case: single-class sample where ROC-AUC cannot be calculated
  const singleClassSamples: EvaluationSample[] = [
    { patientId: 'p1', timestamp: 1, predictedProbability: 0.8, groundTruthLabel: true, actualMaxGlucose: 200, currentGlucose: 150 },
    { patientId: 'p1', timestamp: 2, predictedProbability: 0.9, groundTruthLabel: true, actualMaxGlucose: 210, currentGlucose: 160 }
  ];
  const singleClassMetrics = calculateEvaluationMetrics(singleClassSamples, 0.50);
  assert.equal(singleClassMetrics.rocAuc, null);
  assert.equal(singleClassMetrics.rocAucStatus, 'single_class_undefined');
});

test('GLP-1 RA therapy dynamically dampens absorption coefficient and reduces excursion probability', () => {
  const baseFeatures = {
    age: 55,
    baselineHbA1c: 7.8,
    bmi: 30,
    diagnosisYears: 5,
    medicationPotencyScore: 0.6,
    currentGlucose: 165,
    glucoseDelta15: 14,
    glucoseDelta30: 24,
    glucoseVelocity: 1.8,
    glucoseAcceleration: 0.02,
    glucoseMean60m: 155,
    glucoseStd60m: 18,
    recentSteps60m: 300,
    heartRateElevation: 8,
    sleepDeficitHours: 1.0,
    timeOfDayHour: 19.5,
    glp1TherapyActive: false
  };

  const predWithoutGlp1 = predictExcursion(baseFeatures, 180);

  // Activate GLP-1 with standard absorption delay factor (0.65)
  const glp1StandardFeatures = {
    ...baseFeatures,
    glp1TherapyActive: true,
    absorptionDelayFactor: 0.65
  };
  const predWithStandardGlp1 = predictExcursion(glp1StandardFeatures, 180);

  // Activate GLP-1 with high potency absorption delay factor (0.45)
  const glp1PotentFeatures = {
    ...baseFeatures,
    glp1TherapyActive: true,
    absorptionDelayFactor: 0.45
  };
  const predWithPotentGlp1 = predictExcursion(glp1PotentFeatures, 180);

  // GLP-1 must significantly reduce predicted probability and expected peak
  assert.ok(
    predWithStandardGlp1.predictedProbability < predWithoutGlp1.predictedProbability,
    `GLP-1 should lower probability: without=${predWithoutGlp1.predictedProbability}, with=${predWithStandardGlp1.predictedProbability}`
  );
  assert.ok(
    predWithStandardGlp1.expectedPeakGlucose2h < predWithoutGlp1.expectedPeakGlucose2h,
    `GLP-1 should lower expected peak: without=${predWithoutGlp1.expectedPeakGlucose2h}, with=${predWithStandardGlp1.expectedPeakGlucose2h}`
  );

  // More potent absorption delay (0.45 vs 0.65) should further reduce probability and peak
  assert.ok(
    predWithPotentGlp1.predictedProbability <= predWithStandardGlp1.predictedProbability,
    'Lower absorption coefficient (more delay) should further reduce excursion risk'
  );
  assert.ok(
    predWithPotentGlp1.expectedPeakGlucose2h <= predWithStandardGlp1.expectedPeakGlucose2h,
    'Lower absorption coefficient should further reduce projected peak glucose'
  );

  // Check that trajectory includes both counterfactuals
  assert.ok(predWithStandardGlp1.trajectory[4].counterfactualUnmedicatedGlucose !== undefined);
  assert.ok(predWithoutGlp1.trajectory[4].counterfactualGlp1Glucose !== undefined);
});
