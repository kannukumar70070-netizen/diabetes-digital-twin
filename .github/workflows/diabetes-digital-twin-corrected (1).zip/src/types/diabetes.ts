/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Core Type Definitions
 * Happiest Health Digital Twin Challenge 2026
 */

export type DiabetesSubtype = 'Type 2 Diabetes' | 'Prediabetes' | 'LADA' | 'Metabolic Syndrome';

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  complianceRate: number; // 0 - 1.0 (e.g., 0.95 = 95% adherent)
  class: 'Biguanide' | 'SGLT2-i' | 'GLP-1 RA' | 'Sulfonylurea' | 'Basal Insulin' | 'Lifestyle Only';
}

export interface SyntheticPatient {
  id: string;
  name: string;
  age: number;
  gender: 'Female' | 'Male' | 'Non-Binary';
  diagnosis: DiabetesSubtype;
  diagnosisYears: number;
  bmi: number;
  baselineHbA1c: number; // e.g. 7.6%
  targetGlucoseRange: [number, number]; // e.g. [70, 180] mg/dL
  hyperglycemiaThreshold: number; // e.g. 180 mg/dL
  hypoglycemiaThreshold: number; // e.g. 70 mg/dL
  medications: Medication[];
  clinicalNotes: string;
  avatarSeed: string;
  isCustom?: boolean;
}

export interface SensorReading {
  timestamp: number; // Epoch ms
  isoTime: string;
  glucose: number; // mg/dL
  glucoseVelocity: number; // mg/dL per min (rate of change)
  heartRate: number; // bpm
  steps: number; // steps in 5-min epoch
  cumulativeStepsToday: number;
  sleepMinutesPriorNight: number; // minutes
  sleepQualityScore: number; // 0 - 100
  eventMarker?: 'meal' | 'exercise' | 'medication' | 'sleep' | 'stress';
  eventDescription?: string;
}

export interface FeatureVector {
  // Stream A: Static / Clinical priors
  age: number;
  baselineHbA1c: number;
  bmi: number;
  diagnosisYears: number;
  medicationPotencyScore: number;
  
  // Stream B: High-frequency Sensor Features (STRICTLY available at or before t)
  currentGlucose: number;
  glucoseDelta15: number; // G(t) - G(t-15min)
  glucoseDelta30: number; // G(t) - G(t-30min)
  glucoseVelocity: number; // dG/dt (mg/dL/min)
  glucoseAcceleration: number; // d^2G/dt^2
  glucoseMean60m: number; // rolling average last 1 hour
  glucoseStd60m: number; // rolling standard deviation (glycemic variability)
  recentSteps60m: number; // cumulative steps last 1 hour
  heartRateElevation: number; // current HR relative to resting HR
  sleepDeficitHours: number; // 8.0 - sleepHours
  timeOfDayHour: number; // 0 - 23.99 (circadian dawn effect factor)
  glp1TherapyActive?: boolean; // GLP-1 Receptor Agonist active therapy
  absorptionDelayFactor?: number; // Rate-limiting gastric emptying multiplier (0.65 = 35% delayed absorption)
}

export interface FeatureAttribution {
  featureName: string;
  label: string;
  rawValue: string;
  contributionPercent: number; // positive = pushes risk UP, negative = lowers risk
  impact: 'risk_increasing' | 'protective' | 'neutral';
  clinicalInterpretation: string;
}

export interface ForecastPoint {
  timeOffsetMinutes: number; // 0, 15, 30, ..., 120
  projectedGlucose: number;
  lowerConfidence95: number; // Heuristic dispersion lower bound (expanding delta with variability; not a parametric 95% CI)
  upperConfidence95: number; // Heuristic dispersion upper bound (expanding delta with variability; not a parametric 95% CI)
  counterfactualWalkGlucose?: number; // trajectory if 15-min walk taken
  counterfactualRestGlucose?: number; // trajectory if resting
  counterfactualGlp1Glucose?: number; // trajectory with GLP-1 RA therapy dampening
  counterfactualUnmedicatedGlucose?: number; // trajectory without GLP-1 RA therapy dampening (unattenuated)
}

export interface PredictionResult {
  timestamp: number;
  predictedProbability: number; // 0.0 - 1.0 (Probability of crossing threshold in next 2h)
  decisionThreshold: number; // default 0.50
  willCrossThreshold: boolean; // predictedProbability >= decisionThreshold
  riskTier: 'Low' | 'Moderate' | 'Elevated' | 'Critical';
  expectedPeakGlucose2h: number; // mg/dL
  estimatedMinutesToThreshold: number | null; // e.g., 42 mins or null if low risk
  attributions: FeatureAttribution[];
  trajectory: ForecastPoint[];
  groundTruthLabel?: boolean; // Actual outcome from future 2-hour window (only for historical evaluation)
}

export interface PredictionHistoryRecord {
  id: string;
  predictionTimestamp: number;
  isoTime: string;
  currentGlucoseAtPrediction: number;
  predictedProbability: number;
  riskTier: 'Low' | 'Moderate' | 'Elevated' | 'Critical';
  thresholdUsed: number;
  actualMaxGlucoseNext2h: number;
  actualGroundTruthLabel: boolean; // Did it actually cross threshold?
  predictionCorrect: boolean;
  notes: string;
}

export interface ConfusionMatrix {
  truePositives: number;
  falsePositives: number;
  trueNegatives: number;
  falseNegatives: number;
  total: number;
}

export interface ModelEvaluationMetrics {
  totalEpisodes: number;
  positivePrevalence: number;
  accuracy: number;
  sensitivity: number; // Recall / True Positive Rate
  specificity: number; // True Negative Rate
  precision: number; // Positive Predictive Value
  negativePredictiveValue: number;
  f1Score: number;
  rocAuc: number | null; // null if evaluation set has only single class (cannot compute AUC)
  rocAucStatus?: 'valid' | 'single_class_undefined';
  brierScore: number;
  confusionMatrix: ConfusionMatrix;
  rocCurvePoints: { fpr: number; tpr: number; threshold: number }[];
  calibrationPoints: { meanPredicted: number; observedFrequency: number; count: number }[];
}

export interface ToastAlert {
  id: string;
  timestamp: number;
  type: 'critical_excursion' | 'elevated_warning' | 'info' | 'success';
  title: string;
  message: string;
  patientName: string;
  patientId: string;
  probability: number;
  riskTier: 'Low' | 'Moderate' | 'Elevated' | 'Critical';
  predictedPeak: number;
  minutesToThreshold: number | null;
  threshold: number;
  actionType?: 'open_simulator_walk' | 'open_dossier';
  actionLabel?: string;
  isRead?: boolean;
}

export type ActiveTab = 'overview' | 'simulator' | 'clinical_dossier' | 'evaluation' | 'methodology' | '3d_twin';
