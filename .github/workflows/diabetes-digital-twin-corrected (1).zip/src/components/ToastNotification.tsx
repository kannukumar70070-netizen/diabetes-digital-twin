/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Toast Notification System
 * Professional healthcare SaaS alerts for forecasted 2-hour glucose excursions
 */

import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Flame,
  CheckCircle2,
  X,
  Clock,
  TrendingUp,
  Footprints,
  FileText,
  Volume2,
  VolumeX,
  Bell
} from 'lucide-react';
import type { ToastAlert } from '../types/diabetes';

interface ToastNotificationProps {
  toasts: ToastAlert[];
  onDismiss: (id: string) => void;
  onAction: (toast: ToastAlert) => void;
  onSnooze: (id: string) => void;
}

export const ToastNotificationContainer: React.FC<ToastNotificationProps> = ({
  toasts,
  onDismiss,
  onAction,
  onSnooze
}) => {
  return (
    <div
      aria-live="polite"
      className="fixed top-20 right-4 sm:right-6 z-50 flex flex-col gap-3 max-w-md w-full pointer-events-none"
    >
      {toasts.map(toast => (
        <ToastItem
          key={toast.id}
          toast={toast}
          onDismiss={() => onDismiss(toast.id)}
          onAction={() => onAction(toast)}
          onSnooze={() => onSnooze(toast.id)}
        />
      ))}
    </div>
  );
};

interface ToastItemProps {
  toast: ToastAlert;
  onDismiss: () => void;
  onAction: () => void;
  onSnooze: () => void;
}

const ToastItem: React.FC<ToastItemProps> = ({
  toast,
  onDismiss,
  onAction,
  onSnooze
}) => {
  const [progress, setProgress] = useState(100);
  const [isPaused, setIsPaused] = useState(false);
  const durationMs = 12000; // 12 seconds auto-close

  useEffect(() => {
    if (isPaused) return;
    const interval = 100;
    const step = (interval / durationMs) * 100;

    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          onDismiss();
          return 0;
        }
        return prev - step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [isPaused, onDismiss]);

  const isCritical = toast.type === 'critical_excursion' || toast.riskTier === 'Critical';
  const isElevated = toast.type === 'elevated_warning' || toast.riskTier === 'Elevated';

  return (
    <div
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className={`pointer-events-auto rounded-2xl bg-white border shadow-xl transition-all duration-300 transform translate-y-0 overflow-hidden relative ${
        isCritical
          ? 'border-rose-300 shadow-rose-950/10'
          : isElevated
          ? 'border-amber-300 shadow-amber-950/10'
          : 'border-slate-200 shadow-slate-900/10'
      }`}
    >
      {/* Top Banner Stripe */}
      <div
        className={`px-4 py-2 flex items-center justify-between text-xs font-semibold ${
          isCritical
            ? 'bg-rose-500 text-white'
            : isElevated
            ? 'bg-amber-500 text-white'
            : 'bg-teal-600 text-white'
        }`}
      >
        <div className="flex items-center gap-1.5">
          {isCritical ? (
            <Flame className="w-4 h-4 text-rose-100 animate-bounce" />
          ) : isElevated ? (
            <AlertTriangle className="w-4 h-4 text-amber-100" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-teal-100" />
          )}
          <span className="uppercase tracking-wider text-[11px] font-bold">
            {toast.title}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] opacity-90 font-mono">
            {new Date(toast.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Dismiss Alert"
            className="p-0.5 rounded-md hover:bg-black/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Toast Body */}
      <div className="p-4 space-y-3">
        {/* Patient & Forecast Callout */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-slate-900">{toast.patientName}</span>
              <span className="text-[10px] text-slate-400 font-mono">({toast.patientId})</span>
            </div>
            <p className="text-xs text-slate-600 mt-1 leading-snug">
              {toast.message}
            </p>
          </div>

          <div className="text-right shrink-0">
            <span
              className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                isCritical
                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                  : 'bg-amber-100 text-amber-800 border border-amber-200'
              }`}
            >
              {Math.round(toast.probability * 100)}% Risk
            </span>
          </div>
        </div>

        {/* Forecast Metrics Strip */}
        <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-3.5 h-3.5 text-teal-600 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block leading-tight">Projected Peak (+2h)</span>
              <span className="font-bold text-slate-900 font-mono">
                {toast.predictedPeak} mg/dL
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block leading-tight">Crossing Horizon</span>
              <span className="font-bold text-slate-900 font-mono">
                {toast.minutesToThreshold !== null
                  ? toast.minutesToThreshold === 0
                    ? 'Already Crossed'
                    : `In ~${toast.minutesToThreshold} mins`
                  : 'Borderline'}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <button
            type="button"
            onClick={onAction}
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 transition-colors shadow-2xs cursor-pointer"
          >
            <Footprints className="w-3.5 h-3.5" />
            <span>Test 15-Min Walk in What-If</span>
          </button>

          <button
            type="button"
            onClick={onSnooze}
            className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Snooze 15m
          </button>
        </div>
      </div>

      {/* Countdown Progress Bar */}
      <div className="w-full bg-slate-100 h-1 overflow-hidden">
        <div
          className={`h-full transition-all duration-100 ease-linear ${
            isCritical ? 'bg-rose-500' : isElevated ? 'bg-amber-500' : 'bg-teal-500'
          }`}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};
