/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  Sliders,
  Sparkles,
  RotateCcw,
  Footprints,
  Coffee,
  Zap,
  TrendingUp,
  Activity,
  Heart,
  Moon,
  ShieldCheck,
  AlertCircle,
  Pill,
  CheckCircle2,
  SlidersHorizontal
} from 'lucide-react';
import type { SyntheticPatient, FeatureVector } from '../types/diabetes';
import { predictExcursion } from '../ml/twinPredictor';

interface InteractiveSimulatorProps {
  patient: SyntheticPatient;
  baseFeatures: FeatureVector;
  threshold: number;
  onUpdateThreshold: (newTh: number) => void;
}

export const InteractiveSimulator: React.FC<InteractiveSimulatorProps> = ({
  patient,
  baseFeatures,
  threshold,
  onUpdateThreshold
}) => {
  // Check if patient baseline indicates GLP-1 RA prescription
  const initialHasGlp1 = baseFeatures.glp1TherapyActive ?? patient.medications.some(m => m.class === 'GLP-1 RA');

  // Simulator state initialized from current patient features
  const [currentGlucose, setCurrentGlucose] = useState<number>(baseFeatures.currentGlucose);
  const [glucoseVelocity, setGlucoseVelocity] = useState<number>(baseFeatures.glucoseVelocity);
  const [recentSteps, setRecentSteps] = useState<number>(baseFeatures.recentSteps60m);
  const [heartRateElevation, setHeartRateElevation] = useState<number>(baseFeatures.heartRateElevation);
  const [sleepDeficit, setSleepDeficit] = useState<number>(baseFeatures.sleepDeficitHours);
  const [baselineHbA1c, setBaselineHbA1c] = useState<number>(patient.baselineHbA1c);
  const [bmi, setBmi] = useState<number>(patient.bmi);

  // GLP-1 Receptor Agonist Pharmacotherapy state & Absorption coefficient
  const [glp1Active, setGlp1Active] = useState<boolean>(initialHasGlp1);
  const [absorptionDelayFactor, setAbsorptionDelayFactor] = useState<number>(
    baseFeatures.absorptionDelayFactor ?? 0.65
  );

  // Active scenario badge
  const [activeScenario, setActiveScenario] = useState<string>('Custom / Current');

  // Synchronize when patient or base features change
  useEffect(() => {
    const ptHasGlp1 = baseFeatures.glp1TherapyActive ?? patient.medications.some(m => m.class === 'GLP-1 RA');
    setCurrentGlucose(baseFeatures.currentGlucose);
    setGlucoseVelocity(baseFeatures.glucoseVelocity);
    setRecentSteps(baseFeatures.recentSteps60m);
    setHeartRateElevation(baseFeatures.heartRateElevation);
    setSleepDeficit(baseFeatures.sleepDeficitHours);
    setBaselineHbA1c(patient.baselineHbA1c);
    setBmi(patient.bmi);
    setGlp1Active(ptHasGlp1);
    setAbsorptionDelayFactor(baseFeatures.absorptionDelayFactor ?? 0.65);
    setActiveScenario('Current Patient State');
  }, [patient, baseFeatures]);

  // Compute live prediction based on interactive controls and GLP-1 therapy state
  const simulatedFeatures: FeatureVector = useMemo(() => {
    return {
      ...baseFeatures,
      currentGlucose,
      glucoseVelocity,
      glucoseDelta15: glucoseVelocity * 15,
      glucoseDelta30: glucoseVelocity * 30,
      recentSteps60m: recentSteps,
      heartRateElevation,
      sleepDeficitHours: sleepDeficit,
      baselineHbA1c,
      bmi,
      glp1TherapyActive: glp1Active,
      absorptionDelayFactor: glp1Active ? absorptionDelayFactor : 1.0,
    };
  }, [
    baseFeatures,
    currentGlucose,
    glucoseVelocity,
    recentSteps,
    heartRateElevation,
    sleepDeficit,
    baselineHbA1c,
    bmi,
    glp1Active,
    absorptionDelayFactor
  ]);

  const livePrediction = useMemo(() => {
    return predictExcursion(simulatedFeatures, threshold);
  }, [simulatedFeatures, threshold]);

  // Reset to live patient sensor telemetry
  const handleReset = () => {
    const ptHasGlp1 = baseFeatures.glp1TherapyActive ?? patient.medications.some(m => m.class === 'GLP-1 RA');
    setCurrentGlucose(baseFeatures.currentGlucose);
    setGlucoseVelocity(baseFeatures.glucoseVelocity);
    setRecentSteps(baseFeatures.recentSteps60m);
    setHeartRateElevation(baseFeatures.heartRateElevation);
    setSleepDeficit(baseFeatures.sleepDeficitHours);
    setBaselineHbA1c(patient.baselineHbA1c);
    setBmi(patient.bmi);
    setGlp1Active(ptHasGlp1);
    setAbsorptionDelayFactor(baseFeatures.absorptionDelayFactor ?? 0.65);
    setActiveScenario('Reset to Current Telemetry');
  };

  // Scenario Presets
  const applyScenario = (name: string, overrides: Partial<{
    glucose: number;
    velocity: number;
    steps: number;
    hrElev: number;
    sleepDef: number;
    glp1: boolean;
    absorption: number;
  }>) => {
    if (overrides.glucose !== undefined) setCurrentGlucose(overrides.glucose);
    if (overrides.velocity !== undefined) setGlucoseVelocity(overrides.velocity);
    if (overrides.steps !== undefined) setRecentSteps(overrides.steps);
    if (overrides.hrElev !== undefined) setHeartRateElevation(overrides.hrElev);
    if (overrides.sleepDef !== undefined) setSleepDeficit(overrides.sleepDef);
    if (overrides.glp1 !== undefined) setGlp1Active(overrides.glp1);
    if (overrides.absorption !== undefined) setAbsorptionDelayFactor(overrides.absorption);
    setActiveScenario(name);
  };

  // Risk styling
  const probPct = Math.round(livePrediction.predictedProbability * 100);
  const isHigh = livePrediction.riskTier === 'Critical' || livePrediction.riskTier === 'Elevated';

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
                <Sliders className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                Digital Twin What-If Simulator & Counterfactual Testing
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Adjust patient telemetry, GLP-1 pharmacotherapy, and absorption kinetics in real-time to observe the Digital Twin model forecast
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Telemetry</span>
            </button>
          </div>
        </div>

        {/* Quick Counterfactual Scenario Buttons */}
        <div className="pt-4">
          <span className="text-xs font-semibold text-slate-600 block mb-2">
            One-Click Counterfactual Interventions:
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() =>
                applyScenario('15-Min Brisk Post-Meal Walk', {
                  steps: 1800,
                  velocity: Math.max(-1.5, glucoseVelocity - 1.2),
                  hrElev: 18
                })
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <Footprints className="w-3.5 h-3.5 text-emerald-600" />
              <span>Simulate 15-Min Brisk Walk (+1,800 steps)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                applyScenario('Postprandial Refined Carb Influx', {
                  glucose: Math.min(260, currentGlucose + 25),
                  velocity: 2.2,
                  steps: 150
                })
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 transition-colors cursor-pointer"
            >
              <Coffee className="w-3.5 h-3.5 text-amber-600" />
              <span>Simulate 50g High-GI Carbohydrate (Surge)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                applyScenario('GLP-1 RA Therapy Activated (Semaglutide 1.0mg)', {
                  glp1: true,
                  absorption: 0.65
                })
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-teal-50 text-teal-800 border border-teal-200 hover:bg-teal-100 transition-colors cursor-pointer"
            >
              <Pill className="w-3.5 h-3.5 text-teal-600" />
              <span>Simulate GLP-1 RA Therapy (Semaglutide 1.0mg)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                applyScenario('Sedentary Acute Stress & Poor Sleep', {
                  steps: 40,
                  hrElev: 22,
                  sleepDef: 3.5,
                  velocity: 1.4
                })
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-rose-600" />
              <span>Simulate Acute Work Stress & Sleep Debt</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Controls / Right Live Twin Forecast Response */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Telemetry Sliders & GLP-1 RA Panel (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* GLP-1 Receptor Agonist Pharmacotherapy Panel */}
          <div className={`rounded-2xl border transition-all p-5 ${
            glp1Active
              ? 'bg-gradient-to-br from-teal-50/90 via-cyan-50/50 to-indigo-50/30 border-teal-300 shadow-xs'
              : 'bg-white border-slate-200/90 shadow-xs'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3.5 border-b border-slate-200/80 gap-3">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  glp1Active ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}>
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">
                      GLP-1 Receptor Agonist (GLP-1 RA) Incretin Therapy
                    </h3>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      glp1Active
                        ? 'bg-teal-100 text-teal-800 border border-teal-300'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {glp1Active ? 'Active in Twin Model' : 'Inactive'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Incretin mimetic (Semaglutide / Tirzepatide): delays gastric emptying, attenuates postprandial glucose absorption flux, and restores insulin secretion
                  </p>
                </div>
              </div>

              {/* Interactive Toggle Switch */}
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <label htmlFor="glp1-toggle-button" className="text-xs font-semibold text-slate-700 cursor-pointer select-none">
                  {glp1Active ? 'Therapy Enabled' : 'Therapy Disabled'}
                </label>
                <button
                  id="glp1-toggle-button"
                  role="switch"
                  aria-checked={glp1Active}
                  type="button"
                  onClick={() => {
                    const nextState = !glp1Active;
                    setGlp1Active(nextState);
                    setActiveScenario(nextState ? 'GLP-1 RA Therapy Activated' : 'GLP-1 RA Therapy Discontinued');
                  }}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                    glp1Active ? 'bg-teal-600' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                      glp1Active ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Dynamic Absorption Coefficient Controls when GLP-1 is enabled */}
            {glp1Active ? (
              <div className="mt-4 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1">
                  <div>
                    <label htmlFor="absorption-coefficient-slider" className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <SlidersHorizontal className="w-3.5 h-3.5 text-teal-600" />
                      <span>Predictive Glucose Absorption Coefficient (k<sub>abs</sub> multiplier)</span>
                    </label>
                    <span className="text-[11px] text-slate-500 block">
                      Directly scales velocity (dG/dt) and 15/30-min appearance flux in the digital twin kinetics
                    </span>
                  </div>
                  <span className="font-mono font-bold text-xs text-teal-800 bg-white px-2 py-0.5 rounded border border-teal-200 shadow-2xs self-start sm:self-center">
                    {absorptionDelayFactor.toFixed(2)}x (-{Math.round((1 - absorptionDelayFactor) * 100)}% flux)
                  </span>
                </div>

                <input
                  id="absorption-coefficient-slider"
                  type="range"
                  min="0.40"
                  max="0.90"
                  step="0.05"
                  value={absorptionDelayFactor}
                  onChange={(e) => {
                    setAbsorptionDelayFactor(Number(e.target.value));
                    setActiveScenario(`GLP-1 Absorption Coeff Adjusted (${Number(e.target.value).toFixed(2)}x)`);
                  }}
                  className="w-full h-2 bg-teal-200/80 rounded-lg appearance-none cursor-pointer accent-teal-600"
                />

                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>0.40x (Max Dampening / Tirzepatide 15mg)</span>
                  <span className="font-bold text-teal-700">0.65x (Semaglutide 1.0mg Maintenance)</span>
                  <span>0.90x (Mild / 0.25mg Dose)</span>
                </div>

                {/* Real-time Physiological Kinetics Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                  <div className="bg-white/80 rounded-xl p-2.5 border border-teal-100 text-xs shadow-2xs">
                    <span className="text-slate-500 block text-[11px]">Unmodulated CGM Slope</span>
                    <span className="font-mono font-bold text-slate-800">
                      {glucoseVelocity > 0 ? '+' : ''}{glucoseVelocity.toFixed(2)} mg/dL/min
                    </span>
                  </div>
                  <div className="bg-white/80 rounded-xl p-2.5 border border-teal-100 text-xs shadow-2xs">
                    <span className="text-teal-700 font-medium block text-[11px]">Effective Digital Twin Velocity</span>
                    <span className="font-mono font-bold text-teal-800">
                      {(glucoseVelocity * absorptionDelayFactor) > 0 ? '+' : ''}
                      {(glucoseVelocity * absorptionDelayFactor).toFixed(2)} mg/dL/min
                    </span>
                  </div>
                  <div className="bg-white/80 rounded-xl p-2.5 border border-teal-100 text-xs shadow-2xs">
                    <span className="text-emerald-700 font-medium block text-[11px]">Absorption Attenuation</span>
                    <span className="font-mono font-bold text-emerald-700">
                      -{Math.round((1 - absorptionDelayFactor) * 100)}% meal carb surge
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-3 text-xs text-slate-500 flex items-center justify-between">
                <span>Model operates with <strong>1.00x unattenuated gastric emptying rate</strong>.</span>
                <button
                  type="button"
                  onClick={() => {
                    setGlp1Active(true);
                    setAbsorptionDelayFactor(0.65);
                    setActiveScenario('GLP-1 RA Therapy Activated');
                  }}
                  className="text-teal-600 hover:text-teal-700 font-semibold cursor-pointer underline text-[11px]"
                >
                  Turn ON GLP-1 Therapy
                </button>
              </div>
            )}
          </div>

          {/* Sensor Telemetry Sliders Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">
                Continuous Multi-Sensor Parameters
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Mode: {activeScenario}
              </span>
            </div>

            {/* Slider 1: Current Glucose */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="current-glucose-slider" className="font-semibold text-slate-700">Current CGM Glucose (mg/dL)</label>
                <span className="font-mono font-bold text-sm text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                  {currentGlucose} mg/dL
                </span>
              </div>
              <input
                id="current-glucose-slider"
                type="range"
                min="70"
                max="280"
                step="1"
                value={currentGlucose}
                onChange={(e) => {
                  setCurrentGlucose(Number(e.target.value));
                  setActiveScenario('Custom Parameter Adjustment');
                }}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>70 (Target Lower)</span>
                <span>130 (Normoglycemic)</span>
                <span>180 (Threshold)</span>
                <span>280 (Severe Hyper)</span>
              </div>
            </div>

            {/* Slider 2: Glucose Velocity (dG/dt) */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="glucose-velocity-slider" className="font-semibold text-slate-700">Glycemic Velocity (dG/dt rate of change)</label>
                <span className="font-mono font-bold text-sm text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  {glucoseVelocity > 0 ? '+' : ''}{glucoseVelocity.toFixed(2)} mg/dL/min
                </span>
              </div>
              <input
                id="glucose-velocity-slider"
                type="range"
                min="-3.0"
                max="3.5"
                step="0.1"
                value={glucoseVelocity}
                onChange={(e) => {
                  setGlucoseVelocity(Number(e.target.value));
                  setActiveScenario('Custom Parameter Adjustment');
                }}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>-3.0 (Fast Drop)</span>
                <span>0.0 (Steady)</span>
                <span>+1.5 (Rising)</span>
                <span>+3.5 (Surging)</span>
              </div>
            </div>

            {/* Slider 3: Recent Steps (60 min) */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="recent-steps-slider" className="font-semibold text-slate-700">Recent Physical Activity (Steps last 60m)</label>
                <span className="font-mono font-bold text-sm text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                  {recentSteps.toLocaleString()} steps
                </span>
              </div>
              <input
                id="recent-steps-slider"
                type="range"
                min="0"
                max="5000"
                step="100"
                value={recentSteps}
                onChange={(e) => {
                  setRecentSteps(Number(e.target.value));
                  setActiveScenario('Custom Parameter Adjustment');
                }}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>0 (Sedentary Desk)</span>
                <span>1,200 (Active Walk)</span>
                <span>3,500 (Brisk Exercise)</span>
                <span>5,000+</span>
              </div>
            </div>

            {/* Slider 4: Heart Rate Elevation */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="heart-rate-slider" className="font-semibold text-slate-700">Heart Rate Elevation above Resting (bpm)</label>
                <span className="font-mono font-bold text-sm text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  {heartRateElevation >= 0 ? '+' : ''}{heartRateElevation} bpm
                </span>
              </div>
              <input
                id="heart-rate-slider"
                type="range"
                min="-10"
                max="45"
                step="1"
                value={heartRateElevation}
                onChange={(e) => {
                  setHeartRateElevation(Number(e.target.value));
                  setActiveScenario('Custom Parameter Adjustment');
                }}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>-10 (Deep Sleep)</span>
                <span>0 (Resting Baseline)</span>
                <span>+20 (Sympathetic Exertion)</span>
                <span>+45 (High Stress)</span>
              </div>
            </div>

            {/* Slider 5: Sleep Debt */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="sleep-debt-slider" className="font-semibold text-slate-700">Sleep Debt Prior Night (Hours)</label>
                <span className="font-mono font-bold text-sm text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  {sleepDeficit.toFixed(1)} hrs deficit
                </span>
              </div>
              <input
                id="sleep-debt-slider"
                type="range"
                min="0"
                max="4.0"
                step="0.5"
                value={sleepDeficit}
                onChange={(e) => {
                  setSleepDeficit(Number(e.target.value));
                  setActiveScenario('Custom Parameter Adjustment');
                }}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>0 (Full 8h Sleep)</span>
                <span>1.5h (Mild Loss)</span>
                <span>3.0h (Chronic Debt)</span>
                <span>4.0h (Severe Insomnia)</span>
              </div>
            </div>

            {/* Hyperglycemia Threshold Control */}
            <div className="pt-2 border-t border-slate-100">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <label htmlFor="threshold-slider" className="font-semibold text-slate-900">
                  Defined Prediction Target Threshold (mg/dL)
                </label>
                <span className="font-mono font-bold text-sm text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  &gt;{threshold} mg/dL
                </span>
              </div>
              <input
                id="threshold-slider"
                type="range"
                min="140"
                max="220"
                step="5"
                value={threshold}
                onChange={(e) => onUpdateThreshold(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                <span>140 (Tight Control)</span>
                <span>160 (Prediabetes)</span>
                <span>180 (Clinical Standard ADA)</span>
                <span>220 (High Threshold)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic Digital Twin Output & Trajectory (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Live Probability Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Twin ML Live Inference
                </span>
                {glp1Active && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200">
                    GLP-1 Dampened
                  </span>
                )}
              </div>
              <span
                className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                  isHigh ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {livePrediction.riskTier} Risk
              </span>
            </div>

            <div className="my-4 flex items-center justify-between">
              <div>
                <span className="text-4xl font-extrabold text-slate-900 font-mono tracking-tight">
                  {probPct}%
                </span>
                <p className="text-xs text-slate-500 mt-0.5">
                  Probability of crossing &gt;{threshold} mg/dL in next 2h
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs font-semibold text-slate-500 block">Peak Forecast</span>
                <span className="text-2xl font-bold font-mono text-slate-800">
                  {livePrediction.expectedPeakGlucose2h} <span className="text-xs font-normal">mg/dL</span>
                </span>
              </div>
            </div>

            {/* Time to threshold */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 flex items-center justify-between">
              <span>Estimated crossing horizon:</span>
              <span className="font-bold text-slate-900 font-mono">
                {livePrediction.estimatedMinutesToThreshold !== null
                  ? livePrediction.estimatedMinutesToThreshold === 0
                    ? 'Already &gt; Threshold'
                    : `~${livePrediction.estimatedMinutesToThreshold} minutes`
                  : 'No crossing expected'}
              </span>
            </div>
          </div>

          {/* Forward 2-Hour Trajectory Chart */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-teal-600" />
                Forward Trajectory Simulation (+120m)
              </h4>
            </div>

            {/* Trajectory comparison curve SVG */}
            <div className="w-full">
              <svg viewBox="0 0 320 160" className="w-full h-auto overflow-visible">
                {/* Threshold line */}
                {(() => {
                  const minY = 60;
                  const maxY = 280;
                  const thY = 140 - ((threshold - minY) / (maxY - minY)) * 120;
                  return (
                    <g>
                      <line
                        x1="20"
                        y1={thY}
                        x2="310"
                        y2={thY}
                        stroke="#f59e0b"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                      />
                      <text x="312" y={thY + 3} className="text-[9px] fill-amber-700 font-bold font-mono">
                        {threshold}
                      </text>
                    </g>
                  );
                })()}

                {/* Trajectory lines */}
                {(() => {
                  const minY = 60;
                  const maxY = 280;
                  const getYCoord = (val: number) => 140 - ((val - minY) / (maxY - minY)) * 120;
                  const getXCoord = (dt: number) => 25 + (dt / 120) * 270;

                  // Baseline path
                  const baselineD = livePrediction.trajectory.reduce((acc, pt, i) => {
                    const x = getXCoord(pt.timeOffsetMinutes);
                    const y = getYCoord(pt.projectedGlucose);
                    return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
                  }, '');

                  // Walk Counterfactual path
                  const walkD = livePrediction.trajectory.reduce((acc, pt, i) => {
                    const x = getXCoord(pt.timeOffsetMinutes);
                    const y = getYCoord(pt.counterfactualWalkGlucose || pt.projectedGlucose);
                    return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
                  }, '');

                  // Counterfactual line: if GLP-1 active, show unmedicated; if inactive, show with GLP-1
                  const counterD = livePrediction.trajectory.reduce((acc, pt, i) => {
                    const x = getXCoord(pt.timeOffsetMinutes);
                    const yVal = glp1Active
                      ? (pt.counterfactualUnmedicatedGlucose || pt.projectedGlucose)
                      : (pt.counterfactualGlp1Glucose || pt.projectedGlucose);
                    const y = getYCoord(yVal);
                    return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
                  }, '');

                  return (
                    <g>
                      {/* Counterfactual curve (Unmedicated if GLP-1 is on, or GLP-1 if it's off) */}
                      <path
                        d={counterD}
                        fill="none"
                        stroke={glp1Active ? '#f43f5e' : '#8b5cf6'}
                        strokeWidth="1.8"
                        strokeDasharray="3 2"
                      />

                      {/* Walk line */}
                      <path
                        d={walkD}
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="2"
                        strokeDasharray="2 2"
                      />

                      {/* Active Digital Twin Forecast Line */}
                      <path
                        d={baselineD}
                        fill="none"
                        stroke="#0d9488"
                        strokeWidth="2.5"
                      />
                      {livePrediction.trajectory.map((pt, i) => (
                        <circle
                          key={i}
                          cx={getXCoord(pt.timeOffsetMinutes)}
                          cy={getYCoord(pt.projectedGlucose)}
                          r={i === 0 || i === livePrediction.trajectory.length - 1 ? '3.5' : '2'}
                          fill="#0d9488"
                        />
                      ))}
                    </g>
                  );
                })()}

                {/* X axis labels */}
                <text x="25" y="155" className="text-[9px] fill-slate-400">Now (0m)</text>
                <text x="160" y="155" textAnchor="middle" className="text-[9px] fill-slate-400">+60m</text>
                <text x="295" y="155" textAnchor="end" className="text-[9px] fill-slate-400">+120m</text>
              </svg>
            </div>

            {/* Trajectory Legend */}
            <div className="space-y-1.5 text-[11px] text-slate-500 pt-3 border-t border-slate-100 mt-2">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-3.5 h-1 bg-teal-600 rounded-sm"></span>
                  <span className="font-medium text-slate-700">
                    Twin Forecast {glp1Active ? `(GLP-1 ${absorptionDelayFactor.toFixed(2)}x)` : '(Standard)'}
                  </span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3.5 h-0.5 border-t-2 border-dashed border-emerald-500"></span>
                  <span>15m Walk Counterfactual</span>
                </span>
              </div>
              <div className="flex items-center">
                <span className="flex items-center gap-1.5">
                  <span className={`w-3.5 h-0.5 border-t-2 border-dashed ${glp1Active ? 'border-rose-500' : 'border-purple-500'}`}></span>
                  <span>
                    {glp1Active
                      ? 'Without GLP-1 Counterfactual (Unattenuated Spike)'
                      : 'With GLP-1 RA Counterfactual (-35% Absorption)'}
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
