/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  BookOpen,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity,
  Heart,
  Footprints,
  Pill,
  Clock,
  Sparkles,
  GitBranch,
  FileCode2,
  Database,
  Lock
} from 'lucide-react';

export const MethodologyView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900">
                Data Architecture & Machine Learning Methodology
              </h2>
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-teal-50 text-teal-700 border border-teal-200">
                Zero-Leakage Framework
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Technical specification of dual data stream fusion and physiological digital twin forecasting
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-600 mt-3 leading-relaxed">
          The <strong>Diabetes Digital Twin</strong> is designed to solve the critical clinical challenge of anticipating acute postprandial and circadian glycemic excursions before they manifest. Conventional CGM alerts trigger reactively only <em>after</em> a patient crosses a threshold. In contrast, this digital twin combines static clinical priors with dynamic multi-sensor telemetry to forecast excursions <strong>2 hours in advance</strong>, enabling non-pharmacological preemptive action (e.g. a 15-minute brisk walk or hydration).
        </p>
      </div>

      {/* Dual Data Streams Visual Architecture Diagram */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-teal-600" />
          Dual Data Stream Fusion Architecture
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch">
          {/* Stream A: Static Clinical Priors */}
          <div className="md:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800">
                  STREAM A
                </span>
                <h4 className="text-xs font-bold text-slate-900">
                  Static EHR & Clinical Priors
                </h4>
              </div>
              <p className="text-[11px] text-slate-500 mb-3">
                Long-term clinical baseline parameters establishing physiological resistance and pharmacotherapy:
              </p>
              <ul className="space-y-1.5 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  <span><strong>Baseline HbA1c (%):</strong> Chronic glycemia prior</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  <span><strong>BMI & Age:</strong> Peripheral insulin resistance</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  <span><strong>Diabetes Duration:</strong> Beta-cell reserve index</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                  <span><strong>Pharmacotherapy Potency:</strong> SGLT2i, GLP-1, Metformin</span>
                </li>
              </ul>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-200 text-[10px] text-slate-500 font-mono">
              Frequency: Static / Periodic Updates
            </div>
          </div>

          {/* Fusion Bridge */}
          <div className="md:col-span-2 flex flex-col items-center justify-center py-2">
            <div className="w-8 h-8 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-md">
              +
            </div>
            <span className="text-[11px] font-bold text-slate-700 mt-2 text-center">
              Temporal Alignment & Feature Extraction
            </span>
            <span className="text-[10px] text-emerald-600 font-semibold text-center mt-1">
              Strictly t' ≤ t
            </span>
          </div>

          {/* Stream B: High-Frequency Sensor Telemetry */}
          <div className="md:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                  STREAM B
                </span>
                <h4 className="text-xs font-bold text-slate-900">
                  High-Frequency Multi-Sensor Telemetry
                </h4>
              </div>
              <p className="text-[11px] text-slate-500 mb-3">
                Continuous physiological time-series streaming from wearable devices:
              </p>
              <ul className="space-y-1.5 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  <span><strong>Continuous Glucose Monitor:</strong> 5-min interstitial CGM</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  <span><strong>Optical PPG Heart Rate:</strong> Sympathetic stress & arousal</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  <span><strong>Accelerometer Steps:</strong> Non-insulin GLUT4 clearance sink</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  <span><strong>Wearable Sleep Staging:</strong> Nocturnal insulin sensitivity factor</span>
                </li>
              </ul>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-200 text-[10px] text-slate-500 font-mono">
              Frequency: 5-minute sampling interval
            </div>
          </div>
        </div>
      </div>

      {/* Zero Data Leakage & Feature Pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Lock className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Zero Data Leakage Architecture
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            In medical time-series forecasting, <strong>data leakage</strong> is a rampant flaw where future timestamps or forward centered rolling statistics are erroneously introduced into the model input.
          </p>
          <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-950 font-mono space-y-1">
            <p className="font-bold">// Rigorous Invariant Guarantee:</p>
            <p>For all features f in FeatureVector(t):</p>
            <p className="pl-4 font-semibold text-emerald-800">timestamp(f) ≤ t</p>
            <p className="font-bold mt-1.5">// Evaluation Target Horizon:</p>
            <p className="pl-4 font-semibold text-emerald-800">Target Window = (t, t + 120min]</p>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            All rolling averages (Mean 60m), glycemic variability (SD 60m), rate of change (velocity dG/dt), and step accumulations are strictly backward-looking.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <GitBranch className="w-4 h-4 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Prediction Target Formal Definition
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            The prediction target is formulated as a binary classification with calibrated probability estimation:
          </p>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-mono space-y-1 text-center">
            <p className="text-sm font-bold text-teal-800">
              Y(t) = 1 &nbsp;&hArr;&nbsp; max &#123; G(t') | t &lt; t' &le; t + 120m &#125; &gt; &theta;
            </p>
            <p className="text-[11px] text-slate-500 font-sans mt-1">
              Where &theta; is the defined clinical threshold (default: 180 mg/dL).
            </p>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            The model estimates <strong className="font-mono text-teal-700">P(Y(t) = 1 | X(t))</strong> using an expert-parameterized rule-based multivariable logistic scoring model with physiological minimal model kinetic priors and explainable local attributions for clinical interpretability:
          </p>
          <ul className="text-xs text-slate-600 space-y-1 list-disc pl-4">
            <li><strong>Model Architecture:</strong> Expert-parameterized rule-based multivariable logistic scoring model with coefficients derived from physiological minimal model kinetics and multi-sensor glycemic dynamics.</li>
            <li><strong>Target Labeling:</strong> Ground-truth binary outcome derived strictly from future measurements (t &lt; t&apos; &le; t + 120min), eliminating circular label leakage.</li>
            <li><strong>Honest Distinction:</strong> We distinguish rule-based scoring from black-box ML claims. The scoring engine evaluates deterministic features against held-out patient splits to benchmark calibration without claiming empirical human clinical training.</li>
          </ul>
        </div>
      </div>

      {/* Physiological Minimal Model Concept */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-500" />
          Physiological Minimal Model Kinetics (Bergman-Inspired Dynamics)
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed mb-3">
          The synthetic data generator and forward trajectory projection are grounded in the classical <strong>Bergman Minimal Model</strong> of glucose-insulin kinetics, augmented with exercise-induced GLUT4 translocation:
        </p>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 font-mono text-xs text-slate-800 space-y-2">
          <p className="font-bold text-teal-900">
            dG/dt = - [p1 + X(t)] &middot; G(t) + p1 &middot; G_basal + MealFlux(t) - ExerciseSink(t) + CircadianDawn(t)
          </p>
          <p className="text-[11px] text-slate-600 font-sans">
            • <strong>MealFlux(t):</strong> Two-compartment gastrointestinal absorption model yielding postprandial rise peaks at 45–75 mins.
          </p>
          <p className="text-[11px] text-slate-600 font-sans">
            • <strong>ExerciseSink(t):</strong> Skeletal muscle contraction stimulates non-insulin dependent GLUT4 glucose transport, dropping blood glucose at 1.0–1.8 mg/dL per min during active walking.
          </p>
        </div>
      </div>
    </div>
  );
};
