/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Sliders,
  CheckCircle,
  AlertTriangle,
  Info,
  ShieldAlert,
  Percent,
  Target,
  FileCheck
} from 'lucide-react';
import type { ModelEvaluationMetrics } from '../types/diabetes';
import { calculateEvaluationMetrics, type EvaluationSample } from '../ml/evaluation';

interface ModelEvaluationViewProps {
  evaluationSamples: EvaluationSample[];
  threshold: number;
}

export const ModelEvaluationView: React.FC<ModelEvaluationViewProps> = ({
  evaluationSamples,
  threshold
}) => {
  const [decisionThreshold, setDecisionThreshold] = useState<number>(0.50);

  // Recalculate evaluation metrics dynamically when user adjusts decision threshold
  const metrics: ModelEvaluationMetrics = useMemo(() => {
    return calculateEvaluationMetrics(evaluationSamples, decisionThreshold);
  }, [evaluationSamples, decisionThreshold]);

  const cm = metrics.confusionMatrix;

  // ROC SVG dimensions
  const svgSize = 280;
  const padding = 35;
  const plotSize = svgSize - 2 * padding;

  const toSvgX = (fpr: number) => padding + fpr * plotSize;
  const toSvgY = (tpr: number) => padding + (1 - tpr) * plotSize;

  // Build ROC path
  const rocPath = useMemo(() => {
    return metrics.rocCurvePoints.reduce((acc, pt, i) => {
      const x = toSvgX(pt.fpr);
      const y = toSvgY(pt.tpr);
      return i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : `${acc} L ${x.toFixed(1)} ${y.toFixed(1)}`;
    }, '');
  }, [metrics.rocCurvePoints]);

  // Current operating point on ROC
  const currentFPR = (cm.falsePositives + cm.trueNegatives) > 0
    ? cm.falsePositives / (cm.falsePositives + cm.trueNegatives)
    : 0;
  const currentTPR = metrics.sensitivity;

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
                <BarChart3 className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                Model Evaluation & Benchmark Performance
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Synthetic evaluation episodes ({metrics.totalEpisodes}); feature extraction is backward-looking, but this is not clinical validation
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200">
              ROC-AUC: {metrics.rocAuc !== null ? metrics.rocAuc.toFixed(3) : 'N/A (Single Class)'}
            </span>
            <span className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-slate-100 text-slate-700">
              Brier: {metrics.brierScore.toFixed(3)}
            </span>
          </div>
        </div>

        {/* Interactive Decision Threshold Slider */}
        <div className="pt-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2 mb-2">
            <div>
              <span className="font-bold text-slate-800">
                Classification Decision Threshold (τ):
              </span>
              <span className="font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200 ml-2">
                {decisionThreshold.toFixed(2)}
              </span>
              <span className="text-slate-500 text-[11px] ml-2">
                (Assign positive excursion if predicted risk ≥ τ)
              </span>
            </div>
            <div className="text-[11px] text-slate-500">
              Slide to observe Sensitivity vs Specificity clinical trade-offs
            </div>
          </div>

          <input
            id="decision-threshold-slider"
            aria-label="Classification Decision Threshold"
            type="range"
            min="0.10"
            max="0.90"
            step="0.02"
            value={decisionThreshold}
            onChange={(e) => setDecisionThreshold(Number(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
          />

          <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
            <span>0.10 (High Sensitivity / Early Warning)</span>
            <span>0.50 (Standard Balanced Cutoff)</span>
            <span>0.90 (High Specificity / Conservative)</span>
          </div>
        </div>

        {/* Cohort Details & Class Balance Banner */}
        <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
            <span className="text-slate-400 text-[10px] block font-medium">Dataset Size</span>
            <span className="font-bold font-mono text-slate-800">{metrics.totalEpisodes} Episodes</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
            <span className="text-slate-400 text-[10px] block font-medium">Class Balance (Prevalence)</span>
            <span className="font-bold font-mono text-teal-700">
              {(metrics.positivePrevalence * 100).toFixed(1)}% Pos ({cm.truePositives + cm.falseNegatives}) / {((1 - metrics.positivePrevalence) * 100).toFixed(1)}% Neg ({cm.trueNegatives + cm.falsePositives})
            </span>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
            <span className="text-slate-400 text-[10px] block font-medium">Split Strategy</span>
            <span className="font-bold text-slate-800">Synthetic Seed-Offset Episodes</span>
          </div>
          <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
            <span className="text-slate-400 text-[10px] block font-medium">Label Leakage Status</span>
            <span className="font-bold text-emerald-700">Strict Zero Leakage (t' &gt; t)</span>
          </div>
        </div>
      </div>

      {/* Grid: Confusion Matrix & ROC Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Confusion Matrix (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Target className="w-4 h-4 text-teal-600" />
              Confusion Matrix ({metrics.totalEpisodes} Test Windows)
            </h3>
            <span className="text-xs text-slate-500">
              Target: &gt;{threshold} mg/dL
            </span>
          </div>

          {/* Matrix 2x2 Grid */}
          <div className="grid grid-cols-2 gap-3">
            {/* True Positive */}
            <div className="p-4 rounded-xl bg-teal-50/70 border-2 border-teal-300 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-teal-900 uppercase tracking-wider">
                  True Positive (TP)
                </span>
                <CheckCircle className="w-4 h-4 text-teal-600" />
              </div>
              <div className="my-2">
                <span className="text-3xl font-extrabold text-teal-900 font-mono">
                  {cm.truePositives}
                </span>
              </div>
              <p className="text-[11px] text-teal-800 leading-tight">
                Excursion accurately forecasted 2 hours in advance.
              </p>
            </div>

            {/* False Positive */}
            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider">
                  False Positive (FP)
                </span>
                <AlertTriangle className="w-4 h-4 text-amber-600" />
              </div>
              <div className="my-2">
                <span className="text-3xl font-extrabold text-amber-900 font-mono">
                  {cm.falsePositives}
                </span>
              </div>
              <p className="text-[11px] text-amber-800 leading-tight">
                Model flagged risk, but glucose remained below threshold.
              </p>
            </div>

            {/* False Negative */}
            <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-rose-900 uppercase tracking-wider">
                  False Negative (FN)
                </span>
                <AlertTriangle className="w-4 h-4 text-rose-600" />
              </div>
              <div className="my-2">
                <span className="text-3xl font-extrabold text-rose-900 font-mono">
                  {cm.falseNegatives}
                </span>
              </div>
              <p className="text-[11px] text-rose-800 leading-tight">
                Missed excursion (unannounced surge or delayed rise).
              </p>
            </div>

            {/* True Negative */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  True Negative (TN)
                </span>
                <CheckCircle className="w-4 h-4 text-slate-500" />
              </div>
              <div className="my-2">
                <span className="text-3xl font-extrabold text-slate-800 font-mono">
                  {cm.trueNegatives}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-tight">
                Correctly identified normoglycemic / stable window.
              </p>
            </div>
          </div>
        </div>

        {/* Right: Receiver Operating Characteristic (ROC) Curve (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-2">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-teal-600" />
              ROC Curve {metrics.rocAuc !== null ? `(AUC = ${metrics.rocAuc.toFixed(3)})` : '(AUC Undefined - Single Class)'}
            </h3>
            <span className="text-xs text-slate-500">
              Discrimination Capacity
            </span>
          </div>

          <div className="flex items-center justify-center">
            <svg viewBox={`0 0 ${svgSize} ${svgSize}`} className="w-64 h-64 overflow-visible">
              {/* Background Grid */}
              <rect
                x={padding}
                y={padding}
                width={plotSize}
                height={plotSize}
                fill="#f8fafc"
                stroke="#e2e8f0"
              />

              {/* Grid Lines */}
              {[0.25, 0.5, 0.75].map(v => (
                <g key={v}>
                  <line
                    x1={toSvgX(v)}
                    y1={padding}
                    x2={toSvgX(v)}
                    y2={padding + plotSize}
                    stroke="#e2e8f0"
                    strokeDasharray="2 3"
                  />
                  <line
                    x1={padding}
                    y1={toSvgY(v)}
                    x2={padding + plotSize}
                    y2={toSvgY(v)}
                    stroke="#e2e8f0"
                    strokeDasharray="2 3"
                  />
                </g>
              ))}

              {/* Diagonal Chance Line (AUC = 0.5) */}
              <line
                x1={toSvgX(0)}
                y1={toSvgY(0)}
                x2={toSvgX(1)}
                y2={toSvgY(1)}
                stroke="#94a3b8"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />

              {/* ROC Curve Path */}
              <path
                d={rocPath}
                fill="none"
                stroke="#0d9488"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Operating Point Marker */}
              <circle
                cx={toSvgX(currentFPR)}
                cy={toSvgY(currentTPR)}
                r="6"
                fill="#f43f5e"
                stroke="#ffffff"
                strokeWidth="2"
              />

              {/* Axis labels */}
              <text
                x={padding + plotSize / 2}
                y={svgSize - 8}
                textAnchor="middle"
                className="text-[10px] fill-slate-500 font-semibold"
              >
                False Positive Rate (1 - Specificity)
              </text>
              <text
                x={12}
                y={padding + plotSize / 2}
                textAnchor="middle"
                transform={`rotate(-90 12 ${padding + plotSize / 2})`}
                className="text-[10px] fill-slate-500 font-semibold"
              >
                True Positive Rate (Sensitivity)
              </text>
            </svg>
          </div>

          <div className="text-[11px] text-slate-500 text-center mt-2 flex items-center justify-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              Current Operating Point (τ = {decisionThreshold.toFixed(2)})
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-teal-600"></span>
              Model ROC
            </span>
          </div>
        </div>
      </div>

      {/* Metrics Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Accuracy</span>
          <span className="text-xl font-bold font-mono text-slate-900">
            {(metrics.accuracy * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Overall correctness</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Sensitivity (Recall)</span>
          <span className="text-xl font-bold font-mono text-teal-700">
            {(metrics.sensitivity * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Excursions detected</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Specificity</span>
          <span className="text-xl font-bold font-mono text-slate-900">
            {(metrics.specificity * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">True negative rate</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Precision (PPV)</span>
          <span className="text-xl font-bold font-mono text-slate-900">
            {(metrics.precision * 100).toFixed(1)}%
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Positive predictive value</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">F1-Score</span>
          <span className="text-xl font-bold font-mono text-slate-900">
            {metrics.f1Score.toFixed(3)}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Harmonic mean</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/90 p-3 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Brier Calibration</span>
          <span className="text-xl font-bold font-mono text-indigo-700">
            {metrics.brierScore.toFixed(3)}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Mean squared error</span>
        </div>
      </div>

      {/* Prominent Mandatory Disclosure: Synthetic Data Performance Limitation */}
      <div className="bg-amber-50/80 rounded-2xl border border-amber-200 p-5">
        <div className="flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1.5 text-xs text-amber-900 leading-relaxed">
            <h4 className="font-bold text-sm text-amber-950">
              Clinical Validity & Regulatory Limitation Disclosure
            </h4>
            <p>
              <strong>Synthetic data performance does not establish clinical validity.</strong> While the data generation and evaluation framework incorporates rigorous physiological minimal model kinetics and strictly guarantees zero data leakage (t' ≤ t), real human glycemic dynamics exhibit complex stochastic factors not captured in simulation (including interstitial-to-blood glucose lag variations, acute subclinical infection, medication pharmacokinetics, and unannounced food intake).
            </p>
            <p className="text-[11px] text-amber-800">
              This application was engineered specifically for the <strong>Happiest Health Digital Twin Challenge 2026</strong> as an academic and technological proof of concept. It has not been reviewed, cleared, or approved by the US FDA, EMA, or any national regulatory body as a medical device or clinical decision support software. It must never be used for therapeutic insulin dosing, diagnostic triage, or medical advice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
