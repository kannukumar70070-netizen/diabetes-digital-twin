/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, UserPlus, ShieldCheck } from 'lucide-react';
import type { SyntheticPatient, DiabetesSubtype } from '../types/diabetes';

interface CustomPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePatient: (newPatient: SyntheticPatient) => void;
}

export const CustomPatientModal: React.FC<CustomPatientModalProps> = ({
  isOpen,
  onClose,
  onSavePatient
}) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState(52);
  const [gender, setGender] = useState<'Female' | 'Male' | 'Non-Binary'>('Female');
  const [diagnosis, setDiagnosis] = useState<DiabetesSubtype>('Type 2 Diabetes');
  const [diagnosisYears, setDiagnosisYears] = useState(4);
  const [bmi, setBmi] = useState(28.5);
  const [baselineHbA1c, setBaselineHbA1c] = useState(7.4);
  const [threshold, setThreshold] = useState(180);
  const [medicationName, setMedicationName] = useState('Metformin');
  const [clinicalNotes, setClinicalNotes] = useState('Custom synthetic patient profile created for Digital Twin Challenge testing.');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPt: SyntheticPatient = {
      id: `pt-custom-${Date.now().toString().slice(-4)}`,
      name: name.trim() || 'Custom Synthetic Patient',
      age: Number(age),
      gender,
      diagnosis,
      diagnosisYears: Number(diagnosisYears),
      bmi: Number(bmi),
      baselineHbA1c: Number(baselineHbA1c),
      targetGlucoseRange: [70, threshold],
      hyperglycemiaThreshold: Number(threshold),
      hypoglycemiaThreshold: 70,
      medications: [
        {
          name: medicationName || 'Metformin',
          dosage: '500 mg',
          frequency: 'Twice daily',
          complianceRate: 0.90,
          class: 'Biguanide'
        }
      ],
      clinicalNotes,
      avatarSeed: name.toLowerCase().replace(/\s+/g, '-'),
      isCustom: true
    };

    onSavePatient(newPt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Create Synthetic Patient Profile
              </h3>
              <p className="text-[11px] text-slate-500">
                Configure demographic and clinical baseline priors
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">Patient Full Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Samuel Rodriguez"
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Age (Years)</label>
              <input
                type="number"
                min="18"
                max="95"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900 bg-white"
              >
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Non-Binary">Non-Binary</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Diagnosis Subtype</label>
              <select
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value as DiabetesSubtype)}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900 bg-white"
              >
                <option value="Type 2 Diabetes">Type 2 Diabetes</option>
                <option value="Prediabetes">Prediabetes</option>
                <option value="LADA">LADA (Latent Autoimmune)</option>
                <option value="Metabolic Syndrome">Metabolic Syndrome</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Years Diagnosed</label>
              <input
                type="number"
                min="0"
                max="40"
                value={diagnosisYears}
                onChange={(e) => setDiagnosisYears(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">BMI (kg/m²)</label>
              <input
                type="number"
                step="0.1"
                min="18"
                max="50"
                value={bmi}
                onChange={(e) => setBmi(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Baseline HbA1c (%)</label>
              <input
                type="number"
                step="0.1"
                min="5.0"
                max="14.0"
                value={baselineHbA1c}
                onChange={(e) => setBaselineHbA1c(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Alert Cutoff (mg/dL)</label>
              <input
                type="number"
                step="5"
                min="140"
                max="240"
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Primary Medication</label>
            <input
              type="text"
              value={medicationName}
              onChange={(e) => setMedicationName(e.target.value)}
              placeholder="e.g. Metformin 1000mg BID or Semaglutide 0.5mg"
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Clinical Phenotype Notes</label>
            <textarea
              rows={2}
              value={clinicalNotes}
              onChange={(e) => setClinicalNotes(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-teal-500 text-xs text-slate-900 resize-none"
            />
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
              Will generate reproducible 7-day telemetry
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
              >
                Generate Twin Profile
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
