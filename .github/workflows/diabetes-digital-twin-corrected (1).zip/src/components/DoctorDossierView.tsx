/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  History,
  Download,
  Filter,
  UserCheck,
  Stethoscope,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import type {
  SyntheticPatient,
  SensorReading,
  PredictionResult,
  PredictionHistoryRecord,
  FeatureVector
} from '../types/diabetes';

interface DoctorDossierViewProps {
  patient: SyntheticPatient;
  recentReadings: SensorReading[];
  currentPrediction: PredictionResult;
  features: FeatureVector;
  predictionHistory: PredictionHistoryRecord[];
  threshold: number;
}

export const DoctorDossierView: React.FC<DoctorDossierViewProps> = ({
  patient,
  recentReadings,
  currentPrediction,
  features,
  predictionHistory,
  threshold
}) => {
  const [historyFilter, setHistoryFilter] = useState<'all' | 'correct' | 'discrepancies'>('all');

  // Filter prediction history
  const filteredHistory = predictionHistory.filter(h => {
    if (historyFilter === 'correct') return h.predictionCorrect;
    if (historyFilter === 'discrepancies') return !h.predictionCorrect;
    return true;
  });

  // Calculate audit stats
  const totalAudit = predictionHistory.length;
  const correctCount = predictionHistory.filter(h => h.predictionCorrect).length;
  const accuracyPct = totalAudit > 0 ? Math.round((correctCount / totalAudit) * 100) : 0;

  // Export audit log as CSV
  const handleExportCsv = () => {
    const headers = 'ID,Timestamp,CurrentGlucose,PredictedProb,RiskTier,ActualMax2h,GroundTruthCrossed,Correct,Notes\n';
    const rows = predictionHistory.map(h => 
      `"${h.id}","${h.isoTime}",${h.currentGlucoseAtPrediction},${h.predictedProbability},"${h.riskTier}",${h.actualMaxGlucoseNext2h},${h.actualGroundTruthLabel},${h.predictionCorrect},"${h.notes}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `twin_audit_log_${patient.id}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Clinical Dossier Header */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  Clinical Dossier & Longitudinal Prediction Audit
                </h2>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
                  Doctor-Facing View
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Auditable digital twin forecasts verified against future 2-hour continuous sensor ground truth
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 transition-colors shadow-2xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-teal-600" />
              <span>Export Audit CSV</span>
            </button>
          </div>
        </div>

        {/* Audit Summary Statistics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
          <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
            <span className="text-[11px] font-medium text-slate-500 block">Total Forecast Audits</span>
            <span className="text-xl font-bold font-mono text-slate-900">{totalAudit} windows</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Consecutive 2-hr evaluation blocks</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
            <span className="text-[11px] font-medium text-slate-500 block">Audit Window Accuracy</span>
            <span className="text-xl font-bold font-mono text-emerald-700">{accuracyPct}%</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">{correctCount} of {totalAudit} correct</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
            <span className="text-[11px] font-medium text-slate-500 block">Defined Alert Threshold</span>
            <span className="text-xl font-bold font-mono text-amber-700">&gt;{threshold} mg/dL</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">ADA standard clinical cutoff</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
            <span className="text-[11px] font-medium text-slate-500 block">Data Leakage Verification</span>
            <span className="text-sm font-bold font-mono text-teal-700 flex items-center gap-1 mt-1">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              Verified Clean
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Strict prior-only conditioning</span>
          </div>
        </div>
      </div>

      {/* Section 1: Timestamped Prediction History Table (Audit Log) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Timestamped Forecast vs Actual Ground Truth History
            </h3>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center bg-slate-100 rounded-lg p-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setHistoryFilter('all')}
              className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                historyFilter === 'all' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({predictionHistory.length})
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('correct')}
              className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                historyFilter === 'correct' ? 'bg-white text-emerald-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Correct ({correctCount})
            </button>
            <button
              type="button"
              onClick={() => setHistoryFilter('discrepancies')}
              className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                historyFilter === 'discrepancies' ? 'bg-white text-amber-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Discrepancies ({totalAudit - correctCount})
            </button>
          </div>
        </div>

        {/* Table of Past Forecasts */}
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 uppercase tracking-wider text-[10px] border-b border-slate-200/60">
                <th className="py-2.5 px-3 font-semibold">Prediction Timestamp</th>
                <th className="py-2.5 px-3 font-semibold">CGM at Forecast</th>
                <th className="py-2.5 px-3 font-semibold">Predicted Risk</th>
                <th className="py-2.5 px-3 font-semibold">Subsequent +2h Max CGM</th>
                <th className="py-2.5 px-3 font-semibold">Ground Truth (&gt;{threshold})</th>
                <th className="py-2.5 px-3 font-semibold">Outcome Audit</th>
                <th className="py-2.5 px-3 font-semibold">Physiological Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredHistory.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-3 font-medium text-slate-900 whitespace-nowrap">
                    {rec.isoTime}
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold">
                    {rec.currentGlucoseAtPrediction} mg/dL
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                        rec.riskTier === 'Critical' || rec.riskTier === 'Elevated'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : rec.riskTier === 'Moderate'
                          ? 'bg-yellow-50 text-yellow-700 border border-yellow-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {Math.round(rec.predictedProbability * 100)}% ({rec.riskTier})
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono font-bold">
                    <span className={rec.actualMaxGlucoseNext2h >= threshold ? 'text-amber-700' : 'text-slate-800'}>
                      {rec.actualMaxGlucoseNext2h} mg/dL
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    {rec.actualGroundTruthLabel ? (
                      <span className="inline-flex items-center gap-1 text-rose-600 font-semibold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Excursion (&gt;{threshold})
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-emerald-600 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Within Target
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3">
                    {rec.predictionCorrect ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3" />
                        Verified Concordant
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                        <AlertTriangle className="w-3 h-3" />
                        Discrepancy
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-[11px] text-slate-500 max-w-xs">
                    {rec.notes}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Section 2: Recent 5-Minute Telemetry Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-teal-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Recent Continuous Telemetry Log (5-min Epochs)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            Last {recentReadings.slice(-12).length} intervals shown
          </span>
        </div>

        <div className="overflow-x-auto mt-3">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 uppercase tracking-wider text-[10px] border-b border-slate-200/60">
                <th className="py-2.5 px-3 font-semibold">Epoch Time</th>
                <th className="py-2.5 px-3 font-semibold">Glucose (mg/dL)</th>
                <th className="py-2.5 px-3 font-semibold">Velocity (mg/dL/min)</th>
                <th className="py-2.5 px-3 font-semibold">Heart Rate (bpm)</th>
                <th className="py-2.5 px-3 font-semibold">5-min Steps</th>
                <th className="py-2.5 px-3 font-semibold">Event Tag</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
              {recentReadings.slice(-12).reverse().map((r, i) => (
                <tr key={i} className="hover:bg-slate-50/60">
                  <td className="py-2.5 px-3 text-slate-900 font-sans font-medium">
                    {new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-slate-900">
                    {r.glucose}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={r.glucoseVelocity > 0 ? 'text-amber-600' : 'text-teal-600'}>
                      {r.glucoseVelocity > 0 ? '+' : ''}{r.glucoseVelocity.toFixed(2)}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-rose-600">
                    {r.heartRate}
                  </td>
                  <td className="py-2.5 px-3 text-indigo-600">
                    {r.steps}
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    {r.eventDescription ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                        {r.eventDescription}
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[10px]">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
