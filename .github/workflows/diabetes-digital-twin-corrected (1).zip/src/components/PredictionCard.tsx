/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Sparkles,
  AlertTriangle,
  Clock,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
  Info,
  CheckCircle,
  Activity,
  SlidersHorizontal
} from 'lucide-react';
import type { PredictionResult, SyntheticPatient } from '../types/diabetes';

interface PredictionCardProps {
  prediction: PredictionResult;
  patient: SyntheticPatient;
  threshold: number;
  onNavigateToSimulator: () => void;
}

export const PredictionCard: React.FC<PredictionCardProps> = ({
  prediction,
  patient,
  threshold,
  onNavigateToSimulator
}) => {
  const probPct = Math.round(prediction.predictedProbability * 100);

  // Risk Tier Styling
  const getRiskStyle = (tier: PredictionResult['riskTier']) => {
    switch (tier) {
      case 'Critical':
        return {
          bg: 'bg-rose-50',
          border: 'border-rose-200',
          text: 'text-rose-700',
          ring: '#f43f5e',
          badge: 'bg-rose-100 text-rose-800 border-rose-300',
          description: 'High probability of crossing threshold within 120 minutes.'
        };
      case 'Elevated':
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          text: 'text-amber-700',
          ring: '#f59e0b',
          badge: 'bg-amber-100 text-amber-800 border-amber-300',
          description: 'Moderate-high probability of excursion. Proactive monitoring recommended.'
        };
      case 'Moderate':
        return {
          bg: 'bg-yellow-50',
          border: 'border-yellow-200',
          text: 'text-yellow-700',
          ring: '#eab308',
          badge: 'bg-yellow-100 text-yellow-800 border-yellow-300',
          description: 'Borderline dynamics; excursion possible if glycemic velocity sustains.'
        };
      case 'Low':
      default:
        return {
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          text: 'text-emerald-700',
          ring: '#10b981',
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          description: 'Stable trajectory. Glucose projected to remain safely below threshold.'
        };
    }
  };

  const riskStyle = getRiskStyle(prediction.riskTier);

  // SVG circular gauge calculation
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (prediction.predictedProbability * circumference);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 transition-all">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              2-Hour Excursion Predictor (Physiological Scoring Model)
            </h3>
            <p className="text-xs text-slate-500">
              Target Threshold: <strong className="text-slate-700">&gt;{threshold} mg/dL</strong> within next 120 mins
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onNavigateToSimulator}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors cursor-pointer"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Launch What-If Simulator</span>
        </button>
      </div>

      {/* Main Prediction Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 py-5 border-b border-slate-100 items-center">
        {/* Circular Probability Gauge */}
        <div className="flex items-center gap-4 p-3 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
            <svg className="w-24 h-24 transform -rotate-90">
              <circle
                cx="48"
                cy="48"
                r={radius}
                stroke="#e2e8f0"
                strokeWidth="7"
                fill="transparent"
              />
              <circle
                cx="48"
                cy="48"
                r={radius}
                stroke={riskStyle.ring}
                strokeWidth="7"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-black text-slate-900 font-mono tracking-tight leading-none">
                {probPct}%
              </span>
              <span className="text-[10px] font-semibold text-slate-500 uppercase mt-0.5">
                Risk Score
              </span>
            </div>
          </div>

          <div>
            <span
              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${riskStyle.badge}`}
            >
              {prediction.riskTier} Risk
            </span>
            <p className="text-xs text-slate-600 mt-1.5 leading-snug">
              {riskStyle.description}
            </p>
          </div>
        </div>

        {/* Projected Peak Glucose */}
        <div className="p-4 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">Projected Peak Glucose (+2h)</span>
            <TrendingUp className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1.5 my-1">
            <span className="text-3xl font-extrabold text-slate-900 font-mono">
              {prediction.expectedPeakGlucose2h}
            </span>
            <span className="text-xs font-semibold text-slate-500">mg/dL</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            {prediction.expectedPeakGlucose2h >= threshold ? (
              <span className="text-rose-600 font-medium">
                Projected to exceed threshold by +{prediction.expectedPeakGlucose2h - threshold} mg/dL
              </span>
            ) : (
              <span className="text-emerald-600 font-medium">
                Safely below threshold (margin of {threshold - prediction.expectedPeakGlucose2h} mg/dL)
              </span>
            )}
          </div>
        </div>

        {/* Advance Warning Horizon / Estimated Minutes */}
        <div className="p-4 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">Time-to-Threshold Crossing</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-1.5 my-1">
            <span className="text-3xl font-extrabold text-slate-900 font-mono">
              {prediction.estimatedMinutesToThreshold !== null ? (
                prediction.estimatedMinutesToThreshold === 0 ? 'Crossed' : `~${prediction.estimatedMinutesToThreshold}m`
              ) : (
                'Safe'
              )}
            </span>
            {prediction.estimatedMinutesToThreshold !== null && prediction.estimatedMinutesToThreshold > 0 && (
              <span className="text-xs font-semibold text-slate-500">advance warning</span>
            )}
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            {prediction.estimatedMinutesToThreshold !== null ? (
              <span className="text-amber-700 font-medium">
                Crossing window: Next {prediction.estimatedMinutesToThreshold} to 90 minutes
              </span>
            ) : (
              <span className="text-emerald-600 font-medium">
                No crossing anticipated in the 120-minute evaluation window
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Explainable AI (XAI) Feature Attributions */}
      <div className="pt-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Factor Attributions: Key Contributing Dynamics
            </h4>
            <span className="text-[11px] text-slate-400 font-normal">
              (Linear log-odds physiological contributions)
            </span>
          </div>
          <span className="text-[11px] text-slate-500">
            Positive = Pushes Risk Up • Negative = Protective
          </span>
        </div>

        <div className="space-y-2">
          {prediction.attributions.slice(0, 5).map((attr, idx) => {
            const isPositive = attr.contributionPercent > 0;
            const barWidth = Math.min(100, Math.abs(attr.contributionPercent) * 2.5);

            return (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-50/80 border border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2 sm:w-1/3">
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      isPositive ? 'bg-rose-500' : 'bg-emerald-500'
                    }`}
                  ></span>
                  <div>
                    <span className="text-xs font-semibold text-slate-800">
                      {attr.label}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500 ml-1.5">
                      ({attr.rawValue})
                    </span>
                  </div>
                </div>

                <div className="sm:w-1/3 flex items-center gap-2">
                  <div className="w-full bg-slate-200/80 rounded-full h-2 overflow-hidden flex">
                    {isPositive ? (
                      <div
                        className="bg-rose-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${barWidth}%` }}
                      ></div>
                    ) : (
                      <div
                        className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${barWidth}%` }}
                      ></div>
                    )}
                  </div>
                  <span
                    className={`text-xs font-bold font-mono min-w-[42px] text-right ${
                      isPositive ? 'text-rose-600' : 'text-emerald-600'
                    }`}
                  >
                    {isPositive ? '+' : ''}{attr.contributionPercent}%
                  </span>
                </div>

                <div className="sm:w-1/3 text-right">
                  <span className="text-[11px] text-slate-600">
                    {attr.clinicalInterpretation}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
