/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - 3D Physiological Scene Viewer
 * Procedural 3D Vascular & Cellular Glucose Transport Model
 * Follows Three.js Skill Directives & Studio PBR Standards
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  Layers,
  Zap,
  Play,
  Pause,
  RotateCcw,
  Footprints,
  Eye,
  ChevronDown,
  ChevronUp,
  Maximize2
} from 'lucide-react';
import type { SyntheticPatient } from '../types/diabetes';

interface Physiological3DViewerProps {
  patient: SyntheticPatient;
  currentGlucose: number;
  glucoseVelocity: number;
}

export const Physiological3DViewer: React.FC<Physiological3DViewerProps> = ({
  patient,
  currentGlucose,
  glucoseVelocity
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [simulationMode, setSimulationMode] = useState<'normal' | 'spike' | 'walk'>('walk');
  const [isControlsCollapsed, setIsControlsCollapsed] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1.0);

  // Mutable refs for animation loop
  const stateRef = useRef({
    simulationMode: 'walk',
    isPaused: false,
    speedMultiplier: 1.0,
    glucoseConcentration: currentGlucose
  });

  useEffect(() => {
    stateRef.current.simulationMode = simulationMode;
    stateRef.current.isPaused = isPaused;
    stateRef.current.speedMultiplier = speedMultiplier;
    stateRef.current.glucoseConcentration = currentGlucose;
  }, [simulationMode, isPaused, speedMultiplier, currentGlucose]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect headless software WebGL
    const isHeadless =
      typeof navigator !== 'undefined' &&
      (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#090d16');
    scene.fog = new THREE.FogExp2('#090d16', 0.022);

    const width = container.clientWidth || 900;
    const height = container.clientHeight || 480;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 4.5, 12);
    camera.lookAt(0, 0, 0);

    // 2. Renderer Setup with PBR Color Pipeline
    const renderer = new THREE.WebGLRenderer({
      antialias: !isHeadless,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isHeadless ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isHeadless;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 3. Studio Environment Map (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 4. Lighting Rig (Key Light + Cool Fill + Soft Rim)
    const keyLight = new THREE.DirectionalLight('#fff5e6', 2.8);
    keyLight.position.set(6, 10, 8);
    keyLight.castShadow = !isHeadless;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight('#cbe5ff', '#1a2233', 1.2);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight('#14b8a6', 1.8);
    rimLight.position.set(-8, 3, -6);
    scene.add(rimLight);

    // 5. Composite 3–12 Part Procedural Digital Twin Model
    const twinGroup = new THREE.Group();
    scene.add(twinGroup);

    // Part 1: Capillary Blood Vessel Tube (Curved Lumen)
    const vesselCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-10, 1.2, -1),
      new THREE.Vector3(-5, 1.5, 0),
      new THREE.Vector3(0, 1.2, 0.5),
      new THREE.Vector3(5, 1.6, 0),
      new THREE.Vector3(10, 1.2, -1)
    ]);
    const vesselGeo = new THREE.TubeGeometry(vesselCurve, 32, 1.6, 16, false);
    const vesselMat = new THREE.MeshPhysicalMaterial({
      color: '#e11d48',
      transmission: 0.85,
      opacity: 0.35,
      transparent: true,
      roughness: 0.2,
      ior: 1.35,
      thickness: 0.5,
      side: THREE.DoubleSide
    });
    const vesselMesh = new THREE.Mesh(vesselGeo, vesselMat);
    twinGroup.add(vesselMesh);

    // Part 2: Endothelial Cellular Border Rings
    const ringMat = new THREE.MeshStandardMaterial({
      color: '#fb7185',
      roughness: 0.4,
      metalness: 0.1
    });
    for (let r = -4; r <= 4; r += 2) {
      const ringGeo = new THREE.TorusGeometry(1.65, 0.04, 8, 24);
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.set(r * 2, 1.35, 0);
      ringMesh.rotation.y = Math.PI / 2;
      twinGroup.add(ringMesh);
    }

    // Part 3: Muscle / Adipocyte Cellular Plasma Membrane Plate
    const membraneGeo = new THREE.BoxGeometry(18, 0.3, 8);
    const membraneMat = new THREE.MeshPhysicalMaterial({
      color: '#0d9488',
      roughness: 0.35,
      metalness: 0.15,
      clearcoat: 0.4
    });
    const membraneMesh = new THREE.Mesh(membraneGeo, membraneMat);
    membraneMesh.position.set(0, -1.8, 0);
    membraneMesh.receiveShadow = !isHeadless;
    twinGroup.add(membraneMesh);

    // Part 4: GLUT4 Glucose Transporters (docked membrane channel barrels)
    const glut4Group = new THREE.Group();
    twinGroup.add(glut4Group);

    const glut4Barrels: THREE.Mesh[] = [];
    const barrelGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.7, 12);
    const barrelMat = new THREE.MeshStandardMaterial({
      color: '#10b981',
      roughness: 0.25,
      metalness: 0.4
    });

    [-6, -3, 0, 3, 6].forEach(x => {
      const barrel = new THREE.Mesh(barrelGeo, barrelMat);
      barrel.position.set(x, -1.5, 0.8);
      barrel.castShadow = !isHeadless;
      glut4Group.add(barrel);
      glut4Barrels.push(barrel);

      // Accent receptor rim
      const rimGeo = new THREE.TorusGeometry(0.38, 0.05, 8, 16);
      const rimMat = new THREE.MeshStandardMaterial({ color: '#34d399', metalness: 0.7, roughness: 0.2 });
      const rim = new THREE.Mesh(rimGeo, rimMat);
      rim.position.set(x, -1.15, 0.8);
      rim.rotation.x = Math.PI / 2;
      glut4Group.add(rim);
    });

    // Part 5: Insulin Receptors (Tyrosine-kinase heterodimers)
    [-4.5, -1.5, 1.5, 4.5].forEach(x => {
      const stalkGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.8, 8);
      const stalkMat = new THREE.MeshStandardMaterial({ color: '#6366f1', roughness: 0.3, metalness: 0.6 });
      const stalk = new THREE.Mesh(stalkGeo, stalkMat);
      stalk.position.set(x, -1.4, -1.2);
      twinGroup.add(stalk);

      const headGeo = new THREE.SphereGeometry(0.18, 12, 12);
      const headMat = new THREE.MeshStandardMaterial({ color: '#818cf8', roughness: 0.2, metalness: 0.8 });
      const head = new THREE.Mesh(headGeo, headMat);
      head.position.set(x, -0.95, -1.2);
      twinGroup.add(head);
    });

    // Part 6: Floating Erythrocytes (Biconcave Red Blood Cells)
    const erythrocyteGroup = new THREE.Group();
    twinGroup.add(erythrocyteGroup);

    // Procedural Lathe biconcave profile
    const rbcPoints: THREE.Vector2[] = [];
    for (let deg = 0; deg <= 180; deg += 15) {
      const rad = (deg * Math.PI) / 180;
      const x = Math.sin(rad) * 0.45;
      const y = Math.cos(rad) * (0.16 - Math.sin(rad) * 0.06);
      rbcPoints.push(new THREE.Vector2(x, y));
    }
    const rbcGeo = new THREE.LatheGeometry(rbcPoints, 16);
    const rbcMat = new THREE.MeshStandardMaterial({
      color: '#be123c',
      roughness: 0.3,
      metalness: 0.05
    });

    const erythrocytes: { mesh: THREE.Mesh; speed: number; rotSpeed: number }[] = [];
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(rbcGeo, rbcMat);
      mesh.position.set(
        (Math.random() - 0.5) * 16,
        1.2 + (Math.random() - 0.5) * 1.0,
        (Math.random() - 0.5) * 1.0
      );
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      erythrocyteGroup.add(mesh);
      erythrocytes.push({
        mesh,
        speed: 1.5 + Math.random() * 1.0,
        rotSpeed: (Math.random() - 0.5) * 2.0
      });
    }

    // Part 7: Glucose Hexose Molecules (Golden Emissive Clusters)
    const glucoseGroup = new THREE.Group();
    twinGroup.add(glucoseGroup);

    const glucoseGeo = new THREE.DodecahedronGeometry(0.14, 0);
    const glucoseMat = new THREE.MeshPhysicalMaterial({
      color: '#fbbf24',
      emissive: '#d97706',
      emissiveIntensity: 0.6,
      roughness: 0.15,
      metalness: 0.85,
      clearcoat: 1.0
    });

    const glucoseParticles: { mesh: THREE.Mesh; vx: number; vy: number; vz: number; basePos: THREE.Vector3 }[] = [];
    for (let i = 0; i < 48; i++) {
      const mesh = new THREE.Mesh(glucoseGeo, glucoseMat);
      const startX = (Math.random() - 0.5) * 16;
      const startY = 1.2 + (Math.random() - 0.5) * 1.2;
      const startZ = (Math.random() - 0.5) * 1.5;
      mesh.position.set(startX, startY, startZ);
      glucoseGroup.add(mesh);
      glucoseParticles.push({
        mesh,
        vx: 1.0 + Math.random() * 0.8,
        vy: (Math.random() - 0.5) * 0.4,
        vz: (Math.random() - 0.5) * 0.4,
        basePos: new THREE.Vector3(startX, startY, startZ)
      });
    }

    // Contact Ground Shadow Plane
    const shadowGeo = new THREE.PlaneGeometry(24, 14);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: '#05080e',
      transparent: true,
      opacity: 0.5
    });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -2.8;
    scene.add(shadowPlane);

    // Pre-warm WebGL compilation
    renderer.compile(scene, camera);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const delta = Math.min(clock.getDelta(), 0.1);
      const { isPaused, speedMultiplier, simulationMode } = stateRef.current;

      if (!isPaused) {
        const timeScale = delta * speedMultiplier;

        // Move Erythrocytes through capillary
        erythrocytes.forEach(rbc => {
          rbc.mesh.position.x += rbc.speed * timeScale * 1.8;
          rbc.mesh.rotation.x += rbc.rotSpeed * timeScale;
          rbc.mesh.rotation.y += rbc.rotSpeed * 0.5 * timeScale;
          if (rbc.mesh.position.x > 9) {
            rbc.mesh.position.x = -9;
          }
        });

        // Glucose Molecule Kinetics
        glucoseParticles.forEach((gp, idx) => {
          if (simulationMode === 'walk') {
            // Brisk Walk: GLUT4 Transporters pull glucose downward into cell!
            gp.mesh.position.x += gp.vx * timeScale * 1.4;
            // Draw towards nearest GLUT4 transporter
            if (gp.mesh.position.y > -1.5) {
              gp.mesh.position.y -= 1.2 * timeScale;
            }
            if (gp.mesh.position.x > 9 || gp.mesh.position.y <= -1.6) {
              gp.mesh.position.x = -9 + Math.random() * 2;
              gp.mesh.position.y = 1.2 + (Math.random() - 0.5) * 0.8;
            }
          } else if (simulationMode === 'spike') {
            // Postprandial surge: Rapid influx, turbulent flow
            gp.mesh.position.x += gp.vx * timeScale * 2.5;
            gp.mesh.position.y += Math.sin(clock.elapsedTime * 4 + idx) * 0.02;
            if (gp.mesh.position.x > 9) {
              gp.mesh.position.x = -9;
            }
          } else {
            // Normal Basal flow
            gp.mesh.position.x += gp.vx * timeScale;
            if (gp.mesh.position.x > 9) {
              gp.mesh.position.x = -9;
            }
          }
        });

        // Animate GLUT4 Transporter Opening
        glut4Barrels.forEach((barrel, bIdx) => {
          if (simulationMode === 'walk') {
            // Transporters expand and open up to facilitate diffusion
            const targetScaleY = 1.25;
            barrel.scale.y += (targetScaleY - barrel.scale.y) * (1 - Math.exp(-6 * delta));
          } else {
            const targetScaleY = 1.0;
            barrel.scale.y += (targetScaleY - barrel.scale.y) * (1 - Math.exp(-6 * delta));
          }
        });

        // Gentle camera sway
        camera.position.x = Math.sin(clock.elapsedTime * 0.25) * 0.6;
        camera.lookAt(0, -0.2, 0);
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      vesselGeo.dispose();
      vesselMat.dispose();
      membraneGeo.dispose();
      membraneMat.dispose();
      rbcGeo.dispose();
      rbcMat.dispose();
      glucoseGeo.dispose();
      glucoseMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-xl">
      {/* Top Floating Spec Badge */}
      <div className="absolute top-4 left-4 z-20 flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-900/90 text-teal-400 border border-teal-500/40">
          <Layers className="w-3.5 h-3.5 text-teal-400" />
          3D Procedural Glucose & GLUT4 Twin Visualization
        </span>
        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-900/80 text-slate-300 border border-slate-700">
          Vascular Lumen & Skeletal Muscle Interface (Illustrative Concept • Not Clinically Validated)
        </span>
      </div>

      {/* 3D WebGL Canvas Container */}
      <div
        ref={mountRef}
        className="w-full h-[440px] sm:h-[480px] bg-slate-950 cursor-grab active:cursor-grabbing"
      />

      {/* Collapsible Bottom Control Dock (<=15% Viewport footprint) */}
      <div
        className={`absolute bottom-3 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-2xl transition-all duration-300 ${
          isControlsCollapsed ? 'translate-y-[calc(100%-36px)]' : 'translate-y-0'
        }`}
      >
        <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-3 shadow-2xl backdrop-blur-xs">
          {/* Collapse/Expand Toggle Tab */}
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80 text-xs text-slate-400">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Counterfactual Physiological Simulation Mode
            </span>
            <button
              type="button"
              onClick={() => setIsControlsCollapsed(!isControlsCollapsed)}
              className="inline-flex items-center gap-1 text-[11px] text-teal-400 hover:text-teal-300 font-medium cursor-pointer"
            >
              {isControlsCollapsed ? (
                <>
                  <ChevronUp className="w-3.5 h-3.5" />
                  <span>Show Controls</span>
                </>
              ) : (
                <>
                  <ChevronDown className="w-3.5 h-3.5" />
                  <span>Hide Controls</span>
                </>
              )}
            </button>
          </div>

          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Mode Pills */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setSimulationMode('walk')}
                className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  simulationMode === 'walk'
                    ? 'bg-teal-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Footprints className="w-3.5 h-3.5" />
                <span>Active Walk (GLUT4 Sink)</span>
              </button>

              <button
                type="button"
                onClick={() => setSimulationMode('spike')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                  simulationMode === 'spike'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>Carb Surge Spike</span>
              </button>

              <button
                type="button"
                onClick={() => setSimulationMode('normal')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                  simulationMode === 'normal'
                    ? 'bg-blue-500 text-white shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>Basal Equilibrium</span>
              </button>
            </div>

            {/* Play/Pause & Speed */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsPaused(!isPaused)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors cursor-pointer"
                title={isPaused ? 'Resume Motion' : 'Pause Motion'}
              >
                {isPaused ? <Play className="w-3.5 h-3.5 text-teal-400" /> : <Pause className="w-3.5 h-3.5" />}
              </button>

              <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg text-[11px] text-slate-300">
                <span>Speed:</span>
                <button
                  type="button"
                  onClick={() => setSpeedMultiplier(s => (s === 1.0 ? 1.8 : s === 1.8 ? 0.5 : 1.0))}
                  className="font-mono font-bold text-teal-400 hover:underline cursor-pointer"
                >
                  {speedMultiplier}x
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Explicit Scientific Disclaimer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-400 flex items-start gap-2.5">
        <span className="w-1.5 h-1.5 rounded-full bg-teal-400 shrink-0 mt-1.5"></span>
        <p className="leading-relaxed">
          <strong className="text-slate-200">Illustrative Visualization Notice:</strong> This 3D viewport renders a conceptual procedural representation of capillary perfusion and cellular GLUT4-mediated glucose uptake. It is an educational visualization and interactive design concept engineered for the hackathon demonstration, and is <em>not</em> a clinically or bio-mechanically validated organ or tissue model.
        </p>
      </div>
    </div>
  );
};
