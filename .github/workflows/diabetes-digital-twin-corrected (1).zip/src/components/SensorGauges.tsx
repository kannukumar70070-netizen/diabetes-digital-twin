/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Activity,
  Heart,
  Footprints,
  Moon,
  ArrowUp,
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight,
  Zap
} from 'lucide-react';
import type { SensorReading, SyntheticPatient } from '../types/diabetes';

interface SensorGaugesProps {
  currentReading: SensorReading;
  patient: SyntheticPatient;
  recentSteps60m: number;
}

export const SensorGauges: React.FC<SensorGaugesProps> = ({
  currentReading,
  patient,
  recentSteps60m
}) => {
  // Determine trend icon & color based on glucose velocity
  const getVelocityDetails = (vel: number) => {
    if (vel > 2.0) {
      return {
        icon: ArrowUp,
        label: 'Rapidly Rising',
        color: 'text-rose-600 bg-rose-50 border-rose-200',
        badge: 'Rise > 2.0 mg/dL/min'
      };
    }
    if (vel > 0.8) {
      return {
        icon: ArrowUpRight,
        label: 'Rising',
        color: 'text-amber-600 bg-amber-50 border-amber-200',
        badge: 'Rise 0.8–2.0 mg/dL/min'
      };
    }
    if (vel < -2.0) {
      return {
        icon: ArrowDown,
        label: 'Rapidly Falling',
        color: 'text-rose-600 bg-rose-50 border-rose-200',
        badge: 'Drop > 2.0 mg/dL/min'
      };
    }
    if (vel < -0.8) {
      return {
        icon: ArrowDownRight,
        label: 'Falling',
        color: 'text-teal-600 bg-teal-50 border-teal-200',
        badge: 'Drop 0.8–2.0 mg/dL/min'
      };
    }
    return {
      icon: ArrowRight,
      label: 'Stable',
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
      badge: 'Steady (±0.8 mg/dL/min)'
    };
  };

  const velDetails = getVelocityDetails(currentReading.glucoseVelocity);
  const TrendIcon = velDetails.icon;

  // Target status
  const isHypo = currentReading.glucose < patient.hypoglycemiaThreshold;
  const isHyper = currentReading.glucose > patient.hyperglycemiaThreshold;
  const inRange = !isHypo && !isHyper;

  // Sleep hours breakdown
  const sleepHours = Math.floor(currentReading.sleepMinutesPriorNight / 60);
  const sleepMins = currentReading.sleepMinutesPriorNight % 60;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* 1. CGM Sensor Telemetry */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 flex flex-col justify-between relative overflow-hidden group hover:border-teal-300 transition-all">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                CGM Glucose
              </span>
              <p className="text-[11px] text-slate-400">Continuous 5-min stream</p>
            </div>
          </div>
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold border ${
              inRange
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : isHyper
                ? 'bg-amber-50 text-amber-700 border-amber-200'
                : 'bg-rose-50 text-rose-700 border-rose-200'
            }`}
          >
            {inRange ? 'In Target Range' : isHyper ? 'Elevated (>180)' : 'Hypoglycemia (<70)'}
          </span>
        </div>

        <div className="my-3 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 font-mono">
              {currentReading.glucose}
            </span>
            <span className="text-xs font-semibold text-slate-500">mg/dL</span>
          </div>

          <div
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border ${velDetails.color}`}
          >
            <TrendIcon className="w-4 h-4 stroke-[2.5]" />
            <span>
              {currentReading.glucoseVelocity > 0 ? '+' : ''}
              {currentReading.glucoseVelocity.toFixed(2)}
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
          <span>Target: {patient.targetGlucoseRange[0]}–{patient.targetGlucoseRange[1]} mg/dL</span>
          <span className="font-medium text-slate-600">{velDetails.label}</span>
        </div>
      </div>

      {/* 2. Optical Heart Rate (PPG) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 flex flex-col justify-between relative overflow-hidden group hover:border-rose-300 transition-all">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Heart Rate (PPG)
              </span>
              <p className="text-[11px] text-slate-400">Wearable optical pulse</p>
            </div>
          </div>
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600">
            Live
          </span>
        </div>

        <div className="my-3 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 font-mono">
              {currentReading.heartRate}
            </span>
            <span className="text-xs font-semibold text-slate-500">bpm</span>
          </div>
          <div className="text-right">
            <span className="text-xs font-medium text-slate-600">
              {currentReading.heartRate > 85 ? 'Elevated / Active' : 'Resting Baseline'}
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
          <span>Resting: ~68 bpm</span>
          <span>HRV stress index: Normal</span>
        </div>
      </div>

      {/* 3. Physical Steps & Activity */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 flex flex-col justify-between relative overflow-hidden group hover:border-indigo-300 transition-all">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
              <Footprints className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Daily Steps
              </span>
              <p className="text-[11px] text-slate-400">Accelerometer telemetry</p>
            </div>
          </div>
          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <Zap className="w-3 h-3 text-indigo-500" />
            GLUT4 Sink
          </span>
        </div>

        <div className="my-3 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 font-mono">
              {currentReading.cumulativeStepsToday.toLocaleString()}
            </span>
            <span className="text-xs font-semibold text-slate-500">steps</span>
          </div>
          <div className="text-right">
            <span className="text-xs font-medium text-slate-700">
              +{recentSteps60m} in past hr
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
          <span>Goal: 8,000 steps</span>
          <span>
            {Math.round((currentReading.cumulativeStepsToday / 8000) * 100)}% of daily target
          </span>
        </div>
      </div>

      {/* 4. Sleep Staging & Quality */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 flex flex-col justify-between relative overflow-hidden group hover:border-blue-300 transition-all">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Prior Sleep
              </span>
              <p className="text-[11px] text-slate-400">Nocturnal recovery</p>
            </div>
          </div>
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            Score: {currentReading.sleepQualityScore}/100
          </span>
        </div>

        <div className="my-3 flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 font-mono">
              {sleepHours}h {sleepMins}m
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs font-medium text-slate-600">
              {currentReading.sleepMinutesPriorNight >= 420 ? 'Optimal' : 'Mild Deficit'}
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
          <span>Insulin Sensitivity impact:</span>
          <span className="font-medium text-slate-700">
            {currentReading.sleepMinutesPriorNight >= 420 ? 'Preserved' : 'Reduced ~12%'}
          </span>
        </div>
      </div>
    </div>
  );
};
