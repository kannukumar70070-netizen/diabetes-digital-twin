/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Clock,
  Layers,
  Heart,
  Footprints,
  Eye,
  Info,
  Calendar,
  Compass
} from 'lucide-react';
import type { SensorReading, SyntheticPatient, ForecastPoint } from '../types/diabetes';

interface GlucoseChartProps {
  readings: SensorReading[];
  patient: SyntheticPatient;
  forecastTrajectory: ForecastPoint[];
  threshold: number;
}

export type Timeframe = '6h' | '12h' | '24h' | '7d';

export const GlucoseChart: React.FC<GlucoseChartProps> = ({
  readings,
  patient,
  forecastTrajectory,
  threshold
}) => {
  const [timeframe, setTimeframe] = useState<Timeframe>('24h');
  const [showSecondaryStream, setShowSecondaryStream] = useState<'none' | 'heartRate' | 'steps'>('heartRate');
  const [showCounterfactual, setShowCounterfactual] = useState<boolean>(true);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Filter readings based on timeframe
  const filteredReadings = useMemo(() => {
    if (readings.length === 0) return [];
    const latest = readings[readings.length - 1].timestamp;
    let windowMs = 24 * 3600 * 1000;
    if (timeframe === '6h') windowMs = 6 * 3600 * 1000;
    else if (timeframe === '12h') windowMs = 12 * 3600 * 1000;
    else if (timeframe === '7d') windowMs = 7 * 24 * 3600 * 1000;

    const cutoff = latest - windowMs;
    return readings.filter(r => r.timestamp >= cutoff);
  }, [readings, timeframe]);

  // Calculate Time-in-Range (TIR) metrics for the active timeframe
  const tirMetrics = useMemo(() => {
    if (filteredReadings.length === 0) return { inRange: 0, high: 0, low: 0 };
    let inR = 0;
    let high = 0;
    let low = 0;
    filteredReadings.forEach(r => {
      if (r.glucose < patient.hypoglycemiaThreshold) low++;
      else if (r.glucose > patient.hyperglycemiaThreshold) high++;
      else inR++;
    });
    const total = filteredReadings.length;
    return {
      inRange: Math.round((inR / total) * 100),
      high: Math.round((high / total) * 100),
      low: Math.round((low / total) * 100)
    };
  }, [filteredReadings, patient]);

  // SVG dimensions
  const width = 900;
  const height = 340;
  const padding = { top: 25, right: 80, bottom: 40, left: 55 };
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  // Scales
  const minG = 40;
  const maxG = 300;

  const getY = (val: number) => {
    const clamped = Math.max(minG, Math.min(maxG, val));
    return padding.top + plotHeight - ((clamped - minG) / (maxG - minG)) * plotHeight;
  };

  // Forecast time points (extending 2 hours past latest reading)
  const latestTimestamp = readings.length > 0 ? readings[readings.length - 1].timestamp : Date.now();
  const forecastEndTimestamp = latestTimestamp + 120 * 60 * 1000;
  const startTimestamp = filteredReadings.length > 0 ? filteredReadings[0].timestamp : latestTimestamp - 24 * 3600 * 1000;
  const totalChartTimeRange = forecastEndTimestamp - startTimestamp;

  const getX = (timestamp: number) => {
    const fraction = (timestamp - startTimestamp) / totalChartTimeRange;
    return padding.left + fraction * plotWidth;
  };

  // Build SVG path for historical CGM line
  const historicalPath = useMemo(() => {
    if (filteredReadings.length === 0) return '';
    return filteredReadings.reduce((acc, r, i) => {
      const x = getX(r.timestamp);
      const y = getY(r.glucose);
      return i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : `${acc} L ${x.toFixed(1)} ${y.toFixed(1)}`;
    }, '');
  }, [filteredReadings]);

  // Build SVG path for historical CGM area gradient fill
  const historicalAreaPath = useMemo(() => {
    if (filteredReadings.length === 0) return '';
    const firstX = getX(filteredReadings[0].timestamp);
    const lastX = getX(filteredReadings[filteredReadings.length - 1].timestamp);
    const baseY = getY(minG);
    return `${historicalPath} L ${lastX.toFixed(1)} ${baseY.toFixed(1)} L ${firstX.toFixed(1)} ${baseY.toFixed(1)} Z`;
  }, [historicalPath, filteredReadings]);

  // Build Forecast 2-Hour projection line and 95% CI cone
  const forecastPaths = useMemo(() => {
    if (forecastTrajectory.length === 0 || filteredReadings.length === 0) return null;
    const currentReading = filteredReadings[filteredReadings.length - 1];

    // Projection points
    const projPoints = forecastTrajectory.map(pt => {
      const ts = currentReading.timestamp + pt.timeOffsetMinutes * 60 * 1000;
      return {
        x: getX(ts),
        yProj: getY(pt.projectedGlucose),
        yLower: getY(pt.lowerConfidence95),
        yUpper: getY(pt.upperConfidence95),
        yWalk: pt.counterfactualWalkGlucose ? getY(pt.counterfactualWalkGlucose) : undefined
      };
    });

    // Baseline projection line
    const projLine = projPoints.reduce((acc, p, i) => {
      return i === 0 ? `M ${p.x.toFixed(1)} ${p.yProj.toFixed(1)}` : `${acc} L ${p.x.toFixed(1)} ${p.yProj.toFixed(1)}`;
    }, '');

    // Heuristic Uncertainty Dispersion polygon (widens over 2-hour projection horizon; not a parametric 95% CI)
    const upperPoints = projPoints.map(p => `${p.x.toFixed(1)} ${p.yUpper.toFixed(1)}`).join(' L ');
    const lowerPoints = [...projPoints].reverse().map(p => `${p.x.toFixed(1)} ${p.yLower.toFixed(1)}`).join(' L ');
    const ciPolygon = `M ${upperPoints} L ${lowerPoints} Z`;

    // Counterfactual walk line
    const walkLine = projPoints.reduce((acc, p, i) => {
      if (p.yWalk === undefined) return acc;
      return i === 0 ? `M ${p.x.toFixed(1)} ${p.yWalk.toFixed(1)}` : `${acc} L ${p.x.toFixed(1)} ${p.yWalk.toFixed(1)}`;
    }, '');

    return { projLine, ciPolygon, walkLine, projPoints };
  }, [forecastTrajectory, filteredReadings]);

  // Secondary stream: HR or Steps
  const maxHR = 160;
  const minHR = 50;
  const maxSteps = 1500;

  const getSecondaryY = (val: number, type: 'heartRate' | 'steps') => {
    if (type === 'heartRate') {
      const clamped = Math.max(minHR, Math.min(maxHR, val));
      return padding.top + plotHeight - ((clamped - minHR) / (maxHR - minHR)) * (plotHeight * 0.7);
    }
    const clamped = Math.min(maxSteps, val);
    return padding.top + plotHeight - (clamped / maxSteps) * (plotHeight * 0.45);
  };

  // Target Range Band coordinates
  const targetTopY = getY(patient.targetGlucoseRange[1]);
  const targetBottomY = getY(patient.targetGlucoseRange[0]);
  const targetBandHeight = targetBottomY - targetTopY;
  const thresholdY = getY(threshold);

  // Time ticks on X axis
  const timeTicks = useMemo(() => {
    if (filteredReadings.length === 0) return [];
    const count = 6;
    const ticks: { ts: number; label: string; x: number }[] = [];
    const step = totalChartTimeRange / count;
    for (let i = 0; i <= count; i++) {
      const ts = startTimestamp + i * step;
      const d = new Date(ts);
      const label = timeframe === '7d'
        ? d.toLocaleDateString([], { weekday: 'short', month: 'numeric', day: 'numeric' })
        : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      ticks.push({ ts, label, x: getX(ts) });
    }
    return ticks;
  }, [filteredReadings, timeframe, startTimestamp, totalChartTimeRange]);

  // Hover reading
  const activeReading = hoverIndex !== null && filteredReadings[hoverIndex]
    ? filteredReadings[hoverIndex]
    : filteredReadings[filteredReadings.length - 1];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 transition-all">
      {/* Chart Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-4 border-b border-slate-100 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-teal-600" />
              Continuous Glycemic & Sensor Telemetry
            </h3>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
              5-min Resolution
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time CGM curve with +2h forward physiological projection cone & target range
          </p>
        </div>

        {/* Action Controls & Timeframe Selector */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Secondary stream toggle */}
          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5 text-xs">
            <span className="px-2 py-1 text-slate-500 font-medium text-[11px]">Overlay:</span>
            <button
              type="button"
              onClick={() => setShowSecondaryStream('none')}
              className={`px-2 py-1 rounded font-medium cursor-pointer transition-colors ${
                showSecondaryStream === 'none' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              None
            </button>
            <button
              type="button"
              onClick={() => setShowSecondaryStream('heartRate')}
              className={`px-2 py-1 rounded font-medium flex items-center gap-1 cursor-pointer transition-colors ${
                showSecondaryStream === 'heartRate' ? 'bg-white shadow-2xs text-rose-600 font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Heart className="w-3 h-3 text-rose-500" />
              Heart Rate
            </button>
            <button
              type="button"
              onClick={() => setShowSecondaryStream('steps')}
              className={`px-2 py-1 rounded font-medium flex items-center gap-1 cursor-pointer transition-colors ${
                showSecondaryStream === 'steps' ? 'bg-white shadow-2xs text-indigo-600 font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Footprints className="w-3 h-3 text-indigo-500" />
              Steps
            </button>
          </div>

          {/* Counterfactual toggle */}
          <button
            type="button"
            onClick={() => setShowCounterfactual(!showCounterfactual)}
            className={`px-2.5 py-1 text-xs font-medium rounded-lg border flex items-center gap-1.5 transition-colors cursor-pointer ${
              showCounterfactual
                ? 'bg-teal-50 border-teal-200 text-teal-800'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
            title="Toggle Counterfactual 15-min Brisk Walk Projection Curve"
          >
            <Compass className="w-3.5 h-3.5 text-teal-600" />
            <span>Counterfactual Walk</span>
          </button>

          {/* Timeframe Buttons */}
          <div className="flex items-center bg-slate-100 rounded-lg p-0.5 text-xs font-semibold">
            {(['6h', '12h', '24h', '7d'] as Timeframe[]).map(tf => (
              <button
                key={tf}
                type="button"
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                  timeframe === tf
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tf.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Time-In-Range (TIR) Banner */}
      <div className="py-2.5 flex flex-wrap items-center justify-between text-xs gap-3 border-b border-slate-100">
        <div className="flex items-center gap-4">
          <span className="font-semibold text-slate-700">Time In Range ({timeframe}):</span>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span>
              In Range (70–180): {tirMetrics.inRange}%
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-400"></span>
              High (&gt;180): {tirMetrics.high}%
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-rose-700">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500"></span>
              Low (&lt;70): {tirMetrics.low}%
            </span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-[11px] text-slate-500">
          <span className="flex items-center gap-1">
            <span className="w-3 h-0.5 bg-teal-600"></span>
            Past CGM
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-0.5 border-t-2 border-dashed border-teal-600"></span>
            +2h Forecast
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-xs bg-teal-500/20 border border-teal-500/40"></span>
            Dispersion Cone (Heuristic)
          </span>
          {showCounterfactual && (
            <span className="flex items-center gap-1">
              <span className="w-3 h-0.5 border-t-2 border-dotted border-emerald-500"></span>
              What-If: Walk
            </span>
          )}
        </div>
      </div>

      {/* SVG Interactive Chart Canvas */}
      <div className="relative mt-3 w-full overflow-x-auto">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto select-none overflow-visible"
          onMouseLeave={() => setHoverIndex(null)}
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const mouseX = ((e.clientX - rect.left) / rect.width) * width;
            if (mouseX >= padding.left && mouseX <= getX(latestTimestamp)) {
              // Map mouseX to closest historical reading
              const fraction = (mouseX - padding.left) / (getX(latestTimestamp) - padding.left);
              const targetIdx = Math.round(fraction * (filteredReadings.length - 1));
              if (targetIdx >= 0 && targetIdx < filteredReadings.length) {
                setHoverIndex(targetIdx);
              }
            } else {
              setHoverIndex(null);
            }
          }}
        >
          <defs>
            {/* CGM Area Gradient */}
            <linearGradient id="cgmGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0d9488" stopOpacity="0.22" />
              <stop offset="80%" stopColor="#0d9488" stopOpacity="0.02" />
              <stop offset="100%" stopColor="#0d9488" stopOpacity="0.0" />
            </linearGradient>

            {/* Projection Cone Gradient */}
            <linearGradient id="coneGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.30" />
              <stop offset="100%" stopColor="#14b8a6" stopOpacity="0.08" />
            </linearGradient>
          </defs>

          {/* Shaded Target Glucose Range Band (70 to 180 mg/dL) */}
          <rect
            x={padding.left}
            y={targetTopY}
            width={plotWidth}
            height={targetBandHeight}
            fill="#10b981"
            fillOpacity="0.07"
            rx="4"
          />

          {/* Horizontal Grid lines */}
          {[70, 100, 140, 180, 240].map(val => (
            <g key={val}>
              <line
                x1={padding.left}
                y1={getY(val)}
                x2={width - padding.right}
                y2={getY(val)}
                stroke="#e2e8f0"
                strokeWidth="1"
                strokeDasharray={val === 70 || val === 180 ? 'none' : '2 4'}
              />
              <text
                x={padding.left - 8}
                y={getY(val) + 4}
                textAnchor="end"
                className="text-[10px] fill-slate-500 font-mono"
              >
                {val}
              </text>
            </g>
          ))}

          {/* Y-axis label */}
          <text
            x={16}
            y={height / 2}
            textAnchor="middle"
            transform={`rotate(-90 16 ${height / 2})`}
            className="text-[11px] fill-slate-500 font-semibold"
          >
            Glucose (mg/dL)
          </text>

          {/* Hyperglycemia Threshold Line (Dashed Alert) */}
          <line
            x1={padding.left}
            y1={thresholdY}
            x2={width - padding.right}
            y2={thresholdY}
            stroke="#f59e0b"
            strokeWidth="1.5"
            strokeDasharray="4 4"
          />
          <text
            x={width - padding.right + 6}
            y={thresholdY + 3}
            className="text-[10px] fill-amber-700 font-bold font-mono"
          >
            Threshold {threshold}
          </text>

          {/* Secondary Stream: Steps (Bars) */}
          {showSecondaryStream === 'steps' && (
            <g opacity="0.35">
              {filteredReadings.map((r, i) => {
                if (r.steps === 0) return null;
                const x = getX(r.timestamp);
                const barY = getSecondaryY(r.steps, 'steps');
                const barH = padding.top + plotHeight - barY;
                return (
                  <rect
                    key={i}
                    x={x - 1.5}
                    y={barY}
                    width={3}
                    height={barH}
                    fill="#6366f1"
                    rx="1"
                  />
                );
              })}
            </g>
          )}

          {/* Secondary Stream: Heart Rate (Line) */}
          {showSecondaryStream === 'heartRate' && (
            <path
              d={filteredReadings.reduce((acc, r, i) => {
                const x = getX(r.timestamp);
                const y = getSecondaryY(r.heartRate, 'heartRate');
                return i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : `${acc} L ${x.toFixed(1)} ${y.toFixed(1)}`;
              }, '')}
              fill="none"
              stroke="#f43f5e"
              strokeWidth="1.2"
              strokeOpacity="0.45"
            />
          )}

          {/* Historical CGM Area Fill */}
          <path d={historicalAreaPath} fill="url(#cgmGradient)" />

          {/* Historical CGM Telemetry Path */}
          <path
            d={historicalPath}
            fill="none"
            stroke="#0d9488"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Event Markers (Meals, Exercise) on Historical Line */}
          {filteredReadings.map((r, i) => {
            if (!r.eventMarker) return null;
            const x = getX(r.timestamp);
            const y = getY(r.glucose);
            const isMeal = r.eventMarker === 'meal';
            const isEx = r.eventMarker === 'exercise';

            return (
              <g key={i} className="cursor-pointer">
                <circle
                  cx={x}
                  cy={y}
                  r="4.5"
                  fill={isMeal ? '#f59e0b' : isEx ? '#10b981' : '#6366f1'}
                  stroke="#ffffff"
                  strokeWidth="2"
                />
              </g>
            );
          })}

          {/* "NOW / CURRENT" Vertical Separator Line */}
          <line
            x1={getX(latestTimestamp)}
            y1={padding.top}
            x2={getX(latestTimestamp)}
            y2={padding.top + plotHeight}
            stroke="#0f172a"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
          <text
            x={getX(latestTimestamp)}
            y={padding.top - 8}
            textAnchor="middle"
            className="text-[10px] fill-slate-800 font-bold tracking-wider uppercase"
          >
            Now (t)
          </text>

          {/* +2-HOUR DIGITAL TWIN FORECAST CONE */}
          {forecastPaths && (
            <g>
              {/* Heuristic Uncertainty Dispersion Shaded Cone (not a parametric 95% CI) */}
              <path
                d={forecastPaths.ciPolygon}
                fill="url(#coneGradient)"
              />

              {/* Baseline Projected Trajectory Line */}
              <path
                d={forecastPaths.projLine}
                fill="none"
                stroke="#0d9488"
                strokeWidth="2"
                strokeDasharray="4 4"
                strokeLinecap="round"
              />

              {/* Counterfactual Walk Line */}
              {showCounterfactual && (
                <path
                  d={forecastPaths.walkLine}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2"
                  strokeDasharray="2 3"
                  strokeLinecap="round"
                />
              )}

              {/* Forecast points */}
              {forecastPaths.projPoints.map((pt, i) => (
                <circle
                  key={i}
                  cx={pt.x}
                  cy={pt.yProj}
                  r={i === forecastPaths.projPoints.length - 1 ? '4' : '2'}
                  fill="#0d9488"
                />
              ))}

              {/* +120m forecast label */}
              <text
                x={forecastPaths.projPoints[forecastPaths.projPoints.length - 1].x}
                y={padding.top - 8}
                textAnchor="middle"
                className="text-[10px] fill-teal-700 font-bold uppercase"
              >
                +2h Forecast
              </text>
            </g>
          )}

          {/* Hover Crosshair */}
          {hoverIndex !== null && activeReading && (
            <g>
              <line
                x1={getX(activeReading.timestamp)}
                y1={padding.top}
                x2={getX(activeReading.timestamp)}
                y2={padding.top + plotHeight}
                stroke="#64748b"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              <circle
                cx={getX(activeReading.timestamp)}
                cy={getY(activeReading.glucose)}
                r="6"
                fill="#0d9488"
                stroke="#ffffff"
                strokeWidth="2.5"
                className="shadow"
              />
            </g>
          )}

          {/* X-axis ticks & labels */}
          {timeTicks.map((tick, i) => (
            <g key={i}>
              <line
                x1={tick.x}
                y1={padding.top + plotHeight}
                x2={tick.x}
                y2={padding.top + plotHeight + 5}
                stroke="#cbd5e1"
                strokeWidth="1"
              />
              <text
                x={tick.x}
                y={padding.top + plotHeight + 18}
                textAnchor="middle"
                className="text-[10px] fill-slate-500 font-medium"
              >
                {tick.label}
              </text>
            </g>
          ))}
        </svg>

        {/* Hover Floating Tooltip card */}
        {activeReading && (
          <div className="mt-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-wrap items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-semibold text-slate-700">
                {new Date(activeReading.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  month: 'short',
                  day: 'numeric'
                })}
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-baseline gap-1">
                <span className="text-slate-500 text-[11px]">Glucose:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">
                  {activeReading.glucose} mg/dL
                </span>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-slate-500 text-[11px]">Velocity:</span>
                <span className="font-semibold text-slate-800 font-mono">
                  {activeReading.glucoseVelocity > 0 ? '+' : ''}
                  {activeReading.glucoseVelocity.toFixed(2)} mg/dL/min
                </span>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-slate-500 text-[11px]">Heart Rate:</span>
                <span className="font-semibold text-rose-600 font-mono">
                  {activeReading.heartRate} bpm
                </span>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-slate-500 text-[11px]">5-min Steps:</span>
                <span className="font-semibold text-indigo-600 font-mono">
                  {activeReading.steps}
                </span>
              </div>
            </div>

            {activeReading.eventDescription && (
              <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-medium">
                <span>{activeReading.eventDescription}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
