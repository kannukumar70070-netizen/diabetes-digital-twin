/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  User,
  Sliders,
  FileText,
  BarChart3,
  BookOpen,
  Download,
  Plus,
  ShieldCheck,
  Sparkles,
  Bell,
  Layers,
  Flame,
  CheckCircle2,
  Trash2
} from 'lucide-react';
import type { SyntheticPatient, ActiveTab, ToastAlert } from '../types/diabetes';

interface HeaderProps {
  patients: SyntheticPatient[];
  selectedPatient: SyntheticPatient;
  onSelectPatient: (patient: SyntheticPatient) => void;
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenCustomPatientModal: () => void;
  onExportData: () => void;
  recentAlerts: ToastAlert[];
  onTriggerTestToast: () => void;
  onClearAlerts: () => void;
  onToastAction: (toast: ToastAlert) => void;
}

export const Header: React.FC<HeaderProps> = ({
  patients,
  selectedPatient,
  onSelectPatient,
  activeTab,
  onSelectTab,
  onOpenCustomPatientModal,
  onExportData,
  recentAlerts,
  onTriggerTestToast,
  onClearAlerts,
  onToastAction
}) => {
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const unreadCount = recentAlerts.filter(a => !a.isRead).length;
  return (
    <header className="bg-white border-b border-slate-200/80 sticky top-0 z-40 shadow-xs">
      {/* Top Banner: Competition and Synthetic Disclosure */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30">
            <Sparkles className="w-3 h-3 mr-1 text-teal-400" />
            Happiest Health Digital Twin Challenge 2026
          </span>
          <span className="hidden sm:inline text-slate-400">|</span>
          <span className="text-slate-300 hidden md:inline">
            Predictive Multi-Sensor Glycemic Digital Twin
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center text-[11px] text-amber-300/90 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mr-1.5 animate-pulse"></span>
            Synthetic Telemetry • Demo Environment (Zero Data Leakage)
          </span>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand & Title */}
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 via-teal-500 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-teal-500/20">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Diabetes Digital Twin
              </h1>
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold bg-teal-50 text-teal-700 border border-teal-200">
                Research Prototype
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Physiological forecasting of 2-hour glycemic excursions from dual data streams
            </p>
          </div>
        </div>

        {/* Patient Switcher & Actions */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* Patient Selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <User className="w-4 h-4 text-slate-500 ml-1.5" />
            <select
              aria-label="Select Synthetic Patient Profile"
              value={selectedPatient.id}
              onChange={(e) => {
                const found = patients.find(p => p.id === e.target.value);
                if (found) onSelectPatient(found);
              }}
              className="bg-transparent text-xs font-semibold text-slate-800 pr-6 py-1 pl-1 focus:outline-none cursor-pointer"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.diagnosis}, {p.age}y)
                </option>
              ))}
            </select>
          </div>

          {/* New Custom Patient Button */}
          <button
            type="button"
            onClick={onOpenCustomPatientModal}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors shadow-2xs cursor-pointer"
            title="Create Custom Synthetic Patient Profile"
          >
            <Plus className="w-3.5 h-3.5 text-teal-600" />
            <span className="hidden sm:inline">New Profile</span>
          </button>

          {/* Alert Notifications Bell */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsAlertsOpen(!isAlertsOpen)}
              className="relative p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
              title="Forecasting Alert Notifications"
            >
              <Bell className="w-4 h-4 text-slate-600" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-xs">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown Panel */}
            {isAlertsOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsAlertsOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white border border-slate-200 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <Bell className="w-4 h-4 text-teal-600" />
                      <span className="text-xs font-bold text-slate-900">
                        Excursion Alert History
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={onTriggerTestToast}
                        className="text-[10px] font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 px-2 py-0.5 rounded transition-colors cursor-pointer"
                        title="Simulate high-risk excursion alert toast"
                      >
                        + Test Alert
                      </button>
                      {recentAlerts.length > 0 && (
                        <button
                          type="button"
                          onClick={onClearAlerts}
                          className="text-[10px] text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                          title="Clear alert list"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {recentAlerts.length === 0 ? (
                      <div className="py-6 text-center text-xs text-slate-400">
                        No active excursion alerts. Telemetry is within target limits.
                      </div>
                    ) : (
                      recentAlerts.map(alert => (
                        <div
                          key={alert.id}
                          className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                            alert.riskTier === 'Critical'
                              ? 'bg-rose-50/70 border-rose-200 hover:bg-rose-100/70'
                              : 'bg-amber-50/70 border-amber-200 hover:bg-amber-100/70'
                          }`}
                          onClick={() => {
                            onToastAction(alert);
                            setIsAlertsOpen(false);
                          }}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900 flex items-center gap-1">
                              {alert.riskTier === 'Critical' ? (
                                <Flame className="w-3.5 h-3.5 text-rose-600" />
                              ) : (
                                <Bell className="w-3.5 h-3.5 text-amber-600" />
                              )}
                              {alert.title}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500">
                              {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                            {alert.message}
                          </p>
                          <div className="flex items-center justify-between mt-2 pt-1 border-t border-black/5 text-[10px]">
                            <span className="font-semibold text-slate-700">
                              {alert.patientName} • Peak {alert.predictedPeak} mg/dL
                            </span>
                            <span className="text-teal-700 font-bold hover:underline">
                              Open What-If →
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Export Dataset Button */}
          <button
            type="button"
            onClick={onExportData}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-900 rounded-lg transition-colors shadow-2xs cursor-pointer"
            title="Download Reproducible Synthetic Dataset (JSON)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Data</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-100 flex items-center overflow-x-auto gap-1 py-1">
        <button
          type="button"
          onClick={() => onSelectTab('overview')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Activity className="w-4 h-4 text-teal-600" />
          Dashboard Overview
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('simulator')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'simulator'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Sliders className="w-4 h-4 text-teal-600" />
          What-If Simulator & Counterfactuals
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('3d_twin')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === '3d_twin'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Layers className="w-4 h-4 text-teal-600" />
          3D Organ & Cell Twin
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('clinical_dossier')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'clinical_dossier'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <FileText className="w-4 h-4 text-teal-600" />
          Doctor Clinical Dossier & Audit Log
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('evaluation')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'evaluation'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-teal-600" />
          Model Evaluation & Benchmark
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('methodology')}
          className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'methodology'
              ? 'bg-teal-50 text-teal-700 border border-teal-200/80 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <BookOpen className="w-4 h-4 text-teal-600" />
          Data & Methodology
        </button>
      </div>
    </header>
  );
};
