/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  User,
  Pill,
  Calendar,
  Scale,
  HeartPulse,
  Info,
  ShieldCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import type { SyntheticPatient } from '../types/diabetes';

interface PatientSummaryCardProps {
  patient: SyntheticPatient;
}

export const PatientSummaryCard: React.FC<PatientSummaryCardProps> = ({ patient }) => {
  // Estimated Average Glucose (ADAG formula: eAG = 28.7 * A1c - 46.7)
  const eAG = Math.round(28.7 * patient.baselineHbA1c - 46.7);

  // BMI Category
  const getBmiCategory = (bmi: number) => {
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal Weight';
    if (bmi < 30) return 'Overweight';
    return 'Obese (Class I/II)';
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 transition-all">
      {/* Top Banner: Identification and Synthetic Tag */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 text-teal-700 flex items-center justify-center font-bold text-lg shadow-2xs">
            {patient.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900">{patient.name}</h2>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                {patient.diagnosis}
              </span>
              {patient.isCustom && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Custom
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
              <span>Patient ID: <strong className="text-slate-700 font-mono">{patient.id}</strong></span>
              <span>•</span>
              <span>{patient.gender}, {patient.age} years old</span>
              <span>•</span>
              <span>Diagnosed {patient.diagnosisYears} yrs ago</span>
            </p>
          </div>
        </div>

        {/* Synthetic Profile Notice */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
          <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
          <span>Synthetic Patient Record (Zero Leakage Ensured)</span>
        </div>
      </div>

      {/* Grid of Key Historical Biomarkers */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-4 border-b border-slate-100">
        {/* Baseline HbA1c */}
        <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">Baseline HbA1c</span>
            <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold text-slate-900">{patient.baselineHbA1c.toFixed(1)}%</span>
            <span className="text-xs text-slate-500">eAG ~{eAG} mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {patient.baselineHbA1c >= 8.0 ? 'Elevated baseline' : patient.baselineHbA1c >= 7.0 ? 'Moderate elevation' : 'Near target'}
          </p>
        </div>

        {/* BMI & Body Composition */}
        <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">BMI</span>
            <Scale className="w-3.5 h-3.5 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold text-slate-900">{patient.bmi.toFixed(1)}</span>
            <span className="text-xs text-slate-500">kg/m²</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {getBmiCategory(patient.bmi)}
          </p>
        </div>

        {/* Target Range */}
        <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">Target Glucose</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold text-slate-900">
              {patient.targetGlucoseRange[0]}–{patient.targetGlucoseRange[1]}
            </span>
            <span className="text-xs text-slate-500">mg/dL</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Threshold: &gt;{patient.hyperglycemiaThreshold} mg/dL
          </p>
        </div>

        {/* Medication Adherence */}
        <div className="p-3 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-medium">Rx Adherence</span>
            <Pill className="w-3.5 h-3.5 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold text-slate-900">
              {patient.medications.length > 0
                ? `${Math.round(
                    (patient.medications.reduce((s, m) => s + m.complianceRate, 0) /
                      patient.medications.length) *
                      100
                  )}%`
                : 'N/A'}
            </span>
            <span className="text-xs text-slate-500">{patient.medications.length} active</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {patient.medications.length > 0 ? patient.medications[0].class : 'Lifestyle'}
          </p>
        </div>
      </div>

      {/* Bottom Section: Active Medications & Clinical Phenotype Note */}
      <div className="pt-3.5 flex flex-col md:flex-row gap-4 justify-between items-start">
        {/* Medication Badges */}
        <div className="flex-1">
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Pill className="w-3.5 h-3.5 text-teal-600" />
            Active Pharmacotherapy Regimen
          </h3>
          <div className="flex flex-wrap gap-2">
            {patient.medications.map((med, idx) => (
              <div
                key={idx}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-teal-50/60 border border-teal-200/70 text-xs text-teal-900"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600"></span>
                <span className="font-semibold">{med.name}</span>
                <span className="text-teal-700">({med.dosage}, {med.frequency})</span>
                <span className="text-[10px] bg-teal-200/60 px-1 py-0.5 rounded text-teal-800 font-mono font-medium">
                  {Math.round(med.complianceRate * 100)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Clinical Notes */}
        <div className="md:max-w-md w-full bg-slate-50/80 rounded-xl p-3 border border-slate-200/60">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-1">
            <Info className="w-3.5 h-3.5 text-teal-600" />
            <span>Digital Twin Phenotype Notes</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            {patient.clinicalNotes}
          </p>
        </div>
      </div>
    </div>
  );
};
