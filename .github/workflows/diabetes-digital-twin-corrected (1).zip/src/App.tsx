/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Diabetes Digital Twin - Main Application Container
 * Happiest Health Digital Twin Challenge 2026
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { SyntheticPatient, ActiveTab, SensorReading, ToastAlert } from './types/diabetes';
import { SYNTHETIC_PATIENTS, generateSyntheticTelemetry } from './ml/syntheticData';
import { extractFeaturesAtTime, predictExcursion } from './ml/twinPredictor';
import { generateEvaluationTestSet, buildPredictionHistory } from './ml/evaluation';

import { Header } from './components/Header';
import { PatientSummaryCard } from './components/PatientSummaryCard';
import { SensorGauges } from './components/SensorGauges';
import { GlucoseChart } from './components/GlucoseChart';
import { PredictionCard } from './components/PredictionCard';
import { InteractiveSimulator } from './components/InteractiveSimulator';
import { DoctorDossierView } from './components/DoctorDossierView';
import { ModelEvaluationView } from './components/ModelEvaluationView';
import { MethodologyView } from './components/MethodologyView';
import { CustomPatientModal } from './components/CustomPatientModal';
import { ToastNotificationContainer } from './components/ToastNotification';
import { Physiological3DViewer } from './components/Physiological3DViewer';

export default function App() {
  const [patients, setPatients] = useState<SyntheticPatient[]>(SYNTHETIC_PATIENTS);
  const [selectedPatient, setSelectedPatient] = useState<SyntheticPatient>(SYNTHETIC_PATIENTS[0]);
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [threshold, setThreshold] = useState<number>(selectedPatient.hyperglycemiaThreshold);
  const [isCustomModalOpen, setIsCustomModalOpen] = useState<boolean>(false);

  // Toast Notification System State
  const [toasts, setToasts] = useState<ToastAlert[]>([]);
  const [recentAlerts, setRecentAlerts] = useState<ToastAlert[]>([]);
  const [snoozedUntil, setSnoozedUntil] = useState<number | null>(null);
  const lastAlertTimestampRef = useRef<number>(0);

  // Sync threshold when switching patient
  useEffect(() => {
    setThreshold(selectedPatient.hyperglycemiaThreshold);
  }, [selectedPatient]);

  // Generate reproducible 7-day telemetry for active patient
  const telemetry: SensorReading[] = useMemo(() => {
    return generateSyntheticTelemetry(selectedPatient, 7);
  }, [selectedPatient]);

  // Current reading is the latest epoch at time t
  const currentReading: SensorReading = useMemo(() => {
    return telemetry[telemetry.length - 1];
  }, [telemetry]);

  // Extract zero-leakage feature vector at time t
  const currentFeatures = useMemo(() => {
    return extractFeaturesAtTime(selectedPatient, telemetry, currentReading.timestamp);
  }, [selectedPatient, telemetry, currentReading]);

  // Compute live 2-hour Digital Twin prediction
  const livePrediction = useMemo(() => {
    return predictExcursion(currentFeatures, threshold);
  }, [currentFeatures, threshold]);

  // Toast trigger helper
  const addToastAlert = (alert: Omit<ToastAlert, 'id' | 'timestamp'>) => {
    const newAlert: ToastAlert = {
      ...alert,
      id: `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now()
    };
    setToasts(prev => [newAlert, ...prev.slice(0, 2)]); // Keep max 3 on screen
    setRecentAlerts(prev => [newAlert, ...prev.slice(0, 19)]); // Keep last 20 in history
  };

  // Automatic excursion detection alert trigger
  useEffect(() => {
    const isNowSnoozed = snoozedUntil && Date.now() < snoozedUntil;
    if (isNowSnoozed) return;

    // Trigger alert if prediction is High/Critical and hasn't alerted in last 10 minutes
    const isHighRisk = livePrediction.riskTier === 'Critical' || (livePrediction.riskTier === 'Elevated' && livePrediction.predictedProbability >= 0.55);
    const cooldownMs = 10 * 60 * 1000;
    const now = Date.now();

    if (isHighRisk && (now - lastAlertTimestampRef.current > cooldownMs)) {
      lastAlertTimestampRef.current = now;
      const peak = livePrediction.expectedPeakGlucose2h;
      const mins = livePrediction.estimatedMinutesToThreshold;
      const horizonText = mins !== null ? (mins === 0 ? 'Already exceeded cutoff' : `Excursion expected in ~${mins} mins`) : 'High probability of excursion';

      addToastAlert({
        type: livePrediction.riskTier === 'Critical' ? 'critical_excursion' : 'elevated_warning',
        title: livePrediction.riskTier === 'Critical' ? 'High-Risk Glycemic Excursion' : 'Elevated Glucose Warning',
        message: `${horizonText}. Projected peak ${peak} mg/dL exceeds >${threshold} mg/dL threshold within next 2 hours.`,
        patientName: selectedPatient.name,
        patientId: selectedPatient.id,
        probability: livePrediction.predictedProbability,
        riskTier: livePrediction.riskTier,
        predictedPeak: peak,
        minutesToThreshold: mins,
        threshold,
        actionType: 'open_simulator_walk',
        actionLabel: 'Test 15-Min Walk in What-If'
      });
    }
  }, [livePrediction, selectedPatient, threshold, snoozedUntil]);

  // Trigger interactive test toast for judges/reviewers
  const handleTriggerTestToast = () => {
    addToastAlert({
      type: 'critical_excursion',
      title: 'High-Risk Excursion Forecast (+2h)',
      message: `Glycemic velocity +2.4 mg/dL/min detected. Projected peak of 248 mg/dL crosses >${threshold} mg/dL in ~35 mins.`,
      patientName: selectedPatient.name,
      patientId: selectedPatient.id,
      probability: 0.88,
      riskTier: 'Critical',
      predictedPeak: 248,
      minutesToThreshold: 35,
      threshold,
      actionType: 'open_simulator_walk',
      actionLabel: 'Test 15-Min Walk in What-If'
    });
  };

  const handleDismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleSnoozeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
    setSnoozedUntil(Date.now() + 15 * 60 * 1000); // Snooze for 15 minutes
  };

  const handleToastAction = (toast: ToastAlert) => {
    handleDismissToast(toast.id);
    setActiveTab('simulator');
  };

  const handleClearAlerts = () => {
    setRecentAlerts([]);
    setToasts([]);
  };

  // Build timestamped prediction audit history for the doctor view
  const predictionHistory = useMemo(() => {
    return buildPredictionHistory(selectedPatient, telemetry, threshold, 14);
  }, [selectedPatient, telemetry, threshold]);

  // Pre-generate evaluation test set across patient cohorts (500 episodes)
  const evaluationSamples = useMemo(() => {
    return generateEvaluationTestSet(threshold, 125);
  }, [threshold]);

  // Handle saving new custom synthetic patient
  const handleSaveCustomPatient = (newPt: SyntheticPatient) => {
    setPatients(prev => [newPt, ...prev]);
    setSelectedPatient(newPt);
  };

  // Export reproducible synthetic dataset as JSON
  const handleExportData = () => {
    const exportPayload = {
      challenge: 'Happiest Health Digital Twin Challenge 2026',
      exportTimestamp: new Date().toISOString(),
      patient: selectedPatient,
      telemetryPoints: telemetry.length,
      samplingIntervalMinutes: 5,
      featuresAtLatestTime: currentFeatures,
      predictionResult: livePrediction,
      telemetrySample: telemetry.slice(-288) // Last 24 hours of 5-min readings
    };

    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `diabetes_digital_twin_${selectedPatient.id}_reproducible.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50/60 text-slate-900 flex flex-col font-sans">
      {/* Toast Notification Container (Floating Top-Right) */}
      <ToastNotificationContainer
        toasts={toasts}
        onDismiss={handleDismissToast}
        onAction={handleToastAction}
        onSnooze={handleSnoozeToast}
      />

      {/* Header */}
      <Header
        patients={patients}
        selectedPatient={selectedPatient}
        onSelectPatient={setSelectedPatient}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenCustomPatientModal={() => setIsCustomModalOpen(true)}
        onExportData={handleExportData}
        recentAlerts={recentAlerts}
        onTriggerTestToast={handleTriggerTestToast}
        onClearAlerts={handleClearAlerts}
        onToastAction={handleToastAction}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Tab 1: Dashboard Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Synthetic Patient Profile Card */}
            <PatientSummaryCard patient={selectedPatient} />

            {/* Live Sensor Telemetry Gauges */}
            <SensorGauges
              currentReading={currentReading}
              patient={selectedPatient}
              recentSteps60m={currentFeatures.recentSteps60m}
            />

            {/* Continuous Glycemic Chart with +2h Forecast Cone */}
            <GlucoseChart
              readings={telemetry}
              patient={selectedPatient}
              forecastTrajectory={livePrediction.trajectory}
              threshold={threshold}
            />

            {/* 2-Hour Excursion Predictor Card with Explainable AI */}
            <PredictionCard
              prediction={livePrediction}
              patient={selectedPatient}
              threshold={threshold}
              onNavigateToSimulator={() => setActiveTab('simulator')}
            />
          </div>
        )}

        {/* Tab 2: Interactive What-If Simulator & Counterfactuals */}
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            <PatientSummaryCard patient={selectedPatient} />
            <InteractiveSimulator
              patient={selectedPatient}
              baseFeatures={currentFeatures}
              threshold={threshold}
              onUpdateThreshold={setThreshold}
            />
          </div>
        )}

        {/* Tab 3: 3D Organ & Cell Twin */}
        {activeTab === '3d_twin' && (
          <div className="space-y-6">
            <PatientSummaryCard patient={selectedPatient} />
            <Physiological3DViewer
              patient={selectedPatient}
              currentGlucose={currentReading.glucose}
              glucoseVelocity={currentReading.glucoseVelocity}
            />
          </div>
        )}

        {/* Tab 4: Doctor Clinical Dossier & Audit Log */}
        {activeTab === 'clinical_dossier' && (
          <div className="space-y-6">
            <PatientSummaryCard patient={selectedPatient} />
            <DoctorDossierView
              patient={selectedPatient}
              recentReadings={telemetry}
              currentPrediction={livePrediction}
              features={currentFeatures}
              predictionHistory={predictionHistory}
              threshold={threshold}
            />
          </div>
        )}

        {/* Tab 5: Model Evaluation & Benchmark */}
        {activeTab === 'evaluation' && (
          <div className="space-y-6">
            <ModelEvaluationView
              evaluationSamples={evaluationSamples}
              threshold={threshold}
            />
          </div>
        )}

        {/* Tab 6: Data Architecture & Methodology */}
        {activeTab === 'methodology' && (
          <div className="space-y-6">
            <MethodologyView />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <span className="font-semibold text-slate-700">Diabetes Digital Twin</span>
            <span className="hidden sm:inline text-slate-300">•</span>
            <span>Happiest Health Digital Twin Challenge 2026</span>
            <span className="hidden sm:inline text-slate-300">•</span>
            <span className="text-teal-700 font-medium">Physiological ML Prototype</span>
          </div>

          <div className="text-center md:text-right text-[11px] text-slate-400 max-w-md">
            Built strictly for hackathon demonstration with reproducible synthetic data. Not a validated medical device.
          </div>
        </div>
      </footer>

      {/* Custom Patient Modal */}
      <CustomPatientModal
        isOpen={isCustomModalOpen}
        onClose={() => setIsCustomModalOpen(false)}
        onSavePatient={handleSaveCustomPatient}
      />
    </div>
  );
}
