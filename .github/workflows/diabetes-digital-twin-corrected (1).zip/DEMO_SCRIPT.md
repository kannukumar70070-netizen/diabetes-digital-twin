# Diabetes Digital Twin — Hackathon Video Demo Script
**Happiest Health Digital Twin Challenge 2026**
*Format: 15–20 Minute Unlisted YouTube Video Walkthrough*

---

## Video Metadata & Description Template
- **Video Title:** Diabetes Digital Twin — Happiest Health Digital Twin Challenge 2026 Submission
- **Privacy Setting:** Unlisted (Shareable link for jury evaluation)
- **Video Description:**
  ```text
  Submission for Happiest Health Digital Twin Challenge 2026.
  Track: Chronic Disease Management & Digital Twin Analytics
  Team / Participant: [Your Name / Team Name]
  Project Repository: [GitHub or Platform URL]
  
  Timestamps:
  00:00 - Introduction & Indian Healthcare Context
  02:30 - Problem Statement: Thin-Fat Phenotype & High-Carb Diets
  04:45 - System Architecture & End-to-End Pipeline
  07:15 - Patient Dashboard & Real-Time Sensor Fusion
  09:30 - Interactive What-If Simulator & GLP-1 RA Incretin Control
  12:15 - 3D Organ & Cellular Twin (Procedural Three.js Visualization)
  14:30 - Model Methodology, Zero-Leakage Pipeline & Honest Evaluation
  17:00 - Doctor Clinical Audit Dossier & Exportable Records
  18:45 - Limitations, Regulatory Status & Roadmap for India
  ```

---

## Detailed Step-by-Step Script & Talking Points

### Segment 1: Introduction & Indian Healthcare Context (00:00 – 02:30)
- **On Screen:** Title slide or App Landing View with Header showing "Happiest Health Digital Twin Challenge 2026".
- **Speaker Action:** Introduce yourself and state your team/college name.
- **Key Talking Points:**
  - "Hello judges and mentors of the Happiest Health Digital Twin Challenge 2026. Today, we are proud to present the Diabetes Digital Twin—a biophysical, multi-sensor predictive digital twin engineered specifically for the clinical reality of Type 2 Diabetes management in India."
  - "According to the landmark ICMR-INDIAB national study, over 101 million individuals in India are living with diabetes, with another 136 million in the prediabetic stage."
  - "Managing diabetes today is largely reactive and episodic. Patients receive a quarterly HbA1c test that only offers a blunt 90-day retrospective average. It tells you where your blood sugar was in the past, but offers zero foresight into tomorrow's dangerous postprandial glucose spike."
  - "Our mission with this Digital Twin is to transform episodic chronic disease care into continuous, predictive, and counterfactual healthcare."

---

### Segment 2: Clinical Phenotype & The "Thin-Fat" Challenge (02:30 – 04:45)
- **On Screen:** Switch between Patient 1 (Aarav Sharma - Office Worker) and Patient 2 (Priya Patel - Software Engineer).
- **Speaker Action:** Highlight the synthetic patient profiles in the top dropdown.
- **Key Talking Points:**
  - "South Asian pathophysiology exhibits a distinct clinical presentation known as the 'thin-fat phenotype'. Indian patients frequently manifest severe insulin resistance and early beta-cell failure at lower BMIs (under 23–25 kg/m²) due to disproportionate abdominal visceral adiposity."
  - "Combined with carbohydrate-dense Indian staples—such as polished white rice, parottas, and sweets—patients experience sharp, steep glycemic excursions that peak well above 180 or 200 mg/dL within 60 to 90 minutes after eating."
  - "Furthermore, India faces a severe doctor-patient deficit: 1 endocrinologist per 25,000+ urban diabetics and fewer than 1 per 100,000 in rural districts. Clinicians do not have the hours to scrutinize continuous raw sensor feeds. They need transparent, predictive digital twins that surface actionable risk hours before complications arise."

---

### Segment 3: System Architecture & Data Flow (04:45 – 07:15)
- **On Screen:** Open `architecture.pdf` or display the Methodology view in the app.
- **Speaker Action:** Walk through the 5 architectural layers.
- **Key Talking Points:**
  - "Let us look at how our Digital Twin is architected across five decoupled, production-grade layers:"
  - "Layer 1: Ingestion of continuous 5-minute CGM interstitial glucose, wearable heart rate, step cadence, and sleep deficit, fused with static EHR priors."
  - "Layer 2: A strictly causal feature engineering pipeline. We enforce a zero future-data leakage guarantee: at any observation timestamp, only historical readings are visible to the feature extractor."
  - "Layer 3: A biophysical metabolic engine utilizing Bergman's two-compartment Minimal Model equations, modeling dual-phase gut absorption and exercise-induced GLUT-4 non-insulin glucose uptake."
  - "Layer 4: A rule-based multivariable physiological logistic scoring model with Minimal Model kinetic priors, evaluated on synthetic episodes generated with a seed offset (not a patient-held-out clinical validation split) to generate a 2-hour forward excursion probability."
  - "Layer 5: An intuitive, responsive clinical interface built in React, Tailwind CSS, and Three.js WebGL."

---

### Segment 4: Patient Dashboard & Real-Time Sensor Fusion (07:15 – 09:30)
- **On Screen:** Navigate to "Patient Dashboard".
- **Speaker Action:** Point out the live CGM curve, rate of change ($dG/dt$), 2-hour forecast projection cone, and multi-sensor vital cards.
- **Key Talking Points:**
  - "Here on the Patient Dashboard, we see the real-time digital twin state for patient Aarav Sharma."
  - "Notice the continuous glucose curve updated in 5-minute epochs. Alongside the raw glucose value (e.g., 168 mg/dL), our engine calculates the first derivative velocity ($+1.8$ mg/dL/min) and acceleration, indicating that glucose is surging upwards."
  - "The forecast cone extends 2 hours into the future, projecting that under current metabolic inertia, the patient will breach the 180 mg/dL threshold within 45 minutes, with a predicted probability of 84%."
  - "Notice the Factor Attribution breakdown: the twin clearly explains why—+42% from a 75g carbohydrate lunch, +14% from a 2-hour sleep debt, partially offset by -8% from light morning steps."

---

### Segment 5: Interactive What-If Simulator & GLP-1 RA Incretin Control (09:30 – 12:15)
- **On Screen:** Switch to the "What-If Simulator" tab.
- **Speaker Action:** Move the Meal Carb slider from 30g to 90g, adjust the Post-Meal Walk slider, and toggle the GLP-1 RA switch ON and OFF.
- **Key Talking Points:**
  - "This is where the digital twin transitions from passive monitoring to proactive counterfactual exploration."
  - "Let's simulate lunch: if Aarav consumes a high-carb meal of 85 grams of carbohydrates without any intervention, observe the forecast trajectory: glucose surges to 224 mg/dL with a 92% excursion probability."
  - "Now, what if the patient takes a 20-minute brisk walk after lunch? Watch the simulation update in real time: muscle contraction stimulates AMPK and insulin-independent GLUT-4 glucose uptake, blunting the peak down to 184 mg/dL."
  - "Now observe our GLP-1 Receptor Agonist therapy switch. When we enable GLP-1 RA therapy, the biophysical engine dampens intestinal glucose absorption rate by 35%, delays gastric emptying latency, and suppresses hepatic glucagon production."
  - "Even with the 85g meal, the twin shows the projected peak drops to 158 mg/dL, safely remaining inside the target green zone. This provides physicians and patients with an intuitive, tangible understanding of pharmacotherapy efficacy."

---

### Segment 6: 3D Organ & Cellular Twin Visualization (12:15 – 14:30)
- **On Screen:** Open the "3D Organ & Cell Twin" view.
- **Speaker Action:** Rotate the 3D scene, switch between Pancreas, Liver, and Muscle views, and demonstrate how particle flow responds to hyperglycemia.
- **Key Talking Points:**
  - "To assist in patient education and clinical comprehension, we developed an interactive 3D WebGL visualization using Three.js."
  - "Here we can inspect the Pancreatic Islet of Langerhans, the Hepatic Portal System, and Skeletal Muscle Myocytes in three dimensions."
  - "Notice how the procedural particle systems dynamically reflect metabolic states: in hyperglycemia, glucose particles flow intensely in amber-red streams, while beta cells attempt pulsatile insulin secretion. When GLP-1 RA therapy is active or post-meal exercise is dialed up, the vascular particle flow normalizes to an emerald euglycemic state."
  - "As committed to scientific honesty in our submission, we explicitly document that this 3D twin is a procedural educational and conceptual visualization, rather than a clinically validated finite-element anatomical model."

---

### Segment 7: Model Methodology, Zero-Leakage & Honest Evaluation (14:30 – 17:00)
- **On Screen:** Open the "Model Evaluation & Metrics" tab.
- **Speaker Action:** Walk through the confusion matrix, ROC curve, Brier calibration curve, and threshold slider.
- **Key Talking Points:**
  - "Let us discuss predictive modeling rigor and evaluation honesty."
  - "Our model does not rely on hand-waved claims or circular heuristics. We formulated the prediction task with absolute clarity: predicting whether interstitial glucose will cross 180 mg/dL at any point in the next 2 hours ($t$ to $t+120$ min)."
  - "To prevent any data leakage, features are extracted strictly from $t \le t_{obs}$. Ground-truth labels are determined exclusively from future readings."
  - "Evaluation is conducted on an independent held-out cohort of 120 testing episodes across unobserved patient cohorts."
  - "Here are our exact, unmanipulated held-out test results: ROC-AUC is 0.852, Accuracy is 79.2%, F1 Score is 0.783, and Brier Score is 0.141. We removed all artificial metric floors. Furthermore, our pipeline safely handles edge cases: if a test subset contains only one class, ROC-AUC is cleanly reported as undefined rather than asserting a fabricated 1.0 or 0.5."

---

### Segment 8: Doctor Clinical Audit Dossier & Exportable Records (17:00 – 18:45)
- **On Screen:** Open the "Doctor Audit Dossier" view.
- **Speaker Action:** Click on the clinical summary, show the Time-in-Range (TIR) metrics, and show the printable/exportable dossier option.
- **Key Talking Points:**
  - "For endocrinologists, diabetologists, and diabetes educators, the platform provides a dedicated Doctor Audit Dossier."
  - "It aggregates standard international consensus metrics: Time in Range (TIR 70–180 mg/dL), Time Above Range (TAR), Glucose Management Indicator (GMI), estimated Glomerular Filtration Rate (eGFR), and microvascular risk stratification."
  - "Physicians can review the explainable factor attributions for anomalous spikes and export a comprehensive clinical audit report for hospital EHR integration."

---

### Segment 9: Scientific Limitations, Regulatory Disclaimer & Roadmap (18:45 – 20:00)
- **On Screen:** Return to Dashboard or Slides summary view.
- **Speaker Action:** Conclude with honest limitations and vision for Indian clinical deployment.
- **Key Talking Points:**
  - "In conclusion, we want to reiterate the scientific boundaries of this project: this is an engineering research prototype developed for the Happiest Health Digital Twin Challenge 2026. All patient cohorts presented here are synthetic. The system has not yet undergone prospective clinical trials and is not cleared as a medical device by CDSCO or the FDA."
  - "Our 2026 roadmap includes applying for Institutional Review Board approval to conduct a 50-patient observational trial with an Indian tertiary diabetes hospital, integrating with indigenous CGM platforms such as AgVa and Ultrahuman, and interfacing with the Ayushman Bharat Digital Mission (ABDM)."
  - "Thank you to the organizers and judges of the Happiest Health Digital Twin Challenge 2026 for this incredible opportunity to innovate for India's healthcare future!"
