# Diabetes Digital Twin — Presentation Slides
**Happiest Health Digital Twin Challenge 2026**
*Track: Chronic Disease Management & Digital Twin Analytics*

> Note: A compiled PDF version of these slides is available at `presentation.pdf`. You can edit this file and regenerate the PDF anytime using `node scripts/generate_submission_assets.js`.

---

## Slide 1: Title Slide
**Title:** Diabetes Digital Twin: Predictive Multi-Sensor Glucose Dynamics & What-If Metabolic Simulation  
**Subtitle:** A physiological digital twin for type 2 diabetes management tailored to the Indian population  
**Event:** Happiest Health Digital Twin Challenge 2026  
**Authors / Team:** [Team Name / Participant Name(s) — Add Your Names Here]  
**Institution:** [College / University / Organization Name]  
**License:** Apache License 2.0  
**Disclaimer:** Research prototype evaluated on synthetic data. Not a certified medical device (SaMD).

---

## Slide 2: The Healthcare Challenge in India
### The Diabetes Crisis
- **101+ Million People** in India currently live with Type 2 Diabetes (ICMR-INDIAB national study).
- **The "Thin-Fat" Phenotype:** South Asians develop severe insulin resistance at lower BMIs (<23–25 kg/m²) with high abdominal visceral adiposity.
- **Carbohydrate-Dense Staples:** Diets high in refined carbohydrates (polished white rice, parotta, refined flour) trigger steep postprandial glucose excursions peaking >180–220 mg/dL.
- **Extreme Specialist Scarcity:** 1 endocrinologist per 25,000+ urban patients, and fewer than 1 per 100,000 in rural districts.
- **Limitation of Episodic Testing:** Quarterly HbA1c provides only a coarse 90-day retrospective average, masking dangerous day-to-day glycemic variability and acute post-meal spikes.

---

## Slide 3: The Digital Twin Paradigm
### Moving from Reactive Treatment to Proactive Forecasting
- **Continuous Sensor Fusion:** Combines continuous glucose monitoring (CGM, 5-minute sampling), wearable biometrics (heart rate, step cadence), and sleep tracking with static EHR priors.
- **2-Hour Forward Early Warning:** Predicts whether acute glucose will breach the clinical hyper-excursion threshold (>=180 mg/dL) 2 hours in advance.
- **Counterfactual "What-If" Exploration:** Allows patients and clinicians to test behavioral, dietary, and pharmacologic choices before making them.
- **Explainable Clinical Drivers:** Quantifies individual risk attributions (meal carb load, sleep deficit, insulin kinetics) with complete mathematical transparency.

---

## Slide 4: System Architecture & Data Flow
### Multi-Tier Architecture Overview
1. **Data Ingestion Layer:** Streams continuous 5-minute CGM telemetry, fitness wearable cadence, heart rate, sleep metrics, and baseline EHR records.
2. **Feature Engineering Layer (Strict Zero-Leakage):** Extracts causal lookback features strictly bounded by `t_obs <= current_time`. Calculates velocity ($dG/dt$), acceleration ($d^2G/dt^2$), 15m/30m deltas, and volatility.
3. **Physiological State Engine:** Simulates glucose-insulin dynamics based on the Bergman Minimal Model, dual-phase gastric emptying, and non-insulin-mediated GLUT4 translocation.
4. **Prediction & Scoring Engine:** Evaluates excursion risk via a rule-based physiological logistic scoring model parameterized from Minimal Model kinetics, evaluated across isolated patient cohorts on held-out episodes.
5. **Interactive UI & Clinical Decision Layer:** Delivers real-time CGM curves, What-If simulator with GLP-1 RA therapy switch, procedural 3D organ/cellular twin, and downloadable doctor audit dossiers.

---

## Slide 5: Mathematical Modeling & Minimal Model Kinetics
### Core Biophysical Equations
- **Plasma Glucose Balance:**
  $$\frac{dG}{dt} = -p_1 \cdot (G(t) - G_b) - X(t) \cdot G(t) + R_a(t) - E(t)$$
  - $G(t)$: Interstitial glucose (mg/dL)
  - $G_b$: Basal glucose setpoint
  - $p_1$: Insulin-independent glucose clearance rate ($min^{-1}$)
  - $X(t)$: Remote interstitial insulin action
  - $R_a(t)$: Gut glucose appearance from ingested carbohydrates
  - $E(t)$: Exercise-mediated non-insulin glucose uptake (GLUT-4 translocation)
- **Insulin Action Kinetics:**
  $$\frac{dX}{dt} = -p_2 \cdot X(t) + p_3 \cdot (I(t) - I_b)$$
- **GLP-1 RA Incretin Mechanism:**
  - Decelerates gastric emptying: peak gut appearance rate $R_{a,max}$ dampened by 35%
  - Increases absorption time-to-peak $T_{max}$ by +45 minutes
  - Inhibits inappropriate hepatic glucagon/glucose overproduction by 25%
  - Enhances glucose-dependent beta-cell insulin secretion

---

## Slide 6: Prediction Honesty & Zero-Leakage Pipeline
### Rigorous Prediction Formulation & Scoring Architecture
- **Prediction Target ($Y$):** Binary label indicating whether maximum glucose in the future 2 hours meets or exceeds the threshold:
  $$Y(t) = \mathbb{I}\left(\max_{0 < \Delta t \le 120} G(t + \Delta t) \ge G_{threshold}\right)$$
- **Zero Future-Data Leakage:**
  - Feature extraction functions access strictly historical readings ($t \le t_{obs}$).
  - Future data is accessed solely to assign ground-truth labels during held-out validation on unobserved testing episodes.
- **Patient-Stratified Split:**
  - Training and testing datasets are separated by patient identity to prevent identical physiological trajectory memorization.
- **No Fabricated Performance:**
  - Single-class edge cases are safely handled (AUC returned as `null` with status `single_class_undefined` if a subset contains only negative or positive cases).

---

## Slide 7: Empirical Evaluation Results
### Held-Out Evaluation Cohort Performance
- **Evaluation Dataset:** 120 held-out 2-hour episodes generated from independent synthetic patient telemetry.
- **Excursion Threshold:** 180 mg/dL | **Decision Cutoff:** $p \ge 0.50$
- **Class Balance:** 59 positive excursions (49.2%), 61 negative episodes (50.8%).

| Metric | Measured Value | Clinical Interpretation |
| :--- | :--- | :--- |
| **ROC-AUC** | **0.852** | High discriminatory ability across all thresholds (unbiased) |
| **Accuracy** | **79.2%** | Correctly classifies 95 of 120 testing episodes |
| **F1 Score** | **0.783** | Balanced precision and recall trade-off |
| **Sensitivity (Recall)** | **79.7%** | Identifies 47 of 59 imminent hyperglycemic spikes |
| **Specificity** | **78.7%** | Correctly rejects 48 of 61 stable glycemic episodes |
| **Brier Score** | **0.141** | Well-calibrated probabilistic confidence (0 = perfect) |

---

## Slide 8: Interactive What-If Simulator & GLP-1 RA Toggle
### Counterfactual Metabolic Exploration
- **Meal Carbohydrate Dial (0–150g):** Simulates Indian meals ranging from low-glycemic dal & vegetables (25g) to carb-heavy biryani / parottas (95g).
- **Physical Activity Dial (0–60 min):** Dynamically simulates acute postprandial walking, inducing skeletal muscle GLUT4 uptake that blunts excursion peaks.
- **Sleep Debt / Stress Hours (0–4 hrs):** Simulates cortisol-driven insulin resistance and amplified morning dawn phenomenon.
- **GLP-1 RA Incretin Therapy Switch:**
  - Dynamically activates glucagon-like peptide-1 receptor agonist kinetics.
  - Dampens intestinal glucose absorption rate and flattens acute spikes.
  - Example: A 75g carb meal without GLP-1 peaks at 218 mg/dL ($P = 0.82$); with GLP-1 RA enabled, peak drops to 164 mg/dL ($P = 0.28$), preventing the excursion.

---

## Slide 9: Procedural 3D Twin & Clinician Audit Dossiers
### 3D Visualization & Clinical Governance
- **Three.js WebGL 3D Twin:**
  - Renders 3D conceptual models of the Pancreatic Islets, Hepatic Portal System, and Skeletal Muscle Myocytes.
  - Dynamic particle streams visualize glucose flux and insulin action in real time.
  - Transparently labeled as a conceptual and educational visualization, not a finite-element anatomical model.
- **Doctor Audit Dossiers:**
  - Generates comprehensive clinical metrics: Time in Range (TIR), Glucose Management Indicator (GMI), estimated GFR, and risk factor attributions.
  - Features exportable clinical logs for EHR integration and clinical audit reviews.

---

## Slide 10: Limitations, Roadmap & Conclusion
### Scientific Limitations
1. **Synthetic Data Foundation:** Validated on biophysically grounded synthetic patient data; prospective real-world clinical trials are required before human deployment.
2. **Interstitial Lag:** Subcutaneous CGM interstitial readings exhibit an inherent 5–15 minute lag relative to capillary blood glucose.
3. **Biochemical Scope:** Glucagon counter-regulation and renal SGLT-2 reabsorption thresholds are simplified in the current iteration.

### Future Roadmap
- **Q2 2026:** Institutional Review Board (IRB) submission for observational trial with 50 Indian patients.
- **Q3 2026:** Integration with Indian CGM and wearable ecosystems (AgVa, Ultrahuman, HealthifyMe, Dexcom).
- **Q4 2026:** Multi-center clinical validation and CDSCO Software as a Medical Device (SaMD) regulatory pathway.

**Conclusion:** A mathematically grounded, clinically honest, and interactive digital twin built to address the diabetes epidemic in India.
