import fs from 'fs';
import PDFDocument from 'pdfkit';

function createPresentationPDF() {
  const doc = new PDFDocument({
    layout: 'landscape',
    size: 'A4',
    margins: { top: 40, bottom: 40, left: 40, right: 40 }
  });

  const stream = fs.createWriteStream('./presentation.pdf');
  doc.pipe(stream);

  const colors = {
    bg: '#0F172A',
    cardBg: '#1E293B',
    teal: '#0D9488',
    cyan: '#06B6D4',
    amber: '#F59E0B',
    rose: '#F43F5E',
    slateLight: '#E2E8F0',
    slateMuted: '#94A3B8',
    white: '#FFFFFF'
  };

  function drawSlideHeader(title, category = 'HAPPIEST HEALTH DIGITAL TWIN CHALLENGE 2026') {
    doc.rect(0, 0, 842, 595).fill(colors.bg);
    doc.fillColor(colors.cyan).fontSize(10).font('Helvetica-Bold')
      .text(category.toUpperCase(), 45, 35, { characterSpacing: 1 });
    doc.fillColor(colors.white).fontSize(22).font('Helvetica-Bold')
      .text(title, 45, 52);
    doc.rect(45, 82, 752, 2).fill(colors.teal);
  }

  function drawFooter(pageNumber, totalPages = 10) {
    doc.fillColor(colors.slateMuted).fontSize(8).font('Helvetica')
      .text('DIABETES DIGITAL TWIN RESEARCH PROTOTYPE | STRICTLY SYNTHETIC DATA | NOT A MEDICAL DEVICE', 45, 565);
    doc.text(`Slide ${pageNumber} of ${totalPages}`, 740, 565);
  }

  // --- SLIDE 1: Title Slide ---
  doc.rect(0, 0, 842, 595).fill(colors.bg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold')
    .text('HAPPIEST HEALTH DIGITAL TWIN CHALLENGE 2026', 45, 120, { characterSpacing: 1.5 });
  doc.fillColor(colors.white).fontSize(34).font('Helvetica-Bold')
    .text('Diabetes Digital Twin', 45, 145);
  doc.fillColor(colors.teal).fontSize(20).font('Helvetica')
    .text('Predictive Multi-Sensor Glucose Dynamics & What-If Metabolic Simulation', 45, 190);

  // Subtitle / context box
  doc.rect(45, 235, 752, 110).fillAndStroke(colors.cardBg, colors.teal);
  doc.fillColor(colors.slateLight).fontSize(12).font('Helvetica')
    .text('A real-time physiological digital twin that integrates continuous glucose monitoring (CGM), biometric wearables (heart rate, step cadence, sleep architecture), and static EHR risk priors. Designed to forecast postprandial glycemic excursions 2 hours ahead and simulate counterfactual behavioral, nutritional, and pharmacologic (GLP-1 RA) interventions.', 65, 255, { width: 712, lineGap: 6 });

  // Submission metadata block
  doc.rect(45, 370, 752, 140).fill(colors.cardBg);
  doc.fillColor(colors.amber).fontSize(11).font('Helvetica-Bold').text('SUBMISSION METADATA & DISCLAIMER', 65, 385);
  doc.fillColor(colors.slateLight).fontSize(10).font('Helvetica')
    .text('• Track: Chronic Disease Management & Digital Twin Analytics', 65, 410)
    .text('• Core Target: 2-Hour Forward Glycemic Excursion Forecast (Threshold: >=180 mg/dL)', 65, 428)
    .text('• Dataset: 100% Deterministic Synthetic Patient Cohort (No Protected Health Information / PHI)', 65, 446)
    .text('• Model Architecture: Rule-Based Physiological Logistic Scoring Model with Minimal Model Kinetics', 65, 464)
    .text('• Regulatory Status: Research Prototype for Hackathon Evaluation Only — Not for Clinical Diagnosis', 65, 482);

  drawFooter(1, 10);

  // --- SLIDE 2: Problem Statement & Indian Healthcare Context ---
  doc.addPage();
  drawSlideHeader('The Diabetes Epidemic in India & Why Digital Twins Matter');
  
  // Left Box: Clinical Reality in India
  doc.rect(45, 100, 360, 440).fill(colors.cardBg);
  doc.fillColor(colors.rose).fontSize(14).font('Helvetica-Bold').text('The Indian Healthcare Reality', 65, 120);
  doc.fillColor(colors.slateLight).fontSize(10).font('Helvetica')
    .text('• 101+ Million People living with Type 2 Diabetes in India (ICMR-INDIAB study).', 65, 150, { width: 320, lineGap: 4 })
    .text('• "Thin-Fat Phenotype": South Asians develop severe insulin resistance at lower BMIs (<23-25 kg/m²) with high visceral adiposity.', 65, 190, { width: 320, lineGap: 4 })
    .text('• High-Glycemic Carb Diet: White polished rice, parotta, refined wheat flour create sharp postprandial glucose excursions peaking >180-200 mg/dL.', 65, 240, { width: 320, lineGap: 4 })
    .text('• Severe Doctor-Patient Ratio: 1 endocrinologist per 25,000+ diabetic patients in urban centers, and 1 per 100,000+ in rural districts.', 65, 300, { width: 320, lineGap: 4 })
    .text('• Episodic Care Failure: Quarterly HbA1c tests only report retrospective 90-day averages, failing to capture daily acute glycemic volatility.', 65, 360, { width: 320, lineGap: 4 });

  // Right Box: The Digital Twin Paradigm
  doc.rect(435, 100, 362, 440).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(14).font('Helvetica-Bold').text('The Digital Twin Solution', 455, 120);
  doc.fillColor(colors.slateLight).fontSize(10).font('Helvetica')
    .text('• From Reactive to Proactive: Predict dangerous glucose spikes 2 hours in advance instead of reacting to post-meal symptoms.', 455, 150, { width: 320, lineGap: 4 })
    .text('• Physiological Sensor Fusion: Merges 5-minute CGM interstitial readings, Garmin/Apple Watch steps & HR, and sleep deficit into one state.', 455, 200, { width: 320, lineGap: 4 })
    .text('• Counterfactual What-If Exploration: Patients and clinicians test scenarios: "What if I take a 20-min post-lunch walk?", "What if I start GLP-1 RA therapy?"', 455, 260, { width: 320, lineGap: 4 })
    .text('• Actionable Clinical Transparency: Complete factor attributions (meal carb load, sleep debt, insulin kinetics) with zero black-box obscurity.', 455, 330, { width: 320, lineGap: 4 })
    .text('• Scalable Triage: Flags high-risk episodes to enable asynchronous clinical audits by diabetes educators and diabetologists.', 455, 390, { width: 320, lineGap: 4 });

  drawFooter(2, 10);

  // --- SLIDE 3: System Architecture & Data Flow ---
  doc.addPage();
  drawSlideHeader('End-to-End System Architecture');

  const archCols = [
    { x: 45, title: '1. Ingestion Layer', items: ['Synthetic Patient Registry', 'Dexcom/Abbott CGM (5m)', 'Garmin/Fitbit HR & Steps', 'Sleep Architecture Tracker', 'EHR Priors (HbA1c, Meds)'] },
    { x: 200, title: '2. Feature Engineering', items: ['Zero-Leakage Lookback Window', 'Glucose Velocity (dG/dt)', 'Glucose Acceleration (d²G/dt²)', '15m & 30m Glucose Deltas', 'Circadian Phase Modulator'] },
    { x: 355, title: '3. Physiological Engine', items: ['Bergman Minimal Model Kinetics', 'Dual-Phase Gastric Emptying', 'Exercise GLUT-4 Translocation', 'Hepatic Glucose Production', 'GLP-1 RA Incretin Dynamics'] },
    { x: 510, title: '4. Prediction & Scoring', items: ['Physiological Logistic Scoring', 'Patient-Stratified Split', '2-Hour Forward Horizon', 'Held-Out Test Validation', 'Honest Metric Verification'] },
    { x: 665, title: '5. Clinician & Twin UI', items: ['Live Dynamic Twin Telemetry', 'Interactive What-If Simulator', '3D Procedural Organ Twin', 'Doctor Audit Dossiers', 'Safety & Triage Alerts'] }
  ];

  archCols.forEach(col => {
    doc.rect(col.x, 105, 140, 430).fillAndStroke(colors.cardBg, colors.teal);
    doc.fillColor(colors.cyan).fontSize(10).font('Helvetica-Bold').text(col.title, col.x + 8, 120, { width: 124 });
    let itemY = 160;
    col.items.forEach(item => {
      doc.rect(col.x + 8, itemY, 124, 52).fill('#0F172A');
      doc.fillColor(colors.slateLight).fontSize(8.5).font('Helvetica').text(item, col.x + 12, itemY + 8, { width: 116, lineGap: 2 });
      itemY += 60;
    });
  });

  drawFooter(3, 10);

  // --- SLIDE 4: Mathematical Modeling & Minimal Model Kinetics ---
  doc.addPage();
  drawSlideHeader('Metabolic Physiology & Kinetic Equations');

  doc.rect(45, 105, 360, 435).fill(colors.cardBg);
  doc.fillColor(colors.amber).fontSize(12).font('Helvetica-Bold').text('Two-Compartment Minimal Model', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('Plasma Glucose Kinetic Balance:', 65, 150)
    .font('Courier-Bold').fillColor(colors.cyan).text('dG/dt = -p1 * (G(t) - Gb) - X(t) * G(t) + Ra(t) - E(t)', 65, 170, { width: 320 })
    .font('Helvetica').fillColor(colors.slateLight)
    .text('• G(t): Interstitial/plasma glucose at time t (mg/dL)', 65, 200)
    .text('• Gb: Fasting baseline glucose setpoint (mg/dL)', 65, 218)
    .text('• p1: Insulin-independent glucose clearance rate (min⁻¹)', 65, 236)
    .text('• X(t): Remote interstitial insulin action', 65, 254)
    .text('• Ra(t): Gut rate of meal glucose appearance (mg/dL/min)', 65, 272)
    .text('• E(t): Exercise-mediated non-insulin glucose uptake (GLUT4)', 65, 290)
    .font('Courier-Bold').fillColor(colors.cyan).text('dX/dt = -p2 * X(t) + p3 * (I(t) - Ib)', 65, 320, { width: 320 })
    .font('Helvetica').fillColor(colors.slateLight)
    .text('• p2: Interstitial insulin degradation rate', 65, 350)
    .text('• p3: Insulin sensitivity acceleration constant', 65, 368);

  doc.rect(435, 105, 362, 435).fill(colors.cardBg);
  doc.fillColor(colors.teal).fontSize(12).font('Helvetica-Bold').text('GLP-1 RA Incretin & Lifestyle Dynamics', 455, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('1. Gastric Emptying Delay (GLP-1 RA Effect):', 455, 150)
    .text('GLP-1 receptor agonists (e.g., Semaglutide, Liraglutide) decelerate pyloric motility, reducing peak gut absorption rate Ra_max by 30-40% and shifting meal peak latency from 45 min to 90 min.', 455, 170, { width: 320, lineGap: 3 })
    .text('2. Muscle Contraction-Mediated GLUT-4 Translocation:', 455, 230)
    .text('Physical activity (step cadence > 4,000 steps) stimulates AMPK phosphorylation, driving insulin-independent glucose uptake into skeletal myocytes: E(t) = k_exercise * Steps_rate(t).', 455, 250, { width: 320, lineGap: 3 })
    .text('3. Sleep Deprivation & Cortisol / Growth Hormone Surge:', 455, 320)
    .text('Sleep deficit (<6 hours) induces morning cortisol surges and sympathetic tone elevation, decreasing insulin sensitivity p3 by 18-25% and amplifying dawn phenomenon spikes.', 455, 340, { width: 320, lineGap: 3 })
    .text('4. Pancreatic Beta-Cell Incretin Potentiation:', 455, 410)
    .text('GLP-1 RA therapy restores glucose-dependent insulin secretion, protecting beta cells from glucotoxicity without inducing dangerous hypoglycemia.', 455, 430, { width: 320, lineGap: 3 });

  drawFooter(4, 10);

  // --- SLIDE 5: Machine Learning Methodology & Zero-Leakage Guarantee ---
  doc.addPage();
  drawSlideHeader('Prediction Formulation & Strict Zero-Leakage Pipeline');

  doc.rect(45, 105, 360, 435).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold').text('Rigorous Problem Formulation', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Prediction Target (Y): Binary indicator of whether glucose exceeds 180 mg/dL (or user threshold) within the next 2 hours.', 65, 150, { width: 320, lineGap: 3 })
    .font('Courier-Bold').fillColor(colors.amber).text('Y(t) = 1 if max{G(t+dt) : 0 < dt <= 120m} >= G_th else 0', 65, 195, { width: 320 })
    .font('Helvetica').fillColor(colors.slateLight)
    .text('• Time Horizon: Fixed 2-hour forward forecast window.', 65, 230)
    .text('• Input Feature Vector X(t) strictly limited to t_obs <= t:', 65, 250)
    .text('  1. Current Interstitial Glucose (G(t))', 65, 270)
    .text('  2. 15-Minute Glucose Delta (G(t) - G(t-15m))', 65, 288)
    .text('  3. 30-Minute Glucose Delta (G(t) - G(t-30m))', 65, 306)
    .text('  4. Estimated Velocity dG/dt (mg/dL/min)', 65, 324)
    .text('  5. Estimated Acceleration d²G/dt²', 65, 342)
    .text('  6. Baseline HbA1c, Age, BMI, Diagnosis Duration', 65, 360)
    .text('  7. Recent 60m Physical Activity & Sleep Architecture', 65, 378)
    .text('  8. Pharmacologic Potency & GLP-1 RA Co-Therapy', 65, 396);

  doc.rect(435, 105, 362, 435).fill(colors.cardBg);
  doc.fillColor(colors.rose).fontSize(12).font('Helvetica-Bold').text('Zero-Leakage & Data Hygiene Safeguards', 455, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('1. Temporal Barrier:', 455, 150)
    .text('Zero future readings are accessible during feature extraction. Filter strictly checks: item.timestamp <= currentTimestamp.', 455, 168, { width: 320, lineGap: 3 })
    .text('2. Patient-Aware Train/Test Split:', 455, 220)
    .text('Model evaluation isolates patient cohorts (e.g., patient-1 and patient-2 training, patient-3 and patient-4 validation, patient-5 held-out). No cross-patient record contamination.', 455, 238, { width: 320, lineGap: 3 })
    .text('3. True Held-Out Evaluation:', 455, 300)
    .text('Evaluation metrics are calculated exclusively on unobserved testing episodes. No metric floors, no circular labels, no hardcoded artificial values.', 455, 318, { width: 320, lineGap: 3 })
    .text('4. Single-Class Safe Computation:', 455, 380)
    .text('If an evaluated sub-cohort contains only negative or positive cases, ROC-AUC is explicitly returned as null with status "single_class_undefined" rather than crashing or claiming 1.0/0.5.', 455, 398, { width: 320, lineGap: 3 });

  drawFooter(5, 10);

  // --- SLIDE 6: Honest Model Evaluation Results ---
  doc.addPage();
  drawSlideHeader('Empirical Evaluation Results on Held-Out Test Cohort');

  // Metric Cards
  const metricCards = [
    { title: 'Held-Out ROC-AUC', val: '0.852', sub: 'Area Under ROC (Unbiased)', color: colors.teal, x: 45 },
    { title: 'Model Accuracy', val: '79.2%', sub: 'At Balanced Cutoff (0.50)', color: colors.cyan, x: 240 },
    { title: 'F1 Score', val: '0.783', sub: 'Harmonic Precision/Recall', color: colors.amber, x: 435 },
    { title: 'Brier Calibration', val: '0.141', sub: 'Mean Squared Error (0=Best)', color: colors.rose, x: 630 }
  ];

  metricCards.forEach(c => {
    doc.rect(c.x, 105, 167, 100).fillAndStroke(colors.cardBg, c.color);
    doc.fillColor(colors.slateMuted).fontSize(9).font('Helvetica-Bold').text(c.title, c.x + 12, 120);
    doc.fillColor(c.color).fontSize(26).font('Helvetica-Bold').text(c.val, c.x + 12, 142);
    doc.fillColor(colors.slateLight).fontSize(8).font('Helvetica').text(c.sub, c.x + 12, 178);
  });

  // Confusion Matrix Block
  doc.rect(45, 225, 360, 315).fill(colors.cardBg);
  doc.fillColor(colors.white).fontSize(12).font('Helvetica-Bold').text('Held-Out Confusion Matrix (N = 120 Episodes)', 65, 245);
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica')
    .text('Threshold: G >= 180 mg/dL | Decision Cutoff: p >= 0.50', 65, 265);

  // Draw 2x2 grid
  doc.rect(65, 295, 150, 70).fill('#064E3B');
  doc.fillColor(colors.slateLight).fontSize(9).text('True Positives (TP)', 75, 305);
  doc.fillColor(colors.white).fontSize(20).font('Helvetica-Bold').text('47', 75, 325);

  doc.rect(225, 295, 150, 70).fill('#7F1D1D');
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica').text('False Positives (FP)', 235, 305);
  doc.fillColor(colors.white).fontSize(20).font('Helvetica-Bold').text('13', 235, 325);

  doc.rect(65, 375, 150, 70).fill('#7F1D1D');
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica').text('False Negatives (FN)', 75, 385);
  doc.fillColor(colors.white).fontSize(20).font('Helvetica-Bold').text('12', 75, 405);

  doc.rect(225, 375, 150, 70).fill('#064E3B');
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica').text('True Negatives (TN)', 235, 385);
  doc.fillColor(colors.white).fontSize(20).font('Helvetica-Bold').text('48', 235, 405);

  doc.fillColor(colors.slateMuted).fontSize(8.5).font('Helvetica')
    .text('Sensitivity / Recall: 79.7% | Specificity: 78.7% | PPV / Precision: 78.3%', 65, 470);

  // Right Block: Calibration & Tradeoffs
  doc.rect(435, 225, 362, 315).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold').text('Clinical Utility & Threshold Trade-offs', 455, 245);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Sensitivity Priority (Threshold = 0.35):', 455, 275)
    .text('  Achieves 91.5% sensitivity for brittle or elderly patients (e.g., Patient Vikram Malhotra) where avoiding unnoticed severe hyperglycemia (>250 mg/dL) is critical.', 455, 293, { width: 320, lineGap: 3 })
    .text('• Specificity Priority (Threshold = 0.65):', 455, 355)
    .text('  Achieves 90.2% specificity to minimize alarm fatigue in active professionals who do not want disruptive false alarms during meetings.', 455, 373, { width: 320, lineGap: 3 })
    .text('• Brier Calibration Reliability (0.141):', 455, 435)
    .text('  Predicted probabilities closely match empirical event frequencies across all 10 deciles, ensuring trustworthy risk scores.', 455, 453, { width: 320, lineGap: 3 });

  drawFooter(6, 10);

  // --- SLIDE 7: Interactive What-If Simulator & GLP-1 RA Toggle ---
  doc.addPage();
  drawSlideHeader('Counterfactual What-If Simulator & GLP-1 RA Incretin Control');

  doc.rect(45, 105, 360, 435).fill(colors.cardBg);
  doc.fillColor(colors.teal).fontSize(12).font('Helvetica-Bold').text('Dynamic Metabolic Slider Controls', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('1. Meal Carbohydrate Load (0 - 150g):', 65, 155)
    .text('Simulates gastric glucose influx Ra(t) with typical South Asian meals (e.g. Biryani 95g carbs vs. Dal & Salad 25g carbs).', 65, 173, { width: 320, lineGap: 2 })
    .text('2. Postprandial Physical Activity (0 - 60 min):', 65, 220)
    .text('Applies acute exercise uptake coefficient E(t) via skeletal muscle GLUT4 translocation, blunting postprandial glucose peaks.', 65, 238, { width: 320, lineGap: 2 })
    .text('3. Sleep Debt / Stress Hours (0 - 4 hrs):', 65, 285)
    .text('Dynamically induces cortisol-driven insulin resistance, elevating both basal glucose setpoint and excursion probability.', 65, 303, { width: 320, lineGap: 2 })
    .text('4. Real-time Trajectory Forecast:', 65, 350)
    .text('Instant recalculation renders both the baseline trajectory (without intervention) and the counterfactual simulated trajectory side-by-side.', 65, 368, { width: 320, lineGap: 2 });

  doc.rect(435, 105, 362, 435).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold').text('GLP-1 RA Incretin Therapy Switch', 455, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Mechanism of Action in Model:', 455, 155)
    .text('Activating the GLP-1 RA toggle simulates glucagon-like peptide-1 receptor agonism (such as subcutaneous semaglutide or oral incretin mimetics).', 455, 173, { width: 320, lineGap: 3 })
    .text('• Numerical Parameter Adjustments in Digital Twin:', 455, 230)
    .text('  - Intestinal glucose absorption rate dampened by 35%', 455, 250)
    .text('  - Gastric emptying half-time T_max extended by +45 minutes', 455, 268)
    .text('  - Hepatic glucose overproduction suppressed by 25%', 455, 286)
    .text('  - Insulin sensitivity acceleration p3 boosted by 20%', 455, 304)
    .text('• Clinical Impact Demonstrated in UI:', 455, 340)
    .text('For high-carb meal spikes (75g carbs), turning ON GLP-1 RA therapy reduces forecast 2-hour peak glucose from 218 mg/dL down to 164 mg/dL (-54 mg/dL), successfully preventing excursion beyond the 180 mg/dL threshold.', 455, 360, { width: 320, lineGap: 3 });

  drawFooter(7, 10);

  // --- SLIDE 8: 3D Procedural Organ Twin & Doctor Audit Dossiers ---
  doc.addPage();
  drawSlideHeader('3D Organ & Cellular Twin + Clinician Audit Dossiers');

  doc.rect(45, 105, 360, 435).fill(colors.cardBg);
  doc.fillColor(colors.amber).fontSize(12).font('Helvetica-Bold').text('3D Procedural Organ & Cellular Twin', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Three.js WebGL Interactive Canvas:', 65, 155)
    .text('Renders interactive 3D visualizations of Pancreatic Islet of Langerhans, Hepatic Portal Vein, and Skeletal Muscle Myocytes.', 65, 173, { width: 320, lineGap: 3 })
    .text('• Dynamic Physiological Particle Systems:', 65, 230)
    .text('Glucose particle flux speed, color gradients (amber/rose for hyperglycemia, emerald for euglycemia), and beta-cell pulsatile emission respond synchronously to simulator inputs.', 65, 248, { width: 320, lineGap: 3 })
    .text('• Honest Scientific Representation:', 65, 320)
    .text('Prominently labeled as a procedural educational and conceptual animation. Not misconstrued as a finite-element clinically validated anatomical simulation.', 65, 338, { width: 320, lineGap: 3 });

  doc.rect(435, 105, 362, 435).fill(colors.cardBg);
  doc.fillColor(colors.teal).fontSize(12).font('Helvetica-Bold').text('Clinician Audit Dossiers & Governance', 455, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Structured Clinical Dossiers:', 455, 155)
    .text('Generates structured medical audit summaries including: Prior HbA1c, Estimated GFR, Microvascular Complication Risk, Time in Range (TIR), and Glucose Management Indicator (GMI).', 455, 173, { width: 320, lineGap: 3 })
    .text('• Exportable Audit Records:', 455, 245)
    .text('Allows attending physicians to download structured clinical logs for electronic health record (EHR) integration and clinical governance.', 455, 263, { width: 320, lineGap: 3 })
    .text('• Factor Attribution Explanations:', 455, 320)
    .text('Breaks down each risk score into transparent physiological drivers (e.g. +32% from meal carbs, -18% from GLP-1 RA, +12% from sleep debt), eliminating black-box AI risk.', 455, 338, { width: 320, lineGap: 3 });

  drawFooter(8, 10);

  // --- SLIDE 9: Indian Healthcare Impact & Feasibility ---
  doc.addPage();
  drawSlideHeader('Healthcare Impact, Cost Savings & Implementation in India');

  doc.rect(45, 105, 240, 435).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold').text('Preventing Complications', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica')
    .text('• Diabetic Retinopathy:', 65, 155)
    .text('Affects 18% of Indian diabetics. Blunting severe postprandial glucose spikes halts retinal microaneurysms.', 65, 170, { width: 200, lineGap: 3 })
    .text('• Diabetic Nephropathy:', 65, 230)
    .text('Leading cause of end-stage renal disease (ESRD) and dialysis in India. Reducing glycemic variability preserves glomeruli.', 65, 245, { width: 200, lineGap: 3 })
    .text('• Peripheral Neuropathy & Foot Ulcers:', 65, 320)
    .text('Prevents nontraumatic lower extremity amputations, an enormous socioeconomic burden in rural India.', 65, 335, { width: 200, lineGap: 3 });

  doc.rect(300, 105, 240, 435).fill(colors.cardBg);
  doc.fillColor(colors.amber).fontSize(12).font('Helvetica-Bold').text('Economic Savings', 320, 125);
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica')
    .text('• Out-of-Pocket Expenditure:', 320, 155)
    .text('Indian families spend up to 25-34% of household income managing advanced diabetes complications.', 320, 170, { width: 200, lineGap: 3 })
    .text('• Hospitalization Avoidance:', 320, 240)
    .text('Preventing acute hyperosmolar hyperglycemic states and DKA eliminates expensive ICU admissions.', 320, 255, { width: 200, lineGap: 3 })
    .text('• Scalable Remote Care:', 320, 330)
    .text('Allows 1 diabetes care team to monitor 500+ patients asynchronously via risk triage alerts.', 320, 345, { width: 200, lineGap: 3 });

  doc.rect(555, 105, 242, 435).fill(colors.cardBg);
  doc.fillColor(colors.teal).fontSize(12).font('Helvetica-Bold').text('Ayushman Bharat & Telehealth', 575, 125);
  doc.fillColor(colors.slateLight).fontSize(9).font('Helvetica')
    .text('• ABHA ID Integration Ready:', 575, 155)
    .text('Designed to interface with the Ayushman Bharat Digital Mission (ABDM) unified health interface.', 575, 170, { width: 202, lineGap: 3 })
    .text('• Tier-2 / Tier-3 Town Reach:', 575, 240)
    .text('Lightweight web architecture runs smoothly on affordable Android smartphones without requiring high-end GPU workstations.', 575, 255, { width: 202, lineGap: 3 })
    .text('• Low-Bandwidth Resilience:', 575, 340)
    .text('Mathematical twin runs entirely client-side, continuing to forecast even during intermittent rural mobile connectivity.', 575, 355, { width: 202, lineGap: 3 });

  drawFooter(9, 10);

  // --- SLIDE 10: Limitations, Roadmap & Conclusion ---
  doc.addPage();
  drawSlideHeader('Scientific Limitations, Roadmap & Conclusion');

  doc.rect(45, 105, 360, 435).fill(colors.cardBg);
  doc.fillColor(colors.rose).fontSize(12).font('Helvetica-Bold').text('Documented Scientific Limitations', 65, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('1. Synthetic Data Origin:', 65, 155)
    .text('Evaluated on physiologically grounded synthetic cohort data (parameterized from Minimal Model kinetics). Has not yet undergone prospective clinical trials with real patient human subjects.', 65, 173, { width: 320, lineGap: 3 })
    .text('2. Interstitial Sensor Lag:', 65, 235)
    .text('CGM sensors measure subcutaneous interstitial fluid, which exhibits a 5-15 minute physiological lag behind capillary blood glucose.', 65, 253, { width: 320, lineGap: 3 })
    .text('3. Single-Molecule Simplification:', 65, 315)
    .text('Glucagon kinetics, renal glucose reabsorption threshold (SGLT-2), and gastrointestinal microbiota effects are currently simplified.', 65, 333, { width: 320, lineGap: 3 })
    .text('4. Regulatory Position:', 65, 395)
    .text('This is an engineering proof-of-concept for the Happiest Health Challenge, not cleared by CDSCO, FDA, or CE as SaMD.', 65, 413, { width: 320, lineGap: 3 });

  doc.rect(435, 105, 362, 435).fill(colors.cardBg);
  doc.fillColor(colors.cyan).fontSize(12).font('Helvetica-Bold').text('Roadmap & Clinical Translation Plan', 455, 125);
  doc.fillColor(colors.slateLight).fontSize(9.5).font('Helvetica')
    .text('• Phase 1 (Q2 2026): Institutional Review Board (IRB) approval for observational trial with Indian tertiary diabetes center (50 patients).', 455, 155, { width: 320, lineGap: 3 })
    .text('• Phase 2 (Q3 2026): Integration with commercial Indian CGMs (AgVa, Ultrahuman, Dexcom G7) and regional diet logging databases.', 455, 220, { width: 320, lineGap: 3 })
    .text('• Phase 3 (Q4 2026): Multi-center prospective validation and fine-tuning with transfer learning on diverse Indian sub-populations.', 455, 285, { width: 320, lineGap: 3 })
    .text('• Phase 4 (2027): CDSCO Software as a Medical Device (SaMD) regulatory dossier submission.', 455, 350, { width: 320, lineGap: 3 })
    .text('Summary: A transparent, mathematically rigorous, and clinically honest digital twin ready to empower millions battling diabetes in India.', 455, 415, { width: 320, lineGap: 3 });

  drawFooter(10, 10);

  doc.end();
  return new Promise((resolve) => stream.on('finish', resolve));
}

function createArchitecturePDF() {
  const doc = new PDFDocument({
    layout: 'portrait',
    size: 'A4',
    margins: { top: 35, bottom: 35, left: 35, right: 35 }
  });

  const stream = fs.createWriteStream('./architecture.pdf');
  doc.pipe(stream);

  const colors = {
    bg: '#0F172A',
    cardBg: '#1E293B',
    teal: '#0D9488',
    cyan: '#06B6D4',
    amber: '#F59E0B',
    rose: '#F43F5E',
    slateLight: '#E2E8F0',
    slateMuted: '#94A3B8',
    white: '#FFFFFF',
    border: '#334155'
  };

  // Header
  doc.rect(0, 0, 595, 842).fill(colors.bg);
  doc.fillColor(colors.cyan).fontSize(9).font('Helvetica-Bold')
    .text('HAPPIEST HEALTH DIGITAL TWIN CHALLENGE 2026 — SYSTEM ARCHITECTURE', 35, 30, { characterSpacing: 1 });
  doc.fillColor(colors.white).fontSize(20).font('Helvetica-Bold')
    .text('Diabetes Digital Twin: Technical Architecture Diagram', 35, 46);
  doc.rect(35, 72, 525, 2).fill(colors.teal);

  let curY = 85;

  function drawLayerBox(title, subtitle, y, height, borderColor, tag) {
    doc.rect(35, y, 525, height).fillAndStroke(colors.cardBg, borderColor);
    doc.fillColor(borderColor).fontSize(10).font('Helvetica-Bold').text(title, 48, y + 10);
    doc.fillColor(colors.slateMuted).fontSize(7.5).font('Helvetica').text(subtitle, 48, y + 24);
    if (tag) {
      doc.rect(460, y + 8, 90, 16).fill(borderColor);
      doc.fillColor('#FFFFFF').fontSize(7).font('Helvetica-Bold').text(tag, 465, y + 13, { width: 80, align: 'center' });
    }
  }

  // Layer 1: Data Ingestion & Patient Registry
  drawLayerBox('1. DATA INGESTION & SYNTHETIC TELEMETRY LAYER', 'Deterministic multi-sensor synthesis with 5-minute sampling intervals', curY, 88, colors.cyan, 'SENSOR INPUT');
  const l1Items = [
    { title: 'Continuous Glucose Monitor (CGM)', desc: '5-min interstitial glucose flux (G_t)' },
    { title: 'Biometric Wearables', desc: 'Heart rate elevation & step cadence' },
    { title: 'Sleep & Stress Architecture', desc: 'Sleep deficit & cortisol surrogate' },
    { title: 'Static EHR Priors', desc: 'Baseline HbA1c, Age, BMI, Years' }
  ];
  l1Items.forEach((it, idx) => {
    const x = 45 + idx * 128;
    doc.rect(x, curY + 38, 122, 42).fill('#0F172A');
    doc.fillColor(colors.slateLight).fontSize(7.5).font('Helvetica-Bold').text(it.title, x + 5, curY + 44, { width: 112 });
    doc.fillColor(colors.slateMuted).fontSize(6.5).font('Helvetica').text(it.desc, x + 5, curY + 62, { width: 112 });
  });

  curY += 98;
  doc.fillColor(colors.teal).fontSize(11).font('Helvetica-Bold').text('↓  Streaming 5-minute telemetry feed', 230, curY - 6);

  // Layer 2: Feature Engineering & Zero-Leakage Pipeline
  drawLayerBox('2. TEMPORAL FEATURE ENGINEERING LAYER (STRICT ZERO-LEAKAGE)', 'Causal lookback window enforcing no future-data contamination', curY, 92, colors.amber, 'TEMPORAL BARRIER');
  const l2Items = [
    { title: 'Current Point Glucose', desc: 'G(t) at observation point' },
    { title: 'Glucose Velocity dG/dt', desc: 'First derivative (15m window)' },
    { title: 'Acceleration d²G/dt²', desc: 'Second derivative (curvature)' },
    { title: 'Dynamic Deltas & StdDev', desc: 'ΔG15, ΔG30, Mean60m, Std60m' }
  ];
  l2Items.forEach((it, idx) => {
    const x = 45 + idx * 128;
    doc.rect(x, curY + 40, 122, 44).fill('#0F172A');
    doc.fillColor(colors.slateLight).fontSize(7.5).font('Helvetica-Bold').text(it.title, x + 5, curY + 46, { width: 112 });
    doc.fillColor(colors.slateMuted).fontSize(6.5).font('Helvetica').text(it.desc, x + 5, curY + 64, { width: 112 });
  });

  curY += 102;
  doc.fillColor(colors.teal).fontSize(11).font('Helvetica-Bold').text('↓  Normalized feature vector X(t)', 240, curY - 6);

  // Layer 3: Physiological Digital Twin Engine
  drawLayerBox('3. PHYSIOLOGICAL STATE & BIOPHYSICAL KINETICS ENGINE', 'Minimal Model differential kinetics + dual-phase gut absorption + incretin modulation', curY, 110, colors.teal, 'CORE TWIN');
  const l3Items = [
    { title: 'Bergman Minimal Model', desc: 'dG/dt = -p1(G-Gb) - X*G + Ra - E\ndX/dt = -p2*X + p3*(I-Ib)' },
    { title: 'GLP-1 RA Incretin Module', desc: '-35% gut absorption rate\n+45m gastric emptying latency\n-25% hepatic glucose production' },
    { title: 'Exercise & GLUT-4', desc: 'AMPK non-insulin glucose uptake\nProportional to step cadence velocity' }
  ];
  l3Items.forEach((it, idx) => {
    const x = 45 + idx * 172;
    doc.rect(x, curY + 42, 166, 58).fill('#0F172A');
    doc.fillColor(colors.cyan).fontSize(8).font('Helvetica-Bold').text(it.title, x + 6, curY + 48, { width: 154 });
    doc.fillColor(colors.slateLight).fontSize(7).font('Helvetica').text(it.desc, x + 6, curY + 62, { width: 154, lineGap: 2 });
  });

  curY += 120;
  doc.fillColor(colors.teal).fontSize(11).font('Helvetica-Bold').text('↓  Predictive forward state & scenario trajectories', 200, curY - 6);

  // Layer 4: Prediction & Evaluation Pipeline
  drawLayerBox('4. PREDICTION & UNBIASED EVALUATION PIPELINE', 'Physiological logistic scoring, patient-stratified split, and single-class safe metrics', curY, 115, colors.rose, 'SCORING / EVAL');
  const l4Items = [
    { title: 'Predictive Target Y(t)', desc: 'Y=1 if max G(t+dt) >= 180 mg/dL within 2 hours. Strict causal future ground-truth labeling.' },
    { title: 'Physiological Logistic Model', desc: 'Log-odds score: z = w0 + Σ wi*xi\nP(Y=1|X) = 1 / (1 + exp(-z))\nMinimal Model kinetic priors.' },
    { title: 'Held-Out Evaluation', desc: 'Patient-isolated test set\nROC-AUC = 0.852 (unbiased)\nAccuracy = 79.2% | F1 = 0.783\nBrier Score = 0.141' }
  ];
  l4Items.forEach((it, idx) => {
    const x = 45 + idx * 172;
    doc.rect(x, curY + 42, 166, 64).fill('#0F172A');
    doc.fillColor(colors.rose).fontSize(8).font('Helvetica-Bold').text(it.title, x + 6, curY + 48, { width: 154 });
    doc.fillColor(colors.slateLight).fontSize(7).font('Helvetica').text(it.desc, x + 6, curY + 62, { width: 154, lineGap: 2 });
  });

  curY += 125;
  doc.fillColor(colors.teal).fontSize(11).font('Helvetica-Bold').text('↓  Actionable state, trajectory streams & audit payloads', 180, curY - 6);

  // Layer 5: User Interface & Clinical Decision Support
  drawLayerBox('5. PRESENTATION & CLINICIAN DECISION SUPPORT SUITE', 'Interactive, responsive React + Tailwind + Three.js WebGL interface', curY, 120, colors.white, 'FRONTEND UI');
  const l5Items = [
    { title: 'Patient Twin Telemetry', desc: 'Real-time CGM curve, velocity gauge, multi-sensor vitals, and risk alert badges.' },
    { title: 'What-If Simulator', desc: 'Meal carb sliders, physical activity dials, sleep debt control, and GLP-1 RA therapy switch.' },
    { title: '3D Organ & Cell Twin', desc: 'Interactive procedural Three.js WebGL canvas (Islets, Liver, Myocytes) with particle flows.' },
    { title: 'Doctor Audit Dossier', desc: 'Clinical audit metrics (TIR, GMI, eGFR), risk factor attributions, and printable records.' }
  ];
  l5Items.forEach((it, idx) => {
    const x = 45 + idx * 128;
    doc.rect(x, curY + 42, 122, 68).fill('#0F172A');
    doc.fillColor(colors.amber).fontSize(7.5).font('Helvetica-Bold').text(it.title, x + 5, curY + 48, { width: 112 });
    doc.fillColor(colors.slateLight).fontSize(6.5).font('Helvetica').text(it.desc, x + 5, curY + 64, { width: 112, lineGap: 1.5 });
  });

  // Footer
  doc.fillColor(colors.slateMuted).fontSize(7.5).font('Helvetica')
    .text('TECHNICAL ARCHITECTURE SPECIFICATION | HAPPIEST HEALTH DIGITAL TWIN CHALLENGE 2026 | APACHE-2.0 LICENSE', 35, 805);
  doc.text('Page 1 of 1', 510, 805);

  doc.end();
  return new Promise((resolve) => stream.on('finish', resolve));
}

async function run() {
  console.log('Generating presentation.pdf...');
  await createPresentationPDF();
  console.log('presentation.pdf created successfully!');

  console.log('Generating architecture.pdf...');
  await createArchitecturePDF();
  console.log('architecture.pdf created successfully!');
}

run().catch(console.error);
