# Diabetes Digital Twin — System Architecture Specification
**Happiest Health Digital Twin Challenge 2026**

> Note: A compiled PDF version of the technical architecture is available at `architecture.pdf`. You can regenerate both the presentation and architecture PDFs using `node scripts/generate_submission_assets.js`.

---

## 1. High-Level System Architecture Diagram

```mermaid
graph TD
    subgraph S1 [1. Multi-Sensor Data Ingestion Layer]
        CGM[Continuous Glucose Monitor - 5m Interstitial G_t]
        WEAR[Biometric Wearables - Heart Rate & Step Cadence]
        SLEEP[Sleep Architecture Tracker - Sleep Deficit & Cortisol]
        EHR[Static EHR Priors - HbA1c, Age, BMI, Diagnosis Years]
    end

    subgraph S2 [2. Feature Engineering Layer - Strict Zero-Leakage]
        TL[Causal Temporal Lookback Barrier: t_obs <= current_time]
        VEL[Glucose Velocity: dG/dt]
        ACC[Glucose Acceleration: d²G/dt²]
        DELTAS[15m & 30m Glucose Deltas & Volatility StdDev]
        NORM[Feature Normalization & Min-Max Scaling]
    end

    subgraph S3 [3. Biophysical Digital Twin Engine]
        MM[Bergman Minimal Model Glucose-Insulin Kinetics]
        GUT[Dual-Phase Gastric Emptying & Gut Glucose Influx Ra_t]
        GLUT4[Exercise AMPK-Mediated GLUT-4 Non-Insulin Glucose Uptake]
        GLP1[GLP-1 RA Incretin Module: Decelerated Emptying & Hepatic Suppression]
    end

    subgraph S4 [4. Prediction & Evaluation Pipeline]
        TARGET[Target Formulation: Y = 1 if max G in 2h >= 180 mg/dL]
        MODEL[Rule-Based Physiological Logistic Scoring Model]
        SPLIT[Patient-Stratified Train/Test Split]
        METRICS[Unbiased Held-Out Metrics: ROC-AUC 0.852, Accuracy 79.2%, Brier 0.141]
    end

    subgraph S5 [5. User Interface & Decision Support Layer]
        DASH[Real-Time Patient Twin Dashboard]
        SIM[What-If Simulator & GLP-1 RA Toggle]
        TWIN3D[Three.js Procedural 3D Organ & Cell Twin]
        AUDIT[Doctor Clinical Audit Dossier & Exportable Records]
    end

    CGM --> TL
    WEAR --> TL
    SLEEP --> TL
    EHR --> TL

    TL --> VEL
    TL --> ACC
    TL --> DELTAS
    VEL --> NORM
    ACC --> NORM
    DELTAS --> NORM

    NORM --> MM
    MM --> GUT
    MM --> GLUT4
    MM --> GLP1

    GUT --> TARGET
    GLUT4 --> TARGET
    GLP1 --> TARGET
    NORM --> MODEL
    TARGET --> MODEL
    MODEL --> SPLIT
    SPLIT --> METRICS

    METRICS --> DASH
    MM --> SIM
    GLP1 --> SIM
    MM --> TWIN3D
    METRICS --> AUDIT
    MODEL --> DASH
```

---

## 2. Layer-by-Layer Architectural Breakdown

### Layer 1: Data Ingestion & Patient Registry
- **Synthetic Patient Registry:** Stores static clinical priors (e.g., age, BMI, baseline HbA1c, duration of diabetes, baseline medication regimen).
- **Dynamic 5-Minute Telemetry Stream:** Ingests continuous interstitial glucose measurements ($G_t$), step cadence, heart rate, and sleep architecture scores.
- **Deterministic Pseudo-Random Generation:** Built using seeded LCG generators to ensure reproducible synthetic runs across all experiments.

### Layer 2: Feature Engineering & Temporal Barrier (Zero-Leakage Guarantee)
- **Strict Temporal Barrier:** The extraction window enforces $t_{reading} \le t_{obs}$. No future readings are accessible during feature computation.
- **Derived Physiological Features:**
  - $G(t)$: Current glucose reading (mg/dL)
  - $\Delta G_{15}$: 15-minute glucose delta ($G(t) - G(t-15m)$)
  - $\Delta G_{30}$: 30-minute glucose delta ($G(t) - G(t-30m)$)
  - $v_G$: Finite-difference velocity $\frac{dG}{dt}$ (mg/dL/min)
  - $a_G$: Finite-difference acceleration $\frac{d^2G}{dt^2}$ (mg/dL/min²)
  - $\mu_{60}, \sigma_{60}$: 60-minute historical mean and standard deviation (glucose variability)
  - Recent physical activity (steps in past 60 min)
  - Sleep deficit relative to 8-hour restorative sleep setpoint

### Layer 3: Physiological Digital Twin Engine
- **Bergman Minimal Model Implementation:**
  $$\frac{dG}{dt} = -p_1(G(t) - G_b) - X(t)G(t) + R_a(t) - E(t)$$
  $$\frac{dX}{dt} = -p_2 X(t) + p_3(I(t) - I_b)$$
- **Dual-Phase Gastric Emptying ($R_a(t)$):** Models meal carbohydrate absorption with early rapid emptying followed by zero-order sustained delivery.
- **Exercise GLUT-4 Translocation ($E(t)$):** Models non-insulin-mediated glucose uptake triggered by skeletal muscle contraction ($E(t) \propto \text{step cadence}$).
- **GLP-1 RA Incretin Dynamics:**
  - Intestinal glucose absorption rate is dampened by 35%.
  - Gastric emptying latency $T_{max}$ is delayed by +45 minutes.
  - Hepatic glucose overproduction is suppressed by 25%.
  - Beta-cell insulin sensitivity constant $p_3$ is potentiated by 20%.

### Layer 4: Prediction & Evaluation Pipeline
- **Ground-Truth Target:** Causal 2-hour forward window label:
  $$Y(t) = \begin{cases} 1 & \text{if } \max_{0 < \Delta t \le 120} G(t + \Delta t) \ge G_{\text{threshold}} \\ 0 & \text{otherwise} \end{cases}$$
- **Scoring Architecture:** Expert-parameterized rule-based multivariable logistic scoring model with physiological minimal model kinetic priors and standardized features.
- **Patient-Isolated Split:** Telemetry from baseline patients is strictly decoupled from held-out evaluation patients (e.g., patient 5).
- **Safe Metric Computation:**
  - Evaluates true ROC-AUC without artificial lower bounds or hardcoded floors.
  - Returns `rocAuc: null` with status `single_class_undefined` if a subset contains only negative or only positive cases.

### Layer 5: User Interface & Clinical Decision Support
- **Frontend Framework:** React 19 SPA running on Vite with TypeScript and Tailwind CSS.
- **Patient Twin Dashboard:** Live CGM telemetry curve with 2-hour predictive forecast cone, risk tier gauges, and physiological state cards.
- **What-If Simulator:** Interactive dials for meal carbs, physical exercise, and sleep deficit, coupled with the real-time GLP-1 RA therapy toggle.
- **3D Procedural Organ & Cell Twin:** Three.js WebGL canvas visualizing pancreatic islet secretion, hepatic flux, and muscle glucose uptake.
- **Doctor Audit Dossier:** Comprehensive clinical dossiers with Time in Range (TIR), Glucose Management Indicator (GMI), estimated GFR, and exportable medical records.
